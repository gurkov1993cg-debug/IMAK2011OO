#include "silveton/sampler/SamplerLibrary.h"
#include "silveton/sampler/KorgImporter.h"

#include <algorithm>
#include "silveton/sampler/FsCompat.h"
#include <limits>
#include <optional>
#include <unordered_map>
#include <unordered_set>
#include <utility>

namespace silveton::sampler {

namespace {

std::string normalizedIdentity(const std::string& identity) {
    if (identity.empty()) return {};
    if (identity.rfind("KSF:", 0U) == 0U) {
        return std::string("KSF:") + normalizedIdentity(identity.substr(4U));
    }
    std::error_code ec;
    const silveton::fsx::path p(identity);
    const auto canonical = silveton::fsx::weakly_canonical(p, ec);
    return (ec ? p.lexically_normal() : canonical).generic_string();
}

std::string sampleIdentity(const SamplePtr& sample) {
    if (sample == nullptr) return {};
    if (!sample->sourceIdentity.empty()) return normalizedIdentity(sample->sourceIdentity);
    return normalizedIdentity(sample->sourcePath);
}

std::string multisampleIdentity(const MultisamplePtr& multisample) {
    if (multisample == nullptr) return {};
    return normalizedIdentity(multisample->sourceIdentity);
}

template <typename Map>
std::optional<std::uint32_t> firstFreeId(const Map& map, const std::unordered_set<std::uint32_t>& reserved) {
    std::uint64_t candidate = 1U;
    if (!map.empty()) candidate = static_cast<std::uint64_t>(map.rbegin()->first) + 1U;
    while (candidate <= static_cast<std::uint64_t>(std::numeric_limits<std::uint32_t>::max())) {
        const auto id = static_cast<std::uint32_t>(candidate);
        if (id != 0U && map.find(id) == map.end() && reserved.find(id) == reserved.end()) return id;
        ++candidate;
    }
    return std::nullopt;
}

void appendUnique(std::vector<std::uint32_t>& values, std::uint32_t value) {
    if (std::find(values.begin(), values.end(), value) == values.end()) values.push_back(value);
}

} // namespace

bool SamplerLibrary::writeSample(std::uint32_t id, SamplePtr sample) {
    if (id == 0U || sample == nullptr || !sample->valid()) return false;
    SamplePtr previous;
    const auto existing = samples_.find(id);
    if (existing != samples_.end()) previous = existing->second;
    samples_[id] = sample;

    if (previous != nullptr && previous != sample) {
        std::vector<std::pair<std::uint32_t, std::shared_ptr<Multisample>>> replacements;
        for (const auto& item : multisamples_) {
            if (item.second == nullptr) continue;
            std::shared_ptr<Multisample> copy;
            for (std::size_t i = 0U; i < item.second->zones.size(); ++i) {
                if (item.second->zones[i].sample != previous) continue;
                if (copy == nullptr) copy = std::make_shared<Multisample>(*item.second);
                copy->zones[i].sample = sample;
            }
            if (copy != nullptr) replacements.push_back({item.first, std::move(copy)});
        }
        for (auto& item : replacements) (void)writeMultisample(item.first, std::move(item.second));
    }
    return true;
}

bool SamplerLibrary::writeMultisample(std::uint32_t id, MultisamplePtr multisample) {
    if (multisample == nullptr || multisample->name.empty() || multisample->zones.empty() ||
        multisample->zones.size() > static_cast<std::size_t>(kMaxZonesPerMultisample)) return false;
    MultisamplePtr previous;
    const auto existing = multisamples_.find(id);
    if (existing != multisamples_.end()) previous = existing->second;
    multisamples_[id] = multisample;

    if (previous != nullptr && previous != multisample) {
        std::vector<std::pair<SlotAddress, std::shared_ptr<Program>>> replacements;
        for (const auto& item : programs_) {
            if (item.second == nullptr) continue;
            std::shared_ptr<Program> copy;
            for (std::size_t i = 0U; i < item.second->layers.size(); ++i) {
                if (item.second->layers[i].multisample != previous) continue;
                if (copy == nullptr) copy = std::make_shared<Program>(*item.second);
                copy->layers[i].multisample = multisample;
            }
            if (copy != nullptr) replacements.push_back({item.first, std::move(copy)});
        }
        for (auto& item : replacements) (void)writeProgram(item.first, std::move(item.second));
    }
    return true;
}

bool SamplerLibrary::writeProgram(const SlotAddress& address, ProgramPtr program) {
    if (program == nullptr || program->name.empty()) return false;
    ProgramPtr previous;
    const auto existing = programs_.find(address);
    if (existing != programs_.end()) previous = existing->second;
    programs_[address] = program;
    if (previous != nullptr && previous != program) {
        for (auto& item : combis_) {
            for (auto& upper : item.second.uppers) {
                if (upper.program == previous) upper.program = program;
            }
        }
    }
    return true;
}

bool SamplerLibrary::writeCombi(const SlotAddress& address, const Combi& combi) {
    if (combi.name.empty()) return false;
    combis_[address] = combi;
    return true;
}

bool SamplerLibrary::writeList(const SlotAddress& address, const SetList& list) {
    if (list.name.empty()) return false;
    lists_[address] = list;
    return true;
}


KorgLibraryImportResult SamplerLibrary::importKmp(const std::string& path) {
    const auto imported = KorgImporter::loadKmp(path);
    if (!imported.ok()) return {false, {}, {}, imported.warnings, imported.error};
    return importKorgResources({imported.multisample}, imported.samples, imported.warnings);
}

KorgLibraryImportResult SamplerLibrary::importKsc(const std::string& path) {
    const auto imported = KorgImporter::loadKsc(path);
    if (!imported.ok()) return {false, {}, {}, imported.warnings, imported.error};
    return importKorgResources(imported.multisamples, imported.samples, imported.warnings);
}

KorgLibraryImportResult SamplerLibrary::importKorgResources(
    const std::vector<MultisamplePtr>& multisamples,
    const std::vector<SamplePtr>& samples,
    std::vector<std::string> warnings) {
    KorgLibraryImportResult result{};
    result.warnings = std::move(warnings);
    if (multisamples.empty()) {
        result.error = "Korg import contains no multisamples";
        return result;
    }

    std::unordered_map<std::string, std::uint32_t> existingSampleIds;
    for (const auto& item : samples_) {
        const auto identity = sampleIdentity(item.second);
        if (!identity.empty()) existingSampleIds.emplace(identity, item.first);
    }
    std::unordered_map<std::string, std::uint32_t> existingMultisampleIds;
    for (const auto& item : multisamples_) {
        const auto identity = multisampleIdentity(item.second);
        if (!identity.empty()) existingMultisampleIds.emplace(identity, item.first);
    }

    std::unordered_set<std::uint32_t> reservedSampleIds;
    std::unordered_set<std::uint32_t> reservedMultisampleIds;
    std::unordered_map<std::string, std::uint32_t> assignedSampleIds;
    std::unordered_map<std::string, std::uint32_t> assignedMultisampleIds;
    std::map<std::uint32_t, SamplePtr> stagedSamples;
    std::map<std::uint32_t, MultisamplePtr> stagedMultisamples;

    auto assignSample = [&](const SamplePtr& sample) -> std::optional<std::uint32_t> {
        if (sample == nullptr || !sample->valid()) return std::nullopt;
        const auto identity = sampleIdentity(sample);
        if (identity.empty()) return std::nullopt;
        if (const auto it = assignedSampleIds.find(identity); it != assignedSampleIds.end()) {
            stagedSamples[it->second] = sample;
            return it->second;
        }
        std::uint32_t id = 0U;
        if (const auto existing = existingSampleIds.find(identity); existing != existingSampleIds.end()) {
            id = existing->second;
        } else {
            const auto freeId = firstFreeId(samples_, reservedSampleIds);
            if (!freeId.has_value()) return std::nullopt;
            id = *freeId;
        }
        reservedSampleIds.insert(id);
        assignedSampleIds.emplace(identity, id);
        stagedSamples[id] = sample;
        appendUnique(result.sampleIds, id);
        return id;
    };

    for (const auto& sample : samples) {
        if (!assignSample(sample).has_value()) {
            result.error = "Korg import contains an invalid sample or missing source identity";
            return result;
        }
    }

    for (const auto& multisample : multisamples) {
        if (multisample == nullptr || multisample->name.empty() || multisample->zones.empty() ||
            multisample->zones.size() > static_cast<std::size_t>(kMaxZonesPerMultisample)) {
            result.error = "Korg import contains an invalid multisample";
            return result;
        }
        const auto identity = multisampleIdentity(multisample);
        if (identity.empty()) {
            result.error = "Korg multisample has no stable source identity";
            return result;
        }

        std::uint32_t id = 0U;
        if (const auto assigned = assignedMultisampleIds.find(identity); assigned != assignedMultisampleIds.end()) {
            id = assigned->second;
        } else if (const auto existing = existingMultisampleIds.find(identity); existing != existingMultisampleIds.end()) {
            id = existing->second;
            assignedMultisampleIds.emplace(identity, id);
            reservedMultisampleIds.insert(id);
        } else {
            const auto freeId = firstFreeId(multisamples_, reservedMultisampleIds);
            if (!freeId.has_value()) {
                result.error = "No free MULTISAMPLE IDs remain";
                return result;
            }
            id = *freeId;
            assignedMultisampleIds.emplace(identity, id);
            reservedMultisampleIds.insert(id);
        }

        auto copy = std::make_shared<Multisample>(*multisample);
        for (auto& zone : copy->zones) {
            const auto sampleId = assignSample(zone.sample);
            if (!sampleId.has_value()) {
                result.error = "Korg multisample zone references an invalid sample";
                return result;
            }
            const auto staged = stagedSamples.find(*sampleId);
            if (staged == stagedSamples.end() || staged->second == nullptr) {
                result.error = "Korg sample staging failed";
                return result;
            }
            zone.sample = staged->second;
        }
        stagedMultisamples[id] = std::move(copy);
        appendUnique(result.multisampleIds, id);
    }

    const SetData before = snapshot();
    for (const auto& item : stagedSamples) {
        if (!writeSample(item.first, item.second)) {
            replace(before);
            result.sampleIds.clear();
            result.multisampleIds.clear();
            result.error = "Korg SAMPLE library commit failed";
            return result;
        }
    }
    for (const auto& item : stagedMultisamples) {
        if (!writeMultisample(item.first, item.second)) {
            replace(before);
            result.sampleIds.clear();
            result.multisampleIds.clear();
            result.error = "Korg MULTISAMPLE library commit failed";
            return result;
        }
    }

    result.success = true;
    return result;
}

std::vector<std::uint32_t> SamplerLibrary::multisampleIds() const {
    std::vector<std::uint32_t> ids;
    ids.reserve(multisamples_.size());
    for (const auto& item : multisamples_) ids.push_back(item.first);
    return ids;
}

std::vector<std::string> SamplerLibrary::multisampleNames() const {
    std::vector<std::string> names;
    names.reserve(multisamples_.size());
    for (const auto& item : multisamples_) names.push_back(item.second != nullptr ? item.second->name : std::string{});
    return names;
}

bool SamplerLibrary::hasProgram(const SlotAddress& address) const { return programs_.find(address) != programs_.end(); }
bool SamplerLibrary::hasCombi(const SlotAddress& address) const { return combis_.find(address) != combis_.end(); }
bool SamplerLibrary::hasList(const SlotAddress& address) const { return lists_.find(address) != lists_.end(); }

bool SamplerLibrary::renameProgram(const SlotAddress& address, const std::string& name) {
    if (name.empty()) return false;
    const auto it = programs_.find(address);
    if (it == programs_.end() || it->second == nullptr) return false;
    auto copy = std::make_shared<Program>(*it->second);
    copy->name = name;
    return writeProgram(address, std::move(copy));
}

bool SamplerLibrary::renameCombi(const SlotAddress& address, const std::string& name) {
    if (name.empty()) return false;
    const auto it = combis_.find(address);
    if (it == combis_.end()) return false;
    it->second.name = name;
    return true;
}

bool SamplerLibrary::renameList(const SlotAddress& address, const std::string& name) {
    if (name.empty()) return false;
    const auto it = lists_.find(address);
    if (it == lists_.end()) return false;
    it->second.name = name;
    return true;
}

bool SamplerLibrary::copyProgram(const SlotAddress& from, const SlotAddress& to, bool overwrite) {
    const auto it = programs_.find(from);
    if (it == programs_.end() || it->second == nullptr || (!overwrite && hasProgram(to))) return false;
    programs_[to] = std::make_shared<Program>(*it->second);
    return true;
}

bool SamplerLibrary::copyCombi(const SlotAddress& from, const SlotAddress& to, bool overwrite) {
    const auto it = combis_.find(from);
    if (it == combis_.end() || (!overwrite && hasCombi(to))) return false;
    combis_[to] = it->second;
    return true;
}

bool SamplerLibrary::copyList(const SlotAddress& from, const SlotAddress& to, bool overwrite) {
    const auto it = lists_.find(from);
    if (it == lists_.end() || (!overwrite && hasList(to))) return false;
    lists_[to] = it->second;
    return true;
}

bool SamplerLibrary::moveList(const SlotAddress& from, const SlotAddress& to, bool overwrite) {
    if (from == to) return hasList(from);
    const auto it = lists_.find(from);
    if (it == lists_.end() || (!overwrite && hasList(to))) return false;
    lists_[to] = it->second;
    lists_.erase(it);
    return true;
}

bool SamplerLibrary::setListEntry(const SlotAddress& address, std::size_t index, const ListEntry& entry) {
    const auto it = lists_.find(address);
    if (it == lists_.end() || index >= it->second.entries.size() || entry.name.empty()) return false;
    it->second.entries[index] = entry;
    return true;
}

bool SamplerLibrary::insertListEntry(const SlotAddress& address, std::size_t index, const ListEntry& entry) {
    const auto it = lists_.find(address);
    if (it == lists_.end() || entry.name.empty() || it->second.entries.size() >= static_cast<std::size_t>(kMaxListSlots)) return false;
    index = std::min(index, it->second.entries.size());
    it->second.entries.insert(it->second.entries.begin() + static_cast<std::ptrdiff_t>(index), entry);
    return true;
}

bool SamplerLibrary::removeListEntry(const SlotAddress& address, std::size_t index) {
    const auto it = lists_.find(address);
    if (it == lists_.end() || index >= it->second.entries.size()) return false;
    it->second.entries.erase(it->second.entries.begin() + static_cast<std::ptrdiff_t>(index));
    return true;
}

bool SamplerLibrary::moveListEntry(const SlotAddress& address, std::size_t fromIndex, std::size_t toIndex) {
    const auto it = lists_.find(address);
    if (it == lists_.end() || fromIndex >= it->second.entries.size() || toIndex >= it->second.entries.size()) return false;
    if (fromIndex == toIndex) return true;
    auto entry = std::move(it->second.entries[fromIndex]);
    it->second.entries.erase(it->second.entries.begin() + static_cast<std::ptrdiff_t>(fromIndex));
    it->second.entries.insert(it->second.entries.begin() + static_cast<std::ptrdiff_t>(toIndex), std::move(entry));
    return true;
}

SamplePtr SamplerLibrary::sample(std::uint32_t id) const {
    const auto it = samples_.find(id);
    return it == samples_.end() ? nullptr : it->second;
}

MultisamplePtr SamplerLibrary::multisample(std::uint32_t id) const {
    const auto it = multisamples_.find(id);
    return it == multisamples_.end() ? nullptr : it->second;
}

ProgramPtr SamplerLibrary::program(const SlotAddress& address) const {
    const auto it = programs_.find(address);
    return it == programs_.end() ? nullptr : it->second;
}

std::vector<ProgramCatalogItem> SamplerLibrary::programCatalog() const {
    std::vector<ProgramCatalogItem> out;
    out.reserve(programs_.size());
    for (const auto& item : programs_) {
        if (item.second == nullptr) continue;
        out.push_back({item.first, item.second->name});
    }
    return out;
}

std::optional<Combi> SamplerLibrary::combi(const SlotAddress& address) const {
    const auto it = combis_.find(address);
    if (it == combis_.end()) return std::nullopt;
    return it->second;
}

std::optional<SetList> SamplerLibrary::list(const SlotAddress& address) const {
    const auto it = lists_.find(address);
    if (it == lists_.end()) return std::nullopt;
    return it->second;
}

bool SamplerLibrary::clearSample(std::uint32_t id) {
    const auto it = samples_.find(id);
    if (it == samples_.end()) return false;
    it->second.reset(); // tombstone: this ID must never silently become another SAMPLE
    return true;
}
bool SamplerLibrary::clearMultisample(std::uint32_t id) {
    const auto it = multisamples_.find(id);
    if (it == multisamples_.end()) return false;
    it->second.reset(); // tombstone: preserve stable MULTISAMPLE identity
    return true;
}
bool SamplerLibrary::clearProgram(const SlotAddress& address) { return programs_.erase(address) != 0U; }
bool SamplerLibrary::clearCombi(const SlotAddress& address) { return combis_.erase(address) != 0U; }
bool SamplerLibrary::clearList(const SlotAddress& address) { return lists_.erase(address) != 0U; }

SetData SamplerLibrary::snapshot() const {
    SetData data;
    data.name = setName_;
    data.global = global_;
    for (const auto& item : samples_) data.samples.push_back({item.first, item.second});
    for (const auto& item : multisamples_) data.multisamples.push_back({item.first, item.second});
    for (const auto& item : programs_) data.programs.push_back({item.first, item.second});
    for (const auto& item : combis_) data.combis.push_back({item.first, item.second});
    for (const auto& item : lists_) data.lists.push_back({item.first, item.second});
    return data;
}

SetData SamplerLibrary::snapshotBank(std::uint16_t bank) const {
    SetData data;
    data.name = setName_ + " / Bank " + std::to_string(bank);
    data.global = global_;
    for (const auto& item : programs_) if (item.first.bank == bank) data.programs.push_back({item.first, item.second});
    for (const auto& item : combis_) if (item.first.bank == bank) data.combis.push_back({item.first, item.second});
    for (const auto& item : lists_) if (item.first.bank == bank) data.lists.push_back({item.first, item.second});
    return data;
}

BankMergeResult SamplerLibrary::mergeBank(const SetData& data, std::uint16_t targetBank, bool overwrite) {
    // Validate the complete destination first so a rejected import never leaves a partial bank behind.
    for (const auto& item : data.programs) {
        SlotAddress dst{targetBank, item.address.page, item.address.slot};
        if (!overwrite && hasProgram(dst)) return {false, "PROGRAM destination slot is occupied"};
    }
    for (const auto& item : data.combis) {
        SlotAddress dst{targetBank, item.address.page, item.address.slot};
        if (!overwrite && hasCombi(dst)) return {false, "COMBI destination slot is occupied"};
    }
    for (const auto& item : data.lists) {
        SlotAddress dst{targetBank, item.address.page, item.address.slot};
        if (!overwrite && hasList(dst)) return {false, "LIST destination slot is occupied"};
    }

    for (const auto& item : data.programs) {
        if (item.program == nullptr) continue;
        programs_[SlotAddress{targetBank, item.address.page, item.address.slot}] = item.program;
    }
    for (const auto& item : data.combis) {
        combis_[SlotAddress{targetBank, item.address.page, item.address.slot}] = item.combi;
    }
    for (const auto& item : data.lists) {
        auto listCopy = item.list;
        // Entries that pointed into the exported bank follow the remapped bank.
        for (auto& entry : listCopy.entries) {
            bool referencedExportedBank = false;
            for (const auto& combi : data.combis) {
                if (entry.combiBank == combi.address.bank && entry.combiPage == combi.address.page && entry.combiSlot == combi.address.slot) {
                    referencedExportedBank = true;
                    break;
                }
            }
            if (referencedExportedBank) entry.combiBank = targetBank;
        }
        lists_[SlotAddress{targetBank, item.address.page, item.address.slot}] = std::move(listCopy);
    }
    return {true, {}};
}

void SamplerLibrary::replace(const SetData& data) {
    setName_ = data.name;
    global_ = data.global;
    samples_.clear();
    multisamples_.clear();
    programs_.clear();
    combis_.clear();
    lists_.clear();
    for (const auto& item : data.samples) if (item.id != 0U) samples_[item.id] = item.sample;
    for (const auto& item : data.multisamples) if (item.id != 0U) multisamples_[item.id] = item.multisample;
    for (const auto& slot : data.programs) if (slot.program != nullptr) programs_[slot.address] = slot.program;
    for (const auto& slot : data.combis) combis_[slot.address] = slot.combi;
    for (const auto& slot : data.lists) lists_[slot.address] = slot.list;
}

} // namespace silveton::sampler
