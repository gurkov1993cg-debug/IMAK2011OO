#include "silveton/Portamento.h"
#include <algorithm>
#include <cmath>

namespace silveton {

KorgGlideModel::KorgGlideModel() {
    // Manual model until the player balances it by ear (or calibrates with the
    // microphone): time per semitone grows exponentially with CC#5.
    setManualBalance(11.0);
}

void KorgGlideModel::setManualBalance(double ccPerDoubling) {
    balance_ = std::clamp(ccPerDoubling, 3.0, 40.0);
    std::vector<Point> p;
    for (int cc = 4; cc <= 127; cc += 4) p.push_back({cc, 0.0, 0.2 * std::pow(2.0, cc / balance_)});
    setPoints(p, false);
}

void KorgGlideModel::setPoints(const std::vector<Point>& points, bool calibrated) {
    points_ = points;
    std::sort(points_.begin(), points_.end(), [](const Point& x, const Point& y) { return x.cc < y.cc; });
    calibrated_ = calibrated && !points_.empty();
}

double KorgGlideModel::timeFor(int cc, double interval) const {
    if (points_.empty() || cc <= 0) return 0.0;
    auto t = [&](const Point& p) { return std::max(0.0, p.aMs + p.bMsPerSemitone * interval); };
    if (cc <= points_.front().cc) {
        // Between CC 0 (instant) and the first measured point.
        return t(points_.front()) * static_cast<double>(cc) / static_cast<double>(points_.front().cc);
    }
    for (std::size_t i = 1; i < points_.size(); ++i) {
        if (cc <= points_[i].cc) {
            const double f = static_cast<double>(cc - points_[i - 1].cc) /
                             static_cast<double>(points_[i].cc - points_[i - 1].cc);
            return t(points_[i - 1]) + (t(points_[i]) - t(points_[i - 1])) * f;
        }
    }
    return t(points_.back());
}

int KorgGlideModel::ccFor(double interval, double timeMs) const {
    if (timeMs <= 0.0 || interval <= 0.0 || points_.empty()) return 0;
    // t(cc) is monotonic in cc: binary search over 0..127.
    int lo = 0, hi = 127;
    if (timeFor(hi, interval) <= timeMs) return 127;
    while (hi - lo > 1) {
        const int mid = (lo + hi) / 2;
        if (timeFor(mid, interval) < timeMs) lo = mid; else hi = mid;
    }
    // Pick the closer of the two neighbours.
    const double dlo = std::abs(timeFor(lo, interval) - timeMs);
    const double dhi = std::abs(timeFor(hi, interval) - timeMs);
    return dlo <= dhi ? lo : hi;
}

int Portamento::nativeCcForNote(int ch, int note) {
    if (!activeOn(ch)) return -1;
    auto& lastNote = lastNote_[static_cast<std::size_t>(ch)];
    const int last = lastNote;
    lastNote = note;
    if (last < 0 || last == note) return -1;
    const double interval = std::abs(static_cast<double>(note - last));
    const int cc = model_.ccFor(interval, static_cast<double>(config_.timeMs));
    auto& lastCc = lastCc_[static_cast<std::size_t>(ch)];
    if (cc == lastCc) return -1;            // already set: nothing to send
    lastCc = cc;
    return cc;
}

void Portamento::setConfig(const Config& config) {
    if (config.enabled && !config_.enabled) chOn_ = {{true, true, true}};
    config_ = config;
    config_.timeMs = std::clamp(config_.timeMs, kMinTimeMs, kMaxTimeMs);
    if (!config_.enabled) reset();
}

std::vector<MidiMessage> Portamento::setEnabled(bool enabled) {
    if (!enabled) {
        std::vector<MidiMessage> out;
        // Switch the Korg portamento OFF on every Upper that had it.
        for (int ch = 0; ch < 3; ++ch) {
            if (activeOn(ch)) out.push_back(MidiMessage::controlChange(ch, 65, 0));
        }
        config_.enabled = false;
        reset();
        return out;
    }
    // ON: the Uppers whose Sound had portamento, or all three when none had.
    bool any = false;
    for (int b : blend_) any = any || b == 1;
    for (std::size_t c = 0; c < 3; ++c) chOn_[c] = any ? blend_[c] == 1 : true;
    config_.enabled = true;
    return sync();
}

void Portamento::applyBlend(int ch, bool on) {
    if (ch < 0 || ch > 2) return;
    const auto c = static_cast<std::size_t>(ch);
    blend_[c] = on ? 1 : 0;
    chOn_[c] = on;
    resetChannel(ch);           // new Sound: its CC#5 is the Sound's, glide starts fresh
    bool any = false;
    for (bool b : chOn_) any = any || b;
    if (!config_.enabled && on) {
        // The app was OFF: only this Upper follows its Sound; the others stay off.
        for (std::size_t o = 0; o < 3; ++o) if (o != c) chOn_[o] = false;
        any = true;
    }
    config_.enabled = any;
}

bool Portamento::activeOn(int ch) const {
    if (ch < 0 || ch > 2) return false;
    return config_.enabled && chOn_[static_cast<std::size_t>(ch)];
}

int Portamento::activeMask() const {
    int m = 0;
    for (int ch = 0; ch < 3; ++ch) if (activeOn(ch)) m |= 1 << ch;
    return m;
}

int Portamento::blendState(int ch) const {
    if (ch < 0 || ch > 2) return -1;
    return blend_[static_cast<std::size_t>(ch)];
}

void Portamento::setTimeMs(int ms) {
    config_.timeMs = std::clamp(ms, kMinTimeMs, kMaxTimeMs);
}

std::vector<MidiMessage> Portamento::sync() const {
    std::vector<MidiMessage> out;
    if (!config_.enabled) return out;
    for (int ch = 0; ch < 3; ++ch) {
        const auto s = syncForChannel(ch);
        out.insert(out.end(), s.begin(), s.end());
    }
    return out;
}

std::vector<MidiMessage> Portamento::syncForChannel(int ch) const {
    if (!activeOn(ch)) return {};
    // Korg portamento ON; CC#5 follows per note. Re-send the last CC#5 too
    // (a Program Change may have reset it).
    std::vector<MidiMessage> out;
    const int cc = lastCc_[static_cast<std::size_t>(ch)];
    if (cc >= 0) out.push_back(MidiMessage::controlChange(ch, 5, cc));
    out.push_back(MidiMessage::controlChange(ch, 65, 127));
    return out;
}

int Portamento::lastNote(int ch) const {
    if (ch < 0 || ch > 2) return -1;
    return lastNote_[static_cast<std::size_t>(ch)];
}

void Portamento::reset() {
    lastNote_ = {{-1, -1, -1}};
    lastCc_ = {{-1, -1, -1}};
}

void Portamento::resetChannel(int ch) {
    if (ch < 0 || ch > 2) return;
    lastNote_[static_cast<std::size_t>(ch)] = -1;
    lastCc_[static_cast<std::size_t>(ch)] = -1;
}

} // namespace silveton
