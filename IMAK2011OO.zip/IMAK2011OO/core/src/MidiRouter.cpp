#include "silveton/MidiRouter.h"
#include <algorithm>
#include <cmath>
#include <cstddef>

namespace silveton {

MidiRouter::MidiRouter() {
    third_.clearGeneratedState();
}

void MidiRouter::appendRpnRange(std::vector<MidiMessage>& out, int ch, int semitones) {
    out.push_back(MidiMessage::controlChange(ch, 101, 0));
    out.push_back(MidiMessage::controlChange(ch, 100, 0));
    out.push_back(MidiMessage::controlChange(ch, 6, semitones));
    out.push_back(MidiMessage::controlChange(ch, 38, 0));
    out.push_back(MidiMessage::controlChange(ch, 101, 127));
    out.push_back(MidiMessage::controlChange(ch, 100, 127));
}

int MidiRouter::restoreRangeFor(int ch) const {
    const int learned = (ch >= 0 && ch < 3) ? learnedRange_[static_cast<std::size_t>(ch)] : -1;
    return learned >= 0 ? learned : 2;
}

void MidiRouter::syncRibbonRange(std::vector<MidiMessage>& out, bool emitBend, int maxWrites) {
    const bool engaged = pitchTransportEnabled_ && blendNative_ && ribbonUsesPitchBend();
    int writes = 0;
    rangeSyncPending_ = false;
    for (int ch = 0; ch < 3; ++ch) {
        const auto c = static_cast<std::size_t>(ch);
        const int blend = restoreRangeFor(ch);
        // Ribbon range law: while the Ribbon is in use the app SETS the range to
        //     R = B + Rr        (B = the blend's own range, Rr = Ribbon RANGE)
        // and composes Pitch Bend as 8192 * (w*B + s) / R, so the wheel gives
        // exactly w*B and the Ribbon exactly s, never clipped (|w*B + s| <= R).
        // R is always written by the app, never assumed; at rest R = B again.
        int want = -1;
        if (engaged) want = std::min(blend + ribbon_.rangeSemitones(), 24);
        if (want == ribbonRangeOn_[c]) continue;
        if (writes >= maxWrites) {        // the next poll continues from here
            rangeSyncPending_ = true;
            break;
        }
        ++writes;
        if (want > 0) {
            appendRpnRange(out, ch, want);
        } else {
            appendRpnRange(out, ch, blend);           // back to exactly the blend's value
        }
        ribbonRangeOn_[c] = want;
        pitch_.setTransportRange(ch, want);
        if (emitBend && pitchTransportEnabled_) append(out, pitch_.forceEmitChannel(ch));
    }
}

void MidiRouter::append(std::vector<MidiMessage>& dst, const std::vector<MidiMessage>& src) const {
    dst.insert(dst.end(), src.begin(), src.end());
}

void MidiRouter::clearActiveChannel(int ch) {
    if (ch < 0 || ch > 2) return;
    activeRefs_[static_cast<std::size_t>(ch)].fill(0);
    lastNotes_[static_cast<std::size_t>(ch)] = -1;
}

void MidiRouter::trackOutgoing(const MidiMessage& message) {
    const int ch = message.channel();
    if (ch < 0 || ch > 2) return;
    const std::size_t channel = static_cast<std::size_t>(ch);

    if (message.isNoteOn()) {
        const std::size_t note = static_cast<std::size_t>(message.data1 & 0x7F);
        auto& refs = activeRefs_[channel][note];
        if (refs < UINT16_MAX) ++refs;
        lastNotes_[channel] = static_cast<int>(message.data1);
        return;
    }

    if (message.isNoteOff()) {
        const std::size_t note = static_cast<std::size_t>(message.data1 & 0x7F);
        auto& refs = activeRefs_[channel][note];
        if (refs > 0) --refs;
        if (lastNotes_[channel] == static_cast<int>(message.data1) && refs == 0) {
            int replacement = -1;
            for (int candidate = 127; candidate >= 0; --candidate) {
                if (activeRefs_[channel][static_cast<std::size_t>(candidate)] != 0) {
                    replacement = candidate;
                    break;
                }
            }
            lastNotes_[channel] = replacement;
        }
        return;
    }

    if (message.isControlChange() && (message.data1 == 120 || message.data1 == 123)) {
        clearActiveChannel(ch);
    }
}

void MidiRouter::trackOutgoing(const std::vector<MidiMessage>& messages) {
    for (const auto& message : messages) trackOutgoing(message);
}

std::vector<MidiMessage> MidiRouter::releaseActiveChannel(int ch, bool addAllNotesOff) {
    std::vector<MidiMessage> out;
    if (ch < 0 || ch > 2) return out;
    const std::size_t channel = static_cast<std::size_t>(ch);

    for (int note = 0; note < 128; ++note) {
        const std::uint16_t refs = activeRefs_[channel][static_cast<std::size_t>(note)];
        for (std::uint16_t n = 0; n < refs; ++n) {
            out.push_back(MidiMessage::noteOffZero(ch, note));
        }
    }
    // Never cut the accompaniment the left hand is holding on this Upper.
    if (addAllNotesOff && !anyAccompanimentHeld(ch)) out.push_back(MidiMessage::controlChange(ch, 123, 0));
    clearActiveChannel(ch);
    return out;
}

bool MidiRouter::anyAccompanimentHeld(int ch) const {
    if (ch < 0 || ch > 2) return false;
    for (auto r : route_[static_cast<std::size_t>(ch)]) if (r == 1) return true;
    return false;
}

bool MidiRouter::routeAccompaniment(const MidiMessage& m, std::int64_t nowUs, std::vector<MidiMessage>& out) {
    const int ch = m.channel();
    if (ch < 0 || ch > 2) return false;
    const auto c = static_cast<std::size_t>(ch);
    if (m.isControlChange() && (m.data1 == 120 || m.data1 == 123)) {
        for (auto& r : route_[c]) if (r == 1) r = 0;
        return false;                       // the normal cleanup still runs
    }
    if (!m.isNoteOn() && !m.isNoteOff()) return false;
    const auto n = static_cast<std::size_t>(m.data1 & 0x7F);
    auto& route = route_[c][n];
    if (m.isNoteOn()) {
        // Learn this Upper's octave offset to U1: the PA600 sends one key on
        // every Upper within a millisecond or two, same velocity, whole octaves apart.
        const int note = m.data1;
        for (std::size_t o = 0; o < 3; ++o) {
            if (o == c) continue;
            const auto& lo = lastOn_[o];
            if (lo.note < 0 || lo.vel != m.data2 || nowUs - lo.us > 4000 || nowUs < lo.us) continue;
            const int d = note - lo.note;
            if (d % 12 != 0) continue;
            if (c == 0) octRel_[o] = std::clamp(-d / 12, -3, 3);
            else if (o == 0) octRel_[c] = std::clamp(d / 12, -3, 3);
        }
        lastOn_[c] = {note, m.data2, nowUs};
        if (route == 0) {
            const int key = note - 12 * (ch == 0 ? 0 : octRel_[c]);
            route = (splitNote_ > 0 && key < splitNote_) ? 1 : 2;
        }
        if (route != 1) return false;
        out.push_back(m);
        return true;
    }
    // Note Off: follows the route its Note On took.
    const bool raw = route == 1;
    route = 0;
    if (!raw) return false;
    out.push_back(m);
    return true;
}

std::vector<MidiMessage> MidiRouter::releaseAllActive(bool addAllNotesOff) {
    std::vector<MidiMessage> out;
    for (int ch = 0; ch < 3; ++ch) append(out, releaseActiveChannel(ch, addAllNotesOff));
    return out;
}

int MidiRouter::activeNoteRefs(int ch, int note) const {
    if (ch < 0 || ch > 2 || note < 0 || note > 127) return 0;
    return static_cast<int>(activeRefs_[static_cast<std::size_t>(ch)][static_cast<std::size_t>(note)]);
}

int MidiRouter::lastNote(int ch) const {
    if (ch < 0 || ch > 2) return -1;
    return lastNotes_[static_cast<std::size_t>(ch)];
}

void MidiRouter::syncU3Ownership() {
    const bool owned = third_.ownsRawUpper3();
    if (owned == u3Owned_) return;
    u3Owned_ = owned;
    // U3 switches between the raw line and the TERCA line: never glide across.
    portamento_.resetChannel(2);
}

void MidiRouter::startGlide(std::vector<MidiMessage>& out, int ch, int note) {
    if (!portamento_.activeOn(ch)) return;
    // Korg's own portamento glides; send the CC#5 that makes THIS interval
    // last exactly the set time, right before the note. No Pitch Bend.
    const int cc = portamento_.nativeCcForNote(ch, note);
    if (cc >= 0) out.push_back(MidiMessage::controlChange(ch, 5, cc));
}

std::vector<MidiMessage> MidiRouter::process(const MidiMessage& message, std::int64_t nowUs) {
    const int ch = message.channel();
    if (ch < 0 || !KorgProfile::isUpperChannel(ch)) {
        return {message};
    }

    // Accompaniment zone (below the split): returned exactly as played.
    {
        std::vector<MidiMessage> raw;
        if (routeAccompaniment(message, nowUs, raw)) return raw;
    }

    // Releases from a manually-cancelled scan are consumed individually. New
    // notes are immediately allowed again, so cancel really is immediate.
    if (third_.consumeCancelledScanRelease(message)) return {};

    const bool scanGateWasActive = third_.scanSilenceActive();
    if (scanGateWasActive) {
        const bool muteThisMessage = third_.shouldMuteScanMessage(message);
        third_.observeScan(message);
        if (muteThisMessage) {
            syncU3Ownership();          // a scan may have just locked TERCA
            return {};
        }
    }

    // Until Ribbon is actually used, physical Pitch Bend is a true byte-for-byte
    // pass-through.  Only after the Android layer explicitly enables the
    // +/-12 Ribbon transport do we compose physical bend with Ribbon.
    if (message.isPitchBend()) {
        if (!pitchTransportEnabled_) {
            // Keep the exact raw PA600 bend bytes transparent, but remember
            // the physical control position. If Ribbon is enabled later, the
            // coordinator can change to the +/-12 transport without a pitch
            // jump or falsely assuming the wheel is centered.
            pitch_.rememberManualBend14(ch, message.pitchBend14());
            return {message};
        }
        // Ribbon active: emit wheel + Ribbon as one composed value.
        auto out = pitch_.setManualBend14(ch, message.pitchBend14());
        trackOutgoing(out);
        return out;
    }

    // CC120/123 is authoritative cleanup. If the TERCA source Upper is killed,
    // the generated U3 notes are killed too because they belong to it.
    if (message.isControlChange() && (message.data1 == 120 || message.data1 == 123)) {
        std::vector<MidiMessage> out;
        if (ch == 2) third_.clearGeneratedState();
        portamento_.resetChannel(ch);
        clearMono(ch);
        out.push_back(message);
        // In the transparent bridge CC120/123 must not inject an
        // unrelated Pitch Bend. Only reset the composed pitch lane when the
        // Ribbon transport is actually active.
        if (pitchTransportEnabled_) append(out, pitch_.resetChannel(ch));
        trackOutgoing(out);
        return out;
    }

    // With a locked/enabled TERCA, raw U3 musical events are intentionally
    // suppressed; U3 is owned by generated harmony. When TERCA is OFF, U3 is
    // completely normal again.
    // MONO legato: notes on U1/U2/U3 are turned into a strictly monophonic
    // line per Upper (last-note priority, return to a still-held key) BEFORE
    // TERCA / portamento / bridging see them.
    // Automatic MONO: forced on while TIME portamento is ON (a Pitch Bend glide
    // bends every sounding note of the channel, so notes must never overlap),
    // and on the TERCA source while TERCA owns U3 (one clean line of thirds).
    // With both OFF every Upper stays exactly as the PA600 Sound plays it.
    const bool monoHere = monoEnabled_ || portamento_.activeOn(ch) ||
                          (ch == tercaSource() && third_.ownsRawUpper3());
    auto& activeFlag = monoActive_[static_cast<std::size_t>(ch)];
    if (monoHere != activeFlag) {
        clearMono(ch);          // never carry a stale key memory across a switch
        activeFlag = monoHere;
    }
    if (monoHere && (message.isNoteOn() || message.isNoteOff())) {
        std::vector<MidiMessage> out;
        for (const auto& ev : monoTransform(ch, message)) {
            append(out, processNote(ev));
        }
        return out;
    }
    return processNote(message);
}

std::vector<MidiMessage> MidiRouter::monoTransform(int ch, const MidiMessage& message) {
    std::vector<MidiMessage> events;
    auto& mono = mono_[static_cast<std::size_t>(ch)];
    const int note = message.data1;
    auto findHeld = [&](int n) {
        for (std::size_t i = 0; i < mono.held.size(); ++i) if (mono.held[i].first == n) return static_cast<int>(i);
        return -1;
    };

    if (message.isNoteOn()) {
        const int existing = findHeld(note);
        if (existing >= 0) mono.held.erase(mono.held.begin() + existing);
        mono.held.emplace_back(note, message.data2);
        if (mono.sounding == note) return events;           // same key again: keep it
        const int previous = mono.sounding;
        mono.sounding = note;
        // Legato order: new note first, then release the previous one.
        events.push_back(message);
        if (previous >= 0) events.push_back(MidiMessage::noteOffZero(ch, previous));
        return events;
    }

    // Note Off
    const int index = findHeld(note);
    if (index < 0) {
        // Not ours (pressed before MONO was switched on): pass it through so
        // nothing can ever hang.
        events.push_back(message);
        return events;
    }
    mono.held.erase(mono.held.begin() + index);
    if (mono.sounding != note) return events;                // a silent held key
    if (!mono.held.empty()) {
        const auto back = mono.held.back();
        mono.sounding = back.first;
        events.push_back(MidiMessage::noteOn(ch, back.first, back.second));
        events.push_back(message);
    } else {
        mono.sounding = -1;
        events.push_back(message);
    }
    return events;
}

void MidiRouter::clearMono(int ch) {
    if (ch < 0 || ch > 2) return;
    mono_[static_cast<std::size_t>(ch)] = MonoState{};
}

void MidiRouter::setMonoEnabled(bool enabled) {
    monoEnabled_ = enabled;
    for (int ch = 0; ch < 3; ++ch) clearMono(ch);
}

std::vector<MidiMessage> MidiRouter::processNote(const MidiMessage& message) {
    const int ch = message.channel();
    // Raw U3 keys are the TERCA source; they are consumed below and only their
    // thirds reach U3.

    std::vector<MidiMessage> out;

    // TIME portamento, per Upper: every Upper glides from ITS OWN incoming
    // notes (the PA600 sends the key separately on U1/U2/U3), so a muted or
    // untransmitted Upper never breaks another one. U3 uses the TERCA line while
    // TERCA owns it. The glide Pitch Bend is placed BEFORE the note so the note
    // already starts at the glide's start pitch.
    if (message.isNoteOn()) {
        if (ch != 2 || !third_.ownsRawUpper3()) {
            startGlide(out, ch, message.data1);
        }
    }

    const bool consumedAsSource = (ch == 2) && third_.isRawUpper3Musical(message);
    if (!consumedAsSource) out.push_back(message);

    if (ch == tercaSource()) {
        const auto harmony = third_.processSource(message);
        // U3 glides along its own line of thirds (C->D melody = E->F terca).
        if (third_.ownsRawUpper3()) {
            for (const auto& h : harmony) {
                if (h.isNoteOn()) startGlide(out, 2, h.data1);
            }
        }
        append(out, harmony);
        trackOutgoing(out);

        // Safety net: once the last key producing a third is released, U3
        // must be silent. Releasing everything still known on U3 plus CC123
        // guarantees no TERCA note can hang even if the PA600 missed a Note Off.
        if (message.isNoteOff() && third_.ownsRawUpper3() && !third_.anySourceHeld()) {
            auto sweep = releaseActiveChannel(2, true);
            third_.clearGeneratedState();
            append(out, sweep);
        }
        return out;
    }

    trackOutgoing(out);
    return out;
}

std::vector<MidiMessage> MidiRouter::poll(std::int64_t nowUs) {
    std::vector<MidiMessage> out;

    if (!pitchTransportEnabled_) return out;
    // Ribbon range writes spread over polls: one Upper per poll.
    if (rangeSyncPending_) syncRibbonRange(out, true, 1);

    const auto update = ribbonUsesPitchBend() ? ribbon_.advance(nowUs) : Ribbon::Update{};
    const bool ribbonMoving = ribbonUsesPitchBend() &&
        (ribbon_.touching() || ribbon_.currentSemitoneOffset() != ribbon_.targetSemitoneOffset());
    for (int ch = 0; ch < 3; ++ch) {
        const auto c = static_cast<std::size_t>(ch);
        if (update.valid) pitch_.storeRibbonSemitones(ch, update.semitones);
        // Rate-limit while something is moving; always send the settled value.
        if (ribbonMoving && nowUs - lastPbEmitUs_[c] < kPbIntervalUs) continue;
        // Ribbon moving: skip steps smaller than one cent (inaudible). The
        // settled value is always sent once the movement stops.
        if (ribbonMoving && pitch_.pendingChangeInaudible(ch)) continue;
        auto msgs = pitch_.emitChannel(ch);
        if (!msgs.empty()) {
            lastPbEmitUs_[c] = nowUs;
            append(out, msgs);
        }
    }

    trackOutgoing(out);
    return out;
}

std::vector<MidiMessage> MidiRouter::setPortamentoEnabled(bool enabled) {
    auto out = portamento_.setEnabled(enabled);
    trackOutgoing(out);
    return out;
}

std::vector<MidiMessage> MidiRouter::setPortamentoTimeMs(int ms) {
    portamento_.setTimeMs(ms);
    return {};
}

std::vector<MidiMessage> MidiRouter::syncPortamento() const {
    return portamento_.sync();
}

std::vector<MidiMessage> MidiRouter::syncPortamentoChannel(int ch) const {
    return portamento_.syncForChannel(ch);
}

std::vector<MidiMessage> MidiRouter::syncPitchChannel(int ch) {
    if (!pitchTransportEnabled_) return {};
    std::vector<MidiMessage> out;
    append(out, pitch_.forceEmitChannel(ch));
    return out;
}

std::vector<MidiMessage> MidiRouter::setPitchTransportEnabled(bool enabled) {
    if (pitchTransportEnabled_ == enabled) return {};
    pitchTransportEnabled_ = enabled;
    ribbon_.reset();

    std::vector<MidiMessage> out;
    // Ribbon's own range: raise RPN 0 on engage, restore the blend's on rest
    // (before any Pitch Bend in the new scale is sent). Engage writes one Upper
    // now and the others on the next polls; rest restores all at once (the
    // transport is off afterwards, so there are no polls to continue).
    syncRibbonRange(out, false, enabled ? 1 : 3);
    for (int ch = 0; ch < 3; ++ch) {
        // Preserve the remembered physical PA600 wheel position. Only the
        // Ribbon contribution is reset when switching transport modes.
        pitch_.clearRibbonContribution(ch);
        if (enabled) {
            append(out, pitch_.forceEmitChannel(ch));
        } else {
            // Back to the normal +/-2 transport (the Android layer restores
            // RPN 0 = 2 first): re-assert the raw physical wheel position.
            out.push_back(MidiMessage::pitchBend(ch, pitch_.manualBend14(ch)));
        }
    }
    trackOutgoing(out);
    return out;
}

std::vector<MidiMessage> MidiRouter::setThirdEnabled(bool enabled) {
    if (!enabled && third_.scanSilenceActive()) third_.cancelScan();
    if (third_.enabled() == enabled) return {};

    std::vector<MidiMessage> out;
    // U3 ownership changes are always made at a clean note boundary.
    if (third_.tonalityValid()) append(out, releaseActiveChannel(2, true));
    third_.clearGeneratedState();
    third_.setEnabled(enabled);
    syncU3Ownership();
    trackOutgoing(out);
    return out;
}

std::vector<MidiMessage> MidiRouter::setThirdScanning(bool scanning) {
    if (scanning) {
        if (third_.scanning()) return {};
        std::vector<MidiMessage> out = releaseAllActive(true);
        // SCAN swallows the releases of keys held right now, so MONO must not
        // remember them (it would later "return" to a key that is already up).
        for (int ch = 0; ch < 3; ++ch) clearMono(ch);
        third_.clearGeneratedState();
        third_.startScan();
        trackOutgoing(out);
        return out;
    }

    if (!third_.scanSilenceActive()) return {};
    third_.cancelScan();
    return {};
}

std::vector<MidiMessage> MidiRouter::ribbonMove(double normalizedPosition, std::int64_t nowUs) {
    ribbon_.setTarget(normalizedPosition, nowUs);
    return {};
}

std::vector<MidiMessage> MidiRouter::setBlendNative(bool enabled) {
    blendNative_ = enabled;
    std::vector<MidiMessage> out;
    for (int ch = 0; ch < 3; ++ch) {
        const int learned = learnedRange_[static_cast<std::size_t>(ch)];
        pitch_.setBlendRange(ch, enabled ? (learned >= 0 ? learned : 2) : -1);
        if (pitchTransportEnabled_) append(out, pitch_.forceEmitChannel(ch));
    }
    trackOutgoing(out);
    return out;
}

std::vector<MidiMessage> MidiRouter::observeReport(const MidiMessage& m, std::int64_t nowUs) {
    std::vector<MidiMessage> out;
    const int ch = m.channel();
    if (ch < 0 || ch > 2) return out;
    const auto c = static_cast<std::size_t>(ch);
    if ((m.status & 0xF0) == 0xC0) {
        // Sound selected on this Upper. The PA600 sends the Sound's portamento
        // switch (CC#65) right before the Program Change: follow it. A CC#65
        // older than the window is an echo of the app's own button, not a report.
        lastPcUs_[c] = nowUs;
        const auto pend = pendingPorta_[c];
        pendingPorta_[c] = -1;
        if (pend >= 0 && nowUs - pendingPortaUs_[c] <= kReportWindowUs) {
            // New Sound: its portamento starts fresh (no CC#5 from the old one).
            portamento_.applyBlend(ch, pend >= 64);
        }
        trackOutgoing(out);
        return out;
    }
    if (!m.isControlChange()) return out;
    if (m.data1 == 65) {
        pendingPorta_[c] = m.data2;
        pendingPortaUs_[c] = nowUs;
        return out;
    }
    if (m.data1 == 5) return out;   // the Sound's own portamento time: app keeps its TIME
    if (m.data1 == 101) { reportRpnMsb_[c] = m.data2; return out; }
    if (m.data1 == 100) { reportRpnLsb_[c] = m.data2; return out; }
    if (m.data1 == 6 && reportRpnMsb_[c] == 0 && reportRpnLsb_[c] == 0) {
        // RPN 0,0 = Pitch Bend Sensitivity. It is the blend's own range B only
        // when it follows a Sound selection (Program Change on this Upper within
        // the report window). The PA600's reset of all channels also reports
        // RPN 0 (log 2026-09-29 02:02: blend 1, reset said 2): that never
        // changes B.
        const bool soundChange = lastPcUs_[c] >= 0 && nowUs - lastPcUs_[c] <= kReportWindowUs;
        if (soundChange) learnedRange_[c] = std::clamp(static_cast<int>(m.data2), 0, 24);
        if (blendNative_) {
            if (soundChange) pitch_.setBlendRange(ch, learnedRange_[c]);
            // The PA600 has just set this channel's range itself: any Ribbon range
            // written before is gone; write it again if the Ribbon is in use.
            ribbonRangeOn_[c] = -1;
            pitch_.setTransportRange(ch, -1);
            syncRibbonRange(out, false);
            if (pitchTransportEnabled_) append(out, pitch_.forceEmitChannel(ch));
        }
    }
    trackOutgoing(out);
    return out;
}

std::vector<MidiMessage> MidiRouter::ribbonTouch(int action, double position, std::int64_t nowUs) {
    if (action == 0) ribbon_.touchDown(position, nowUs);
    else if (action == 1) ribbon_.touchMove(position, nowUs);
    else ribbon_.touchUp(nowUs);
    return {};
}

std::vector<MidiMessage> MidiRouter::setRibbonSettings(const Ribbon::Settings& settings) {
    std::vector<MidiMessage> out;
    const auto previous = ribbon_.settings().output;
    ribbon_.setSettings(settings);
    if (previous != ribbon_.settings().output) {
        // Switching destination: clear whatever the ribbon had applied before.
        for (int ch = 0; ch < 3; ++ch) {
            auto msgs = pitch_.setRibbonSemitones(ch, 0.0);
            if (pitchTransportEnabled_) append(out, msgs);
        }
        ribbon_.reset();
    }
    syncRibbonRange(out, true);   // RANGE or OUTPUT changed while the Ribbon is in use
    trackOutgoing(out);
    return out;
}

std::vector<MidiMessage> MidiRouter::ribbonReset() {
    std::vector<MidiMessage> out;
    ribbon_.reset();
    for (int ch = 0; ch < 3; ++ch) {
        auto msgs = pitch_.setRibbonSemitones(ch, 0.0);
        if (pitchTransportEnabled_) append(out, msgs);
    }
    trackOutgoing(out);
    return out;
}

std::vector<MidiMessage> MidiRouter::panic() {
    std::vector<MidiMessage> out = releaseAllActive(false);
    for (auto& r : route_) r.fill(0);
    for (int ch = 0; ch < 3; ++ch) {
        out.push_back(MidiMessage::controlChange(ch, 123, 0));
        out.push_back(MidiMessage::controlChange(ch, 120, 0));
        append(out, pitch_.resetChannel(ch));
    }

    third_.cancelScan();
    third_.clearGeneratedState();
    ribbon_.reset();
    portamento_.reset();
    for (int ch = 0; ch < 3; ++ch) clearMono(ch);
    pitch_.clearAll();
    pitchTransportEnabled_ = false;
    syncRibbonRange(out, false);   // a raised Ribbon range goes back to the blend's
    for (int ch = 0; ch < 3; ++ch) clearActiveChannel(ch);
    trackOutgoing(out);
    return out;
}

} // namespace silveton
