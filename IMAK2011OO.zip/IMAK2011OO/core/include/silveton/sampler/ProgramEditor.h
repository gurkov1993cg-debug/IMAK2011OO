#pragma once

#include "silveton/sampler/SamplerTypes.h"

#include <cstddef>
#include <string>

namespace silveton::sampler {

struct ProgramEditResult {
    ProgramPtr program;
    std::string error;
    [[nodiscard]] bool ok() const noexcept { return program != nullptr && error.empty(); }
};

class ProgramEditor {
public:
    static ProgramEditResult updateBasic(
        ProgramPtr source,
        bool mono,
        bool legato,
        float portamentoSec);

    static ProgramEditResult addLayer(
        ProgramPtr source,
        std::string name,
        MultisamplePtr multisample);

    static ProgramEditResult removeLayer(ProgramPtr source, std::size_t layerIndex);
    static ProgramEditResult moveLayer(ProgramPtr source, std::size_t fromIndex, std::size_t toIndex);

    static ProgramEditResult assignMultisample(
        ProgramPtr source,
        std::size_t layerIndex,
        MultisamplePtr multisample);

    static ProgramEditResult updateLayerBasic(
        ProgramPtr source,
        std::size_t layerIndex,
        bool enabled,
        int keyLow,
        int keyHigh,
        int velocityLow,
        int velocityHigh,
        int velocityFadeIn,
        int velocityFadeOut,
        int transposeSemitones,
        float tuneCents,
        float levelDb,
        float pan,
        float delaySec,
        bool damperEnabled);

    static ProgramEditResult updateLayerAmpEnvelope(
        ProgramPtr source,
        std::size_t layerIndex,
        const EnvelopeParams& envelope);

    static ProgramEditResult updateLayerPitch(
        ProgramPtr source,
        std::size_t layerIndex,
        float pitchEnvelopeCents,
        const EnvelopeParams& envelope);

    static ProgramEditResult updateLayerFilter(
        ProgramPtr source,
        std::size_t layerIndex,
        const FilterParams& filter,
        const EnvelopeParams& envelope);

    static ProgramEditResult updateLayerLfo(
        ProgramPtr source,
        std::size_t layerIndex,
        int lfoIndex,
        const LfoParams& lfo);
};

} // namespace silveton::sampler
