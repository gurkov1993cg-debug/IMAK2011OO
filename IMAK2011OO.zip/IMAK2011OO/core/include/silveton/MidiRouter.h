#pragma once
#include "silveton/KorgProfile.h"
#include "silveton/PitchCoordinator.h"
#include "silveton/Portamento.h"
#include "silveton/Ribbon.h"
#include "silveton/ThirdModule.h"
#include <array>
#include <cstdint>
#include <utility>
#include <vector>

namespace silveton {

class MidiRouter {
public:
    MidiRouter();

    Portamento& portamento() { return portamento_; }
    const Portamento& portamento() const { return portamento_; }
    void setPortamentoConfig(const Portamento::Config& config) { portamento_.setConfig(config); }

    ThirdModule& third() { return third_; }
    const ThirdModule& third() const { return third_; }

    Ribbon& ribbon() { return ribbon_; }
    const Ribbon& ribbon() const { return ribbon_; }

    // The PA600 runs with Local Control OFF and the app is the bridge: Upper
    // notes/controls are returned to the PA600 so it can sound them.
    // Upper whose keys drive TERCA: U3 itself.
    int tercaSource() const { return 2; }

    std::vector<MidiMessage> process(const MidiMessage& message, std::int64_t nowUs);

    // MONO legato for U1/U2/U3 (and therefore the TERCA line): a new key ends
    // the previous one; releasing it returns to the most recent held key.
    void setMonoEnabled(bool enabled);
    // Accompaniment zone: keys below this note (Upper 1 note numbers, e.g. 60 =
    // C4) are returned to the PA600 exactly as played — no MONO, TERCA, SCAN,
    // portamento or glide ever touches them. 0 = off (whole keyboard processed).
    // U2/U3 notes are mapped to the key via their octave offset to U1, learned
    // from the PA600 sending the same key on every Upper at the same moment.
    void setSplitNote(int note) { splitNote_ = note < 0 ? 0 : (note > 127 ? 127 : note); }
    int splitNote() const { return splitNote_; }
    int upperOctaveOffset(int ch) const { return (ch >= 0 && ch < 3) ? octRel_[static_cast<std::size_t>(ch)] : 0; }
    bool monoEnabled() const { return monoEnabled_; }
    std::vector<MidiMessage> poll(std::int64_t nowUs);
    std::vector<MidiMessage> panic();

    std::vector<MidiMessage> setPortamentoEnabled(bool enabled);
    std::vector<MidiMessage> setPortamentoTimeMs(int ms);
    std::vector<MidiMessage> syncPortamento() const;
    std::vector<MidiMessage> syncPortamentoChannel(int ch) const;
    std::vector<MidiMessage> syncPitchChannel(int ch);
    std::vector<MidiMessage> setPitchTransportEnabled(bool enabled);
    bool pitchTransportEnabled() const { return pitchTransportEnabled_; }

    std::vector<MidiMessage> setThirdEnabled(bool enabled);
    std::vector<MidiMessage> setThirdScanning(bool scanning);
    int thirdScanResult() const { return third_.scanResultCode(); }
    bool thirdScanning() const { return third_.scanning(); }

    std::vector<MidiMessage> ribbonMove(double normalizedPosition, std::int64_t nowUs);
    // Blend-native pitch (default in the app): the app NEVER writes the Pitch
    // Bend range; wheel and Ribbon are composed inside the range each Sound
    // has, learned from the RPN report the PA600 sends on every sound change.
    std::vector<MidiMessage> setBlendNative(bool enabled);
    bool blendNative() const { return blendNative_; }
    // A report from the PA600 (RPN CCs) that is not bridged: learn from it.
    // Reports the PA600 sends when a Sound is selected on an Upper: RPN 0
    // (Pitch Bend range), CC#65 (portamento switch) and the Program Change.
    std::vector<MidiMessage> observeReport(const MidiMessage& message, std::int64_t nowUs = 0);
    static constexpr std::int64_t kReportWindowUs = 150000;
    int learnedBendRange(int ch) const { return (ch >= 0 && ch < 3) ? learnedRange_[static_cast<std::size_t>(ch)] : -1; }

    // Touch interface: action 0 = down, 1 = move, 2 = up.
    std::vector<MidiMessage> ribbonTouch(int action, double position, std::int64_t nowUs);
    std::vector<MidiMessage> setRibbonSettings(const Ribbon::Settings& settings);
    // Continuous-data budget (MIDI bandwidth): notes are never delayed, but
    // Pitch Bend is sent at most every kPbIntervalUs per channel; the latest
    // value always wins and the final resting value is always sent.
    static constexpr std::int64_t kPbIntervalUs = 10000;      // <= 100 Hz per channel
    // Returns the ribbon to 0 on its current destination (PANIC).
    std::vector<MidiMessage> ribbonReset();
    bool ribbonUsesPitchBend() const { return ribbon_.settings().output == Ribbon::Output::PitchBend; }

    int activeNoteRefs(int ch, int note) const;
    int lastNote(int ch) const;

private:
    void append(std::vector<MidiMessage>& dst, const std::vector<MidiMessage>& src) const;
    void trackOutgoing(const MidiMessage& message);
    void trackOutgoing(const std::vector<MidiMessage>& messages);
    std::vector<MidiMessage> releaseActiveChannel(int ch, bool addAllNotesOff);
    std::vector<MidiMessage> releaseAllActive(bool addAllNotesOff);
    void clearActiveChannel(int ch);
    void startGlide(std::vector<MidiMessage>& out, int ch, int note);
    std::vector<MidiMessage> monoTransform(int ch, const MidiMessage& message);
    std::vector<MidiMessage> processNote(const MidiMessage& message);
    void clearMono(int ch);
    struct MonoState {
        std::vector<std::pair<int, int>> held; // (note, velocity) in press order
        int sounding{-1};
    };
    void syncU3Ownership();
    // Writes RPN 0 (Pitch Bend range) on one Upper, then closes the RPN.
    void appendRpnRange(std::vector<MidiMessage>& out, int ch, int semitones);

    Portamento portamento_{};
    ThirdModule third_{};
    Ribbon ribbon_{};
    PitchCoordinator pitch_{};
    bool pitchTransportEnabled_{false};
    bool u3Owned_{false};
    bool blendNative_{false};
    // Ribbon with its own range (independent of the blend's Pitch Bend range):
    // while the Ribbon transport is on, RPN 0 = max(Ribbon RANGE, blend range);
    // when it rests, RPN 0 goes back to exactly the blend's reported value.
    // maxWrites limits how many Uppers get their RPN 0 written in this call; the
    // rest follow on the next polls (one Upper per poll), so the PA600 never gets
    // one long burst. Each Upper switches scale exactly when its RPN is written.
    void syncRibbonRange(std::vector<MidiMessage>& out, bool emitBend, int maxWrites = 3);
    int restoreRangeFor(int ch) const;
    std::array<int, 3> ribbonRangeOn_{{-1, -1, -1}};
    bool rangeSyncPending_{false};   // some Uppers still wait for their RPN 0 write
    // Accompaniment zone.
    bool routeAccompaniment(const MidiMessage& message, std::int64_t nowUs, std::vector<MidiMessage>& out);
    bool anyAccompanimentHeld(int ch) const;
    int splitNote_{0};
    std::array<int, 3> octRel_{{0, 0, 0}};
    struct LastOn { int note{-1}; int vel{0}; std::int64_t us{0}; };
    std::array<LastOn, 3> lastOn_{};
    // Per incoming note: 0 = not held, 1 = accompaniment (raw), 2 = processed.
    std::array<std::array<std::uint8_t, 128>, 3> route_{};
    std::array<int, 3> pendingPorta_{{-1, -1, -1}};
    std::array<std::int64_t, 3> pendingPortaUs_{{0, 0, 0}};
    std::array<int, 3> learnedRange_{{-1, -1, -1}};
    std::array<std::int64_t, 3> lastPcUs_{{-1, -1, -1}};   // last Program Change report per Upper
    std::array<int, 3> reportRpnMsb_{{127, 127, 127}};
    std::array<int, 3> reportRpnLsb_{{127, 127, 127}};
    bool monoEnabled_{false};
    std::array<MonoState, 3> mono_{};
    std::array<bool, 3> monoActive_{{false, false, false}};
    std::array<std::int64_t, 3> lastPbEmitUs_{{0, 0, 0}};
public:
private:

    std::array<std::array<std::uint16_t, 128>, 3> activeRefs_{};
    std::array<int, 3> lastNotes_{{-1, -1, -1}};
};

} // namespace silveton
