// Differential test: silveton::fsx (the small POSIX replacement of std::filesystem used on the Mac) must give
// the same answers as the real std::filesystem for every call the sampler core makes.
#include "silveton/sampler/FsCompat.h"

#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <string>
#include <vector>

namespace fs = std::filesystem;
namespace fx = silveton::fsx;

static int gFailures = 0;

#define CHECK(cond) do { if (!(cond)) { std::fprintf(stderr, "FAILED %s:%d: %s\n", __FILE__, __LINE__, #cond); std::exit(1); } } while (0)
#define SAME(expr_a, expr_b) do { const auto a_ = (expr_a); const auto b_ = (expr_b); if (!(a_ == b_)) { std::fprintf(stderr, "DIFFERENT %s:%d: %s -> '%s' vs '%s'\n", __FILE__, __LINE__, #expr_a, std::string(a_).c_str(), std::string(b_).c_str()); ++gFailures; } } while (0)

int main() {
    const std::vector<std::string> samples = {
        "", "a", "a.b", "a.b.c", "/a", "/a/b", "/a/b/", "a/b/c.txt", "a//b", "/", ".", "..", "./a", "../a", "a/..", "a/./b",
        "/a/b/../c", "/a/../..", "x/y/../../..", ".hidden", "dir/.hidden", "dir/.hidden.txt", "dir/name.", "dir/", "a/b/", "SILVETON_SETS/My Set.SVSET",
        "/tmp/a.b/c", "archive.tar.gz", "/mnt/some dir/файл.wav", "a/b/c/d/e.f/g",
    };
    for (const auto& s : samples) {
        const fs::path p(s);
        const fx::path q(s);
        SAME(p.filename().string(), q.filename().string());
        SAME(p.extension().string(), q.extension().string());
        SAME(p.stem().string(), q.stem().string());
        SAME(p.parent_path().string(), q.parent_path().string());
        SAME(std::to_string(p.empty()), std::to_string(q.empty()));
        SAME(std::to_string(p.is_absolute()), std::to_string(q.is_absolute()));
        SAME(std::to_string(p.has_parent_path()), std::to_string(q.has_parent_path()));
        SAME(p.lexically_normal().string(), q.lexically_normal().string());
        for (const auto& t : samples) {
            SAME((p / fs::path(t)).string(), (q / fx::path(t)).string());
        }
    }

    // the real folder calls on a scratch folder
    char tmpl[] = "/tmp/imak-fsx-XXXXXX";
    CHECK(::mkdtemp(tmpl) != nullptr);
    const fx::path root(tmpl);
    CHECK(fx::is_directory(root));
    CHECK(!fx::exists(root / "nope"));
    CHECK(fx::create_directories(root / "a/b/c"));
    CHECK(!fx::create_directories(root / "a/b/c"));
    CHECK(fx::is_directory(root / "a/b"));
    { std::ofstream f((root / "a/b/c/file.txt").string()); f << "hello"; }
    CHECK(fx::is_regular_file(root / "a/b/c/file.txt"));
    CHECK(!fx::is_regular_file(root / "a/b"));
    CHECK(fx::copy_file(root / "a/b/c/file.txt", root / "a/copy.txt"));
    bool threw = false;
    try { fx::copy_file(root / "a/b/c/file.txt", root / "a/copy.txt"); } catch (const std::exception&) { threw = true; }
    CHECK(threw);                                         // existing target, no overwrite -> error (as std::filesystem)
    CHECK(fx::copy_file(root / "a/b/c/file.txt", root / "a/copy.txt", fx::copy_options::overwrite_existing));
    fx::rename(root / "a/copy.txt", root / "a/moved.txt");
    CHECK(!fx::exists(root / "a/copy.txt"));
    CHECK(fx::exists(root / "a/moved.txt"));
    CHECK(fx::remove(root / "a/moved.txt"));
    CHECK(!fx::remove(root / "a/moved.txt"));              // already gone -> false, no error
    std::error_code ec;
    const fx::path weak = fx::weakly_canonical(root / "a/b/../b/new/../x.txt", ec);
    CHECK(!ec);
    const fs::path realWeak = fs::weakly_canonical(fs::path((root / "a/b/../b/new/../x.txt").string()), ec);
    SAME(weak.string(), realWeak.string());
    CHECK(fx::remove_all(root) > 0U);
    CHECK(!fx::exists(root));
    CHECK(fx::remove_all(root) == 0U);

    if (gFailures != 0) { std::fprintf(stderr, "%d differences\n", gFailures); return 1; }
    std::puts("fsx tests passed");
    return 0;
}
