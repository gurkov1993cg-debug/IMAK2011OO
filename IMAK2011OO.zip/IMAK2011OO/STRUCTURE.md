# IMAK2011OO — SILVETON SAMPLER за Мак (iMac 2011, macOS High Sierra, Intel x86_64)

Същата програма като семплера в таблета, пренесена 1:1 на C++ за Мак. Работи със същите файлове:
`SILVETON_BANK.sv` (банката със звуците), `SILVETON_BLENDS.SVSET` (смесите, комбитата, ефектите), `SILVETON_SETS/<име>.SVSET`
(готовите сетове). При ЗАПАЗИ програмата пише тези файлове до банката, а таблетът ги чете и зарежда по същия начин.

Само частите, които са на таблета (root, Magisk, заключен изход за слушалки, Direct ALSA), са заменени:
звукът излиза през **CoreAudio**, а клавиатурата (Korg USB-MIDI) се чете през **CoreMIDI**.

## Папки

| Папка | Какво има вътре |
|---|---|
| `core/` | Звуковото ядро (семплер, гласове, ефекти, формат на банката/сетовете) — същият код като на таблета. `fsx` (FsCompat.h) заменя `std::filesystem`, който го няма в macOS 10.13. Тестове: `core/tests/` |
| `host/` | Мостът между екраните и ядрото (`NativeSamplerEngine`, `SamplerHost.cpp`) и двете „врати“: `host/src/mac/CoreAudioOutput.cpp` (звук) и `CoreMidiInput.cpp` (MIDI). На други системи (Linux тестовата машина) се ползва `DefaultIoOther.cpp`. |
| `ui/` | Рисуването и екраните. `Gfx.*` е програмен чертожник (Canvas/Paint/Path/Shader като на Android), `Fonts.cpp` + `resources/fonts` чертаят текста. `SilvetonSamplerView` са всички екрани (в отделни файлове `View_*.cpp`), `SamplerAppController` е управлението (банка, смеси, сетове, запазване). |
| `app/mac/main.mm` | Прозорецът на Мак (AppKit): показва картинката, предава мишката/клавиатурата/колелото и пуска часовника (60 пъти в секунда). |
| `resources/fonts` | Шрифтовете (Roboto, DejaVu — свободни лицензи), слагат се вътре в приложението. |
| `third_party/stb` | stb_truetype (общодостъпен, с една поправка за композитни букви). |

## Откъде е какво (файл на екрана → таблета `SilvetonSamplerView.kt`)

| Файл | Редове в таблета |
|---|---|
| `View_A.cpp` (състояние, докосване, кадър) | 1–700, 3476–3565 |
| `View_Side.cpp` (странична лента, горна лента) | 734–927 |
| `View_Combi.cpp` (КОМБИ) | 927–1700 |
| `View_Eq.cpp` (EQ, анализатор, избор на звук) | 1700–2051, 3263–3400 |
| `View_List.cpp` (СПИСЪК) | 2053–2333 |
| `View_Write.cpp` (WRITE / COPY / MOVE) | 2335–2580 |
| `View_Effects.cpp` (ЕФЕКТИ) | 2582–2721 |
| `View_Settings.cpp` (НАСТРОЙКИ, MIDI, ИНФО) | 2723–2928, 3388–3470 |
| `View_Dialogs.cpp` (прозорците) | 2932–3261 |
| `View_Kit.cpp` (чертожни помощници) | 3556–4141 |

Версията е последната на таблета (SET v14, MULTICORE + VOICE_CEILING). Лъковите инструменти (ЛЪК/BOW) ги няма в нея.

## Как се строи

На Мак (както прави GitHub): `cmake -S . -B build -G Xcode -DCMAKE_OSX_ARCHITECTURES=x86_64 -DCMAKE_OSX_DEPLOYMENT_TARGET=10.13`,
после `cmake --build build --config Release --target SILVETON_SAMPLER`. Тестовете: цел `imak_check` (строи и пуска всички).
На Linux (тестова машина, без приложението): `cmake -S . -B b -G Ninja -DIMAK_WERROR=ON && ninja -C b imak_check`.
Снимки на екраните: `b/ui/imak_ui_render resources/fonts <папка>`.

## Важно за кода

* Мак версията се строи БЕЗ `-Werror`; на Linux тестовата машина с `-Werror` (опция `IMAK_WERROR`).
* Рисуването е напълно програмно (един буфер от пиксели 0xAARRGGBB), за да изглежда еднакво навсякъде; на Мак буферът се показва с CoreGraphics.
* Екранът е 1340 × 800 единици и се мащабира еднакво към прозореца. Десен бутон (или Ctrl + клик) = „нулирай“.
