// The Mac's default doors: CoreAudio for the sound, CoreMIDI for the keyboard.
#if defined(__APPLE__)
#include "silveton/host/HostIo.h"

namespace silveton::host {

std::unique_ptr<AudioOutput> makeCoreAudioOutput();
std::unique_ptr<MidiInput> makeCoreMidiInput();

std::unique_ptr<AudioOutput> makeDefaultAudioOutput() { return makeCoreAudioOutput(); }
std::unique_ptr<MidiInput> makeDefaultMidiInput() { return makeCoreMidiInput(); }

} // namespace silveton::host
#endif
