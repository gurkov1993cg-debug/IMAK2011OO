// Tests of the Mac host: the doors (sound output / MIDI input) are replaced by the offline versions, so
// the whole chain  keyboard -> sampler -> sound  runs without any hardware.
#include "silveton/host/HostIo.h"
#include "silveton/host/NativeSamplerEngine.h"

#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <string>
#include <vector>

#include <sys/stat.h>
#include <unistd.h>

using namespace silveton::host;

#define CHECK(cond) do { if (!(cond)) { std::fprintf(stderr, "FAILED %s:%d: %s\n", __FILE__, __LINE__, #cond); std::exit(1); } } while (0)

namespace {

void put16(std::ofstream& f, std::uint16_t v) { f.put(static_cast<char>(v & 0xFFU)); f.put(static_cast<char>(v >> 8U)); }
void put32(std::ofstream& f, std::uint32_t v) { put16(f, static_cast<std::uint16_t>(v & 0xFFFFU)); put16(f, static_cast<std::uint16_t>(v >> 16U)); }

// 16-bit mono sine wave, 48 kHz, 1 second, with a loop-friendly whole number of periods (440 Hz).
void writeSineWav(const std::string& path) {
    const std::uint32_t rate = 48000U, frames = 48000U;
    std::ofstream f(path, std::ios::binary | std::ios::trunc);
    f.write("RIFF", 4); put32(f, 36U + frames * 2U); f.write("WAVEfmt ", 8);
    put32(f, 16U); put16(f, 1U); put16(f, 1U); put32(f, rate); put32(f, rate * 2U); put16(f, 2U); put16(f, 16U);
    f.write("data", 4); put32(f, frames * 2U);
    for (std::uint32_t i = 0U; i < frames; ++i) {
        const double v = 0.5 * std::sin(2.0 * 3.14159265358979323846 * 440.0 * static_cast<double>(i) / rate);
        put16(f, static_cast<std::uint16_t>(static_cast<std::int16_t>(std::lround(v * 32767.0))));
    }
}

double energy(const std::vector<float>& v) {
    double e = 0.0;
    for (const float x : v) e += static_cast<double>(x) * static_cast<double>(x);
    return e;
}

void testMidiParser() {
    MidiByteParser p;
    std::vector<std::vector<int>> got;
    auto sink = [&](std::uint8_t s, std::uint8_t a, std::uint8_t b) { got.push_back({s, a, b}); };
    // note on, running-status note on, a real-time clock byte in the middle, note off by velocity 0
    for (const std::uint8_t b : {0x90, 60, 100, 61, 0xF8, 90, 0x80, 60, 0}) p.feed(b, sink);
    CHECK(got.size() == 3U);
    CHECK((got[0] == std::vector<int>{0x90, 60, 100}));
    CHECK((got[1] == std::vector<int>{0x90, 61, 90}));
    CHECK((got[2] == std::vector<int>{0x80, 60, 0}));
    // SysEx is skipped completely, a one-byte message (program change) is complete after one data byte
    got.clear();
    for (const std::uint8_t b : {0xF0, 1, 2, 3, 0xF7, 0xC3, 5, 0xB0, 7, 100}) p.feed(b, sink);
    CHECK(got.size() == 2U);
    CHECK((got[0] == std::vector<int>{0xC3, 5, 0}));
    CHECK((got[1] == std::vector<int>{0xB0, 7, 100}));
    // stray data bytes with no status are ignored
    MidiByteParser q;
    got.clear();
    for (const std::uint8_t b : {1, 2, 3}) q.feed(b, sink);
    CHECK(got.empty());
}

void testChain() {
    char tmpl[] = "/tmp/imak-host-test-XXXXXX";
    CHECK(::mkdtemp(tmpl) != nullptr);
    const std::string dir = tmpl;
    const std::string wav = dir + "/sine.wav";
    writeSineWav(wav);

    NativeSamplerEngine native;
    auto audioOwned = std::make_unique<OfflineAudioOutput>(48000.0, 96U);
    auto midiOwned = std::make_unique<ManualMidiInput>();
    OfflineAudioOutput* audio = audioOwned.get();
    ManualMidiInput* midi = midiOwned.get();
    native.setBackends(std::move(audioOwned), std::move(midiOwned));

    CHECK(!native.nativeAudioNeedsRecovery());
    CHECK(native.nativeAudioOpen());
    CHECK(native.nativeAudioStart());
    CHECK(audio->running());
    const auto info = native.nativeAudioInfo();
    CHECK(info.size() == 7U);
    CHECK(info[0] == 48000);
    CHECK(info[1] == 96);
    CHECK(native.nativeLoadAudio(wav));

    // silence before any key
    CHECK(energy(audio->pump(4800)) < 1e-9);

    // key down -> sound
    midi->send(0x90, 69, 100);                       // A4 = the root of the sample
    const auto played = audio->pump(9600);
    CHECK(energy(played) > 1.0);
    for (const float x : played) CHECK(std::fabs(x) <= 1.0F);
    const auto meters = native.nativeMeters();
    CHECK(!meters.empty());
    CHECK(meters[0] > 0.01F || meters[1] > 0.01F);

    // key up through raw bytes -> the sound dies away
    midi->sendBytes({0x80, 69, 0});
    audio->pump(96000);
    CHECK(energy(audio->pump(4800)) < 1e-6);

    // the last MIDI message is remembered for the MIDI page
    const auto last = native.nativeMidiLastMessage();
    CHECK(last.size() == 3U);
    CHECK(last[0] == 0x80);

    // write the sound as a PROGRAM and a COMBI, save the whole set and read it back
    CHECK(native.nativeWriteProgram(0, 0, 0, 0, "TEST PROG"));
    CHECK(native.nativeWriteCombi(0, 0, 0, "TEST COMBI"));
    const std::string setPath = dir + "/test.SVSET";
    if (!native.nativeSaveSet(setPath)) std::fprintf(stderr, "save set: %s\n", native.nativeLastTextError().c_str());
    CHECK(native.nativeSaveSet(setPath));
    struct stat st{};
    CHECK(::stat(setPath.c_str(), &st) == 0 || ::stat((setPath + "/manifest.svs").c_str(), &st) == 0);
    CHECK(native.nativeLoadSet(setPath));
    midi->send(0x90, 69, 100);
    CHECK(energy(audio->pump(9600)) > 1.0);
    midi->send(0xB0, 123, 0);                        // all notes off
    midi->send(0xB0, 120, 0);                        // all sound off
    audio->pump(9600);

    // stop / start / close behave
    native.nativeAudioStop();
    CHECK(!audio->running());
    CHECK(native.nativeAudioStart());
    native.nativeAudioClose();
    CHECK(!audio->running());
    CHECK(native.nativeAudioInfo()[0] == 0);
    CHECK(native.nativeAudioRecover());              // nothing to recover
    CHECK(native.nativeAudioOpen());
    CHECK(native.nativeAudioStart());
    native.nativeAudioClose();

    std::string cmd = "rm -rf '" + dir + "'";
    CHECK(std::system(cmd.c_str()) == 0);
}

void testNoBackendsFallsBackToSilentDevices() {
    NativeSamplerEngine native;
    CHECK(native.nativeAudioOpen());                 // the platform default on Linux: silent offline output
    CHECK(native.nativeAudioStart());
    native.nativeAudioClose();
}

} // namespace

int main() {
    testMidiParser();
    testChain();
    testNoBackendsFallsBackToSilentDevices();
    std::puts("host tests passed");
    return 0;
}
