// SILVETON_MAC_APP_V1 - the window of the SILVETON SAMPLER on the Mac.
// It only does what a window has to do: shows the picture the screens draw (SilvetonSamplerView), hands the mouse, the
// keyboard and the scroll wheel to it, and runs the clock. Sound comes from CoreAudio, the keyboard from CoreMIDI (host/).
#import <Cocoa/Cocoa.h>

#include "silveton/host/HostIo.h"
#include "silveton/ui/Gfx.h"
#include "silveton/ui/SamplerAppController.h"
#include "silveton/ui/SilvetonSamplerView.h"
#include "silveton/ui/Support.h"

#include <atomic>
#include <memory>
#include <string>
#include <vector>

using silveton::ui::Canvas;
using silveton::ui::ControllerEnv;
using silveton::ui::SamplerAppController;
using silveton::ui::SilvetonSamplerView;

static const CGFloat kDesignWidth = 1340.0;
static const CGFloat kDesignHeight = 800.0;

static std::string toStd(NSString* s) { return s != nil ? std::string([s UTF8String]) : std::string(); }
static NSString* toNS(const std::string& s) { return [NSString stringWithUTF8String:s.c_str()]; }

// ---------------------------------------------------------------------------------------------------- the picture
@interface SilvetonPictureView : NSView {
    SilvetonSamplerView* screens_;               // not owned
    std::unique_ptr<Canvas> canvas_;
}
- (instancetype)initWithFrame:(NSRect)frame screens:(SilvetonSamplerView*)screens;
- (void)clockTick;
@end

@implementation SilvetonPictureView

- (instancetype)initWithFrame:(NSRect)frame screens:(SilvetonSamplerView*)screens {
    self = [super initWithFrame:frame];
    if (self != nil) {
        screens_ = screens;
    }
    return self;
}

- (BOOL)isOpaque { return YES; }
- (BOOL)acceptsFirstResponder { return YES; }
- (BOOL)acceptsFirstMouse:(NSEvent*)event { (void)event; return YES; }
- (NSMenu*)menuForEvent:(NSEvent*)event { (void)event; return nil; }   // the right button is the "reset" of a control

// picture pixels (origin top left), the same pixels the canvas has
- (NSPoint)picturePoint:(NSEvent*)event {
    const NSPoint inView = [self convertPoint:[event locationInWindow] fromView:nil];
    const NSPoint backing = [self convertPointToBacking:inView];
    const NSRect bounds = [self convertRectToBacking:[self bounds]];
    return NSMakePoint(backing.x, bounds.size.height - backing.y);
}

- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    const NSRect backing = [self convertRectToBacking:[self bounds]];
    const int w = static_cast<int>(backing.size.width + 0.5);
    const int h = static_cast<int>(backing.size.height + 0.5);
    if (w <= 0 || h <= 0) return;
    if (!canvas_ || canvas_->width() != w || canvas_->height() != h) canvas_ = std::make_unique<Canvas>(w, h);
    screens_->draw(*canvas_);

    CGContextRef context = [[NSGraphicsContext currentContext] CGContext];
    CGColorSpaceRef space = CGColorSpaceCreateDeviceRGB();
    CGDataProviderRef provider = CGDataProviderCreateWithData(NULL, canvas_->pixels(), static_cast<size_t>(w) * static_cast<size_t>(h) * 4U, NULL);
    CGImageRef image = CGImageCreate(static_cast<size_t>(w), static_cast<size_t>(h), 8, 32, static_cast<size_t>(w) * 4U, space,
                                     static_cast<CGBitmapInfo>(kCGBitmapByteOrder32Little | kCGImageAlphaNoneSkipFirst), provider, NULL, false, kCGRenderingIntentDefault);
    if (image != NULL) {
        CGContextSetInterpolationQuality(context, kCGInterpolationNone);
        CGContextDrawImage(context, NSRectToCGRect([self bounds]), image);
        CGImageRelease(image);
    }
    CGDataProviderRelease(provider);
    CGColorSpaceRelease(space);
}

// ---- the clock (about 60 times a second)
- (void)clockTick {
    const std::int64_t now = silveton::ui::nowMs();
    screens_->tick(now);
    if (screens_->redrawDue(now)) [self setNeedsDisplay:YES];
}

// ---- mouse
- (void)mouseDown:(NSEvent*)event {
    const NSPoint p = [self picturePoint:event];
    if (([event modifierFlags] & NSEventModifierFlagControl) != 0) {   // Ctrl + click = the right button
        screens_->secondaryClick(static_cast<float>(p.x), static_cast<float>(p.y));
    } else {
        screens_->pointer(SilvetonSamplerView::PointerAction::Down, static_cast<float>(p.x), static_cast<float>(p.y));
    }
    [self setNeedsDisplay:YES];
}

- (void)mouseDragged:(NSEvent*)event {
    if (([event modifierFlags] & NSEventModifierFlagControl) != 0) return;
    const NSPoint p = [self picturePoint:event];
    screens_->pointer(SilvetonSamplerView::PointerAction::Move, static_cast<float>(p.x), static_cast<float>(p.y));
    [self setNeedsDisplay:YES];
}

- (void)mouseUp:(NSEvent*)event {
    const NSPoint p = [self picturePoint:event];
    if (([event modifierFlags] & NSEventModifierFlagControl) != 0) {
        screens_->pointer(SilvetonSamplerView::PointerAction::Cancel, static_cast<float>(p.x), static_cast<float>(p.y));
    } else {
        screens_->pointer(SilvetonSamplerView::PointerAction::Up, static_cast<float>(p.x), static_cast<float>(p.y));
    }
    [self setNeedsDisplay:YES];
}

- (void)rightMouseDown:(NSEvent*)event {
    const NSPoint p = [self picturePoint:event];
    screens_->secondaryClick(static_cast<float>(p.x), static_cast<float>(p.y));
    [self setNeedsDisplay:YES];
}

- (void)rightMouseUp:(NSEvent*)event { (void)event; }
- (void)rightMouseDragged:(NSEvent*)event { (void)event; }

- (void)scrollWheel:(NSEvent*)event {
    const NSPoint p = [self picturePoint:event];
    // a notch of a mouse wheel = one step; a finger on the trackpad = the distance it moved (in picture pixels)
    const CGFloat scale = [self convertSizeToBacking:NSMakeSize(1.0, 1.0)].height;
    const CGFloat dy = [event hasPreciseScrollingDeltas] ? -[event scrollingDeltaY] * scale : -[event deltaY] * 24.0;
    screens_->wheel(static_cast<float>(p.x), static_cast<float>(p.y), static_cast<float>(dy));
    [self setNeedsDisplay:YES];
}

// ---- keyboard (the text and number pages)
- (void)keyDown:(NSEvent*)event {
    SilvetonSamplerView::Key key = SilvetonSamplerView::Key::None;
    switch ([event keyCode]) {
        case 36: case 76: key = SilvetonSamplerView::Key::Enter; break;       // Return, keypad Enter
        case 53: key = SilvetonSamplerView::Key::Escape; break;
        case 51: key = SilvetonSamplerView::Key::Backspace; break;
        case 117: key = SilvetonSamplerView::Key::Delete; break;
        case 123: key = SilvetonSamplerView::Key::Left; break;
        case 124: key = SilvetonSamplerView::Key::Right; break;
        case 125: key = SilvetonSamplerView::Key::Down; break;
        case 126: key = SilvetonSamplerView::Key::Up; break;
        case 48: key = SilvetonSamplerView::Key::Tab; break;
        default: break;
    }
    if (key != SilvetonSamplerView::Key::None) {
        screens_->keyDown(key);
    } else if (([event modifierFlags] & (NSEventModifierFlagCommand | NSEventModifierFlagControl)) == 0) {
        [self interpretKeyEvents:[NSArray arrayWithObject:event]];   // letters (also Cyrillic and accents) arrive in insertText:
    }
    [self setNeedsDisplay:YES];
}

- (void)insertText:(id)text {
    NSString* s = [text isKindOfClass:[NSAttributedString class]] ? [(NSAttributedString*)text string] : (NSString*)text;
    screens_->typeText(toStd(s));
}

- (void)doCommandBySelector:(SEL)selector { (void)selector; }   // keys that are no letters are handled in keyDown:

@end

// ---------------------------------------------------------------------------------------------------- the program
@interface SilvetonAppDelegate : NSObject <NSApplicationDelegate> {
    std::unique_ptr<SamplerAppController> controller_;
    std::unique_ptr<SilvetonSamplerView> screens_;
    std::shared_ptr<std::atomic<SilvetonSamplerView*>> screensCell_;   // the sound threads reach the screens only through this
    NSWindow* window_;
    SilvetonPictureView* picture_;
    NSTimer* clock_;
    id<NSObject> activity_;
    dispatch_queue_t lifecycle_;
}
@end

@implementation SilvetonAppDelegate

- (NSString*)documentsFolder {
    NSArray* dirs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    return dirs.count > 0 ? [dirs objectAtIndex:0] : [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
}

- (void)applicationDidFinishLaunching:(NSNotification*)notification {
    (void)notification;
    NSString* resources = [[NSBundle mainBundle] resourcePath];
    silveton::ui::setFontDirectory(toStd([resources stringByAppendingPathComponent:@"fonts"]));

    // where the program keeps its own small files
    NSString* support = [NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES) firstObject];
    NSString* dataDir = [support stringByAppendingPathComponent:@"SILVETON SAMPLER"];
    [[NSFileManager defaultManager] createDirectoryAtPath:dataDir withIntermediateDirectories:YES attributes:nil error:nil];

    // where SILVETON_BANK.sv may be (the first one found wins; File > Choose bank... remembers another place)
    NSString* home = NSHomeDirectory();
    NSString* documents = [self documentsFolder];
    ControllerEnv env;
    env.dataDir = toStd(dataDir);
    for (NSString* folder in @[[documents stringByAppendingPathComponent:@"SILVETON"], [home stringByAppendingPathComponent:@"SILVETON"], documents,
                               [home stringByAppendingPathComponent:@"Downloads"], [home stringByAppendingPathComponent:@"Desktop"]]) {
        env.bankCandidates.push_back(toStd([folder stringByAppendingPathComponent:@"SILVETON_BANK.sv"]));
    }
    screensCell_ = std::make_shared<std::atomic<SilvetonSamplerView*>>(nullptr);
    const auto cell = screensCell_;
    env.statusChanged = [cell](const std::string& message) {
        if (SilvetonSamplerView* v = cell->load()) v->setWarning(message);
    };
    env.midiConnectionChanged = [cell](int count) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (SilvetonSamplerView* v = cell->load()) v->setMidiConnections(count);
        });
    };
    controller_ = std::make_unique<SamplerAppController>(env);
    screens_ = std::make_unique<SilvetonSamplerView>(*controller_);
    screensCell_->store(screens_.get());

    // the window: the picture is 1340 x 800 and keeps its shape
    NSRect visible = [[NSScreen mainScreen] visibleFrame];
    CGFloat scale = 1.0;
    if (visible.size.width * 0.96 < kDesignWidth || visible.size.height * 0.96 < kDesignHeight) {
        scale = MIN(visible.size.width * 0.96 / kDesignWidth, visible.size.height * 0.96 / kDesignHeight);
    }
    const NSRect content = NSMakeRect(0, 0, kDesignWidth * scale, kDesignHeight * scale);
    window_ = [[NSWindow alloc] initWithContentRect:content
                                          styleMask:(NSWindowStyleMaskTitled | NSWindowStyleMaskClosable | NSWindowStyleMaskMiniaturizable | NSWindowStyleMaskResizable)
                                            backing:NSBackingStoreBuffered
                                              defer:NO];
    [window_ setTitle:@"SILVETON SAMPLER"];
    [window_ setReleasedWhenClosed:NO];
    [window_ setContentAspectRatio:NSMakeSize(kDesignWidth, kDesignHeight)];
    [window_ setContentMinSize:NSMakeSize(kDesignWidth * 0.5, kDesignHeight * 0.5)];
    [window_ setBackgroundColor:[NSColor blackColor]];
    picture_ = [[SilvetonPictureView alloc] initWithFrame:content screens:screens_.get()];
    [picture_ setAutoresizingMask:(NSViewWidthSizable | NSViewHeightSizable)];
    [window_ setContentView:picture_];
    [window_ makeFirstResponder:picture_];
    [window_ center];
    [window_ makeKeyAndOrderFront:nil];

    // the sound must never be slowed down by the system's power saving
    activity_ = [[NSProcessInfo processInfo] beginActivityWithOptions:(NSActivityUserInitiatedAllowingIdleSystemSleep | NSActivityLatencyCritical)
                                                               reason:@"SILVETON SAMPLER plays sound and listens to MIDI"];

    // the sound starts on its own thread, like the tablet's audio lifecycle
    lifecycle_ = dispatch_queue_create("SilvetonAudioLifecycle", DISPATCH_QUEUE_SERIAL);
    SamplerAppController* controller = controller_.get();
    dispatch_async(lifecycle_, ^{ controller->start(); });

    clock_ = [NSTimer timerWithTimeInterval:(1.0 / 60.0) target:self selector:@selector(clockTick:) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:clock_ forMode:NSRunLoopCommonModes];
}

- (void)clockTick:(NSTimer*)timer {
    (void)timer;
    controller_->housekeeping();
    [picture_ clockTick];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication*)sender { (void)sender; return YES; }

- (void)applicationWillTerminate:(NSNotification*)notification {
    (void)notification;
    [clock_ invalidate];
    if (screensCell_) screensCell_->store(nullptr);
    if (controller_) controller_->close();
    if (activity_ != nil) [[NSProcessInfo processInfo] endActivity:activity_];
}

// File > Choose bank...
- (void)chooseBank:(id)sender {
    (void)sender;
    NSOpenPanel* panel = [NSOpenPanel openPanel];
    [panel setMessage:@"Избери файла SILVETON_BANK.sv"];
    [panel setPrompt:@"Избери"];
    [panel setCanChooseFiles:YES];
    [panel setCanChooseDirectories:NO];
    [panel setAllowsMultipleSelection:NO];
    [panel beginSheetModalForWindow:window_ completionHandler:^(NSModalResponse result) {
        if (result != NSModalResponseOK || [[panel URLs] count] == 0) return;
        const std::string path = toStd([[[panel URLs] objectAtIndex:0] path]);
        SamplerAppController* controller = self->controller_.get();
        dispatch_async(self->lifecycle_, ^{ controller->useBankFile(path); });   // the screens read everything again when it is ready
    }];
}

@end

// ---------------------------------------------------------------------------------------------------- menu and main
static NSMenuItem* addItem(NSMenu* menu, NSString* title, SEL action, NSString* key, id target) {
    NSMenuItem* item = [menu addItemWithTitle:title action:action keyEquivalent:key];
    if (target != nil) [item setTarget:target];
    return item;
}

static void buildMenu(SilvetonAppDelegate* delegate) {
    NSMenu* bar = [[NSMenu alloc] init];

    NSMenuItem* appItem = [[NSMenuItem alloc] init];
    [bar addItem:appItem];
    NSMenu* appMenu = [[NSMenu alloc] initWithTitle:@"SILVETON SAMPLER"];
    addItem(appMenu, @"За SILVETON SAMPLER", @selector(orderFrontStandardAboutPanel:), @"", nil);
    [appMenu addItem:[NSMenuItem separatorItem]];
    addItem(appMenu, @"Скрий SILVETON SAMPLER", @selector(hide:), @"h", nil);
    [appMenu addItem:[NSMenuItem separatorItem]];
    addItem(appMenu, @"Изход от SILVETON SAMPLER", @selector(terminate:), @"q", nil);
    [appItem setSubmenu:appMenu];

    NSMenuItem* fileItem = [[NSMenuItem alloc] init];
    [bar addItem:fileItem];
    NSMenu* fileMenu = [[NSMenu alloc] initWithTitle:@"Файл"];
    addItem(fileMenu, @"Избери банка (SILVETON_BANK.sv)…", @selector(chooseBank:), @"o", delegate);
    [fileItem setSubmenu:fileMenu];

    NSMenuItem* windowItem = [[NSMenuItem alloc] init];
    [bar addItem:windowItem];
    NSMenu* windowMenu = [[NSMenu alloc] initWithTitle:@"Прозорец"];
    addItem(windowMenu, @"Минимизирай", @selector(performMiniaturize:), @"m", nil);
    addItem(windowMenu, @"Увеличи", @selector(performZoom:), @"", nil);
    [windowItem setSubmenu:windowMenu];

    [NSApp setMainMenu:bar];
    [NSApp setWindowsMenu:windowMenu];
}

int main(int argc, const char* argv[]) {
    (void)argc;
    (void)argv;
    @autoreleasepool {
        NSApplication* app = [NSApplication sharedApplication];
        [app setActivationPolicy:NSApplicationActivationPolicyRegular];
        SilvetonAppDelegate* delegate = [[SilvetonAppDelegate alloc] init];
        [app setDelegate:delegate];
        buildMenu(delegate);
        [app activateIgnoringOtherApps:YES];
        [app run];
    }
    return 0;
}
