// SILVETON_MAC_GFX_V1 - the software renderer behind Canvas / Paint / Path / Shader (see Gfx.h).
#include "silveton/ui/Gfx.h"

#include "FontInternal.h"

#include <cstring>
#include <limits>

#if defined(__SSE2__)
#include <emmintrin.h>
#endif

namespace silveton::ui {
namespace {

constexpr float kPi = 3.14159265358979323846F;

inline int div255(int x) noexcept { return (x + 128 + ((x + 128) >> 8)) >> 8; }

inline std::uint32_t premultiply(ColorInt c) noexcept {
    const int a = Color::alpha(c);
    if (a == 255) return c;
    if (a == 0) return 0U;
    const int r = div255(Color::red(c) * a);
    const int g = div255(Color::green(c) * a);
    const int b = div255(Color::blue(c) * a);
    return (static_cast<std::uint32_t>(a) << 24U) | (static_cast<std::uint32_t>(r) << 16U) | (static_cast<std::uint32_t>(g) << 8U) | static_cast<std::uint32_t>(b);
}

// two 8-bit values (bits 0-7 and 16-23) times k, divided by 255 with rounding - the same result as div255 for each of them
inline std::uint32_t mulDiv255x2(std::uint32_t x, std::uint32_t k) noexcept {
    const std::uint32_t v = x * k + 0x00800080U;
    return ((v + ((v >> 8) & 0x00FF00FFU)) >> 8) & 0x00FF00FFU;
}

// scale every channel of a premultiplied colour by k/255
inline std::uint32_t scalePremul(std::uint32_t c, int k) noexcept {
    if (k >= 255) return c;
    if (k <= 0) return 0U;
    const auto kk = static_cast<std::uint32_t>(k);
    return mulDiv255x2(c & 0x00FF00FFU, kk) | (mulDiv255x2((c >> 8) & 0x00FF00FFU, kk) << 8U);
}

// per-channel addition that stops at 255
inline std::uint32_t addSaturated(std::uint32_t a, std::uint32_t b) noexcept {
    const std::uint32_t low = (a & 0x7F7F7F7FU) + (b & 0x7F7F7F7FU);
    const std::uint32_t sum = ((a ^ b) & 0x80808080U) ^ low;                        // the sum of every channel modulo 256
    const std::uint32_t carry = ((a & b) | ((a | b) & ~sum)) & 0x80808080U;         // channels that went beyond 255
    return sum | ((carry >> 7U) * 255U);
}

// source (already premultiplied) over destination
inline std::uint32_t over(std::uint32_t dst, std::uint32_t src) noexcept {
    const std::uint32_t sa = src >> 24U;
    if (sa == 255U) return src;
    if (sa == 0U) return dst;
    const std::uint32_t inv = 255U - sa;
    const std::uint32_t scaled = mulDiv255x2(dst & 0x00FF00FFU, inv) | (mulDiv255x2((dst >> 8U) & 0x00FF00FFU, inv) << 8U);
    return addSaturated(scaled, src);
}

// one translucent colour over a run of pixels (the same arithmetic as over(), four pixels at a time where the CPU can)
inline void overSolidRun(std::uint32_t* p, int n, std::uint32_t src) noexcept {
    int i = 0;
#if defined(__SSE2__)
    const std::uint32_t inv = 255U - (src >> 24U);
    const __m128i zero = _mm_setzero_si128();
    const __m128i vinv = _mm_set1_epi16(static_cast<short>(inv));
    const __m128i round = _mm_set1_epi16(0x80);
    const __m128i vsrc = _mm_set1_epi32(static_cast<int>(src));
    for (; i + 4 <= n; i += 4) {
        const __m128i d = _mm_loadu_si128(reinterpret_cast<const __m128i*>(p + i));
        __m128i lo = _mm_add_epi16(_mm_mullo_epi16(_mm_unpacklo_epi8(d, zero), vinv), round);
        __m128i hi = _mm_add_epi16(_mm_mullo_epi16(_mm_unpackhi_epi8(d, zero), vinv), round);
        lo = _mm_srli_epi16(_mm_add_epi16(lo, _mm_srli_epi16(lo, 8)), 8);
        hi = _mm_srli_epi16(_mm_add_epi16(hi, _mm_srli_epi16(hi, 8)), 8);
        _mm_storeu_si128(reinterpret_cast<__m128i*>(p + i), _mm_adds_epu8(_mm_packus_epi16(lo, hi), vsrc));
    }
#endif
    for (; i < n; ++i) p[i] = over(p[i], src);
}

float signedArea(const std::vector<float>& xy) {
    double a = 0.0;
    const std::size_t n = xy.size() / 2U;
    for (std::size_t i = 0U; i < n; ++i) {
        const std::size_t j = (i + 1U) % n;
        a += static_cast<double>(xy[2U * i]) * static_cast<double>(xy[2U * j + 1U]) - static_cast<double>(xy[2U * j]) * static_cast<double>(xy[2U * i + 1U]);
    }
    return static_cast<float>(a * 0.5);
}

void reversePoly(std::vector<float>& xy) {
    const std::size_t n = xy.size() / 2U;
    for (std::size_t i = 0U; i < n / 2U; ++i) {
        std::swap(xy[2U * i], xy[2U * (n - 1U - i)]);
        std::swap(xy[2U * i + 1U], xy[2U * (n - 1U - i) + 1U]);
    }
}

// ---------------------------------------------------------------- coverage accumulation (exact area, nonzero-ish)
// a: accumulation buffer (w+2 columns, h rows). The edge is already in buffer coordinates.
void accumulateLine(float* a, int stride, int /*w*/, int h, float x0, float y0, float x1, float y1) {
    if (y0 == y1) return;
    float dir = 1.0F;
    if (y0 > y1) { std::swap(x0, x1); std::swap(y0, y1); dir = -1.0F; }
    if (y1 <= 0.0F || y0 >= static_cast<float>(h)) return;
    const float dxdy = (x1 - x0) / (y1 - y0);
    float x = x0;
    if (y0 < 0.0F) x -= y0 * dxdy;
    const int yStart = std::max(0, static_cast<int>(std::floor(y0)));
    const int yEnd = std::min(h, static_cast<int>(std::ceil(y1)));
    for (int y = yStart; y < yEnd; ++y) {
        float* row = a + static_cast<std::ptrdiff_t>(y) * stride;
        const float dy = std::min(static_cast<float>(y + 1), y1) - std::max(static_cast<float>(y), y0);
        const float xnext = x + dxdy * dy;
        const float d = dy * dir;
        const float xa = std::min(x, xnext);
        const float xb = std::max(x, xnext);
        const float x0floor = std::floor(xa);
        const int x0i = static_cast<int>(x0floor);
        const float x1ceil = std::ceil(xb);
        const int x1i = static_cast<int>(x1ceil);
        if (x1i <= x0i + 1) {
            const float xmf = 0.5F * (x + xnext) - x0floor;
            row[x0i] += d - d * xmf;
            row[x0i + 1] += d * xmf;
        } else {
            const float s = 1.0F / (xb - xa);
            const float x0f = xa - x0floor;
            const float a0 = 0.5F * s * (1.0F - x0f) * (1.0F - x0f);
            const float x1f = xb - x1ceil + 1.0F;
            const float am = 0.5F * s * x1f * x1f;
            row[x0i] += d * a0;
            if (x1i == x0i + 2) {
                row[x0i + 1] += d * (1.0F - a0 - am);
            } else {
                const float a1 = s * (1.5F - x0f);
                row[x0i + 1] += d * (a1 - a0);
                for (int xi = x0i + 2; xi < x1i - 1; ++xi) row[xi] += d * s;
                const float a2 = a1 + static_cast<float>(x1i - x0i - 3) * s;
                row[x1i - 1] += d * (1.0F - a2 - am);
            }
            row[x1i] += d * am;
        }
        x = xnext;
    }
}

// Clips the edge sideways to the buffer (outside parts become vertical lines on the border) and accumulates it.
void accumulateEdge(float* a, int stride, int w, int h, float x0, float y0, float x1, float y1) {
    if (y0 == y1) return;
    const auto fw = static_cast<float>(w);
    // work with y0 < y1 and remember the direction
    float dir = 1.0F;
    if (y0 > y1) { std::swap(x0, x1); std::swap(y0, y1); dir = -1.0F; }
    auto put = [&](float xa, float ya, float xb, float yb) {
        xa = std::clamp(xa, 0.0F, fw);
        xb = std::clamp(xb, 0.0F, fw);
        if (dir > 0.0F) accumulateLine(a, stride, w, h, xa, ya, xb, yb);
        else accumulateLine(a, stride, w, h, xb, yb, xa, ya);
    };
    if ((x0 >= 0.0F && x0 <= fw && x1 >= 0.0F && x1 <= fw) || (x0 <= 0.0F && x1 <= 0.0F) || (x0 >= fw && x1 >= fw)) {
        put(x0, y0, x1, y1);
        return;
    }
    const float dxdy = (x1 - x0) / (y1 - y0);
    float cuts[2];
    int n = 0;
    for (const float border : {0.0F, fw}) {
        if ((x0 < border) != (x1 < border)) cuts[n++] = y0 + (border - x0) / dxdy;
    }
    if (n == 2 && cuts[0] > cuts[1]) std::swap(cuts[0], cuts[1]);
    float ya = y0;
    for (int i = 0; i <= n; ++i) {
        const float yb = i < n ? std::clamp(cuts[i], y0, y1) : y1;
        if (yb > ya) put(x0 + dxdy * (ya - y0), ya, x0 + dxdy * (yb - y0), yb);
        ya = yb;
    }
}

} // namespace

// ====================================================================== shaders
float Shader::parameterAt(float x, float y) const noexcept {
    switch (kind) {
        case Kind::Linear: {
            const float dx = x1 - x0;
            const float dy = y1 - y0;
            const float len2 = dx * dx + dy * dy;
            if (len2 <= 0.0F) return 0.0F;
            return ((x - x0) * dx + (y - y0) * dy) / len2;
        }
        case Kind::Radial: {
            if (radius <= 0.0F) return 0.0F;
            return std::hypot(x - cx, y - cy) / radius;
        }
        case Kind::Sweep: {
            float a = std::atan2(y - cy, x - cx) / (2.0F * kPi);
            if (a < 0.0F) a += 1.0F;
            return a;
        }
    }
    return 0.0F;
}

namespace {
// interpolates the colour stops without premultiplying (like Android's default), result as floats 0..255
void interpolateStops(const Shader& s, float t, float out[4]) {
    const std::size_t n = s.colors.size();
    if (n == 0U) { out[0] = out[1] = out[2] = out[3] = 0.0F; return; }
    auto comp = [&](std::size_t i, float* o) {
        const ColorInt c = s.colors[i];
        o[0] = static_cast<float>(Color::alpha(c));
        o[1] = static_cast<float>(Color::red(c));
        o[2] = static_cast<float>(Color::green(c));
        o[3] = static_cast<float>(Color::blue(c));
    };
    auto pos = [&](std::size_t i) -> float {
        if (s.positions.size() == n) return s.positions[i];
        return n <= 1U ? 0.0F : static_cast<float>(i) / static_cast<float>(n - 1U);
    };
    if (n == 1U || t <= pos(0U)) { comp(0U, out); return; }
    for (std::size_t i = 1U; i < n; ++i) {
        const float p1 = pos(i);
        if (t < p1) {
            const float p0 = pos(i - 1U);
            const float k = p1 > p0 ? (t - p0) / (p1 - p0) : 1.0F;
            float c0[4], c1[4];
            comp(i - 1U, c0);
            comp(i, c1);
            for (int j = 0; j < 4; ++j) out[j] = c0[j] + (c1[j] - c0[j]) * k;
            return;
        }
    }
    comp(n - 1U, out);
}
} // namespace

ColorInt Shader::colorForParameter(float t) const noexcept {
    if (tile == TileMode::Repeat) t -= std::floor(t);
    else t = std::clamp(t, 0.0F, 1.0F);
    float c[4];
    interpolateStops(*this, t, c);
    return Color::argb(static_cast<int>(c[0] + 0.5F), static_cast<int>(c[1] + 0.5F), static_cast<int>(c[2] + 0.5F), static_cast<int>(c[3] + 0.5F));
}

ColorInt Shader::colorAt(float x, float y) const noexcept {
    float t = parameterAt(x, y);
    if (kind == Kind::Sweep) t = std::clamp(t, 0.0F, 1.0F);
    else if (tile == TileMode::Repeat) t -= std::floor(t);
    else t = std::clamp(t, 0.0F, 1.0F);
    float c[4];
    interpolateStops(*this, t, c);
    const float a = c[0] / 255.0F;
    const int ia = static_cast<int>(c[0] + 0.5F);
    const int ir = static_cast<int>(c[1] * a + 0.5F);
    const int ig = static_cast<int>(c[2] * a + 0.5F);
    const int ib = static_cast<int>(c[3] * a + 0.5F);
    return (static_cast<std::uint32_t>(std::clamp(ia, 0, 255)) << 24U) | (static_cast<std::uint32_t>(std::clamp(ir, 0, 255)) << 16U) |
           (static_cast<std::uint32_t>(std::clamp(ig, 0, 255)) << 8U) | static_cast<std::uint32_t>(std::clamp(ib, 0, 255));
}

ShaderPtr linearGradient(float x0, float y0, float x1, float y1, ColorInt c0, ColorInt c1, TileMode tile) {
    return linearGradient(x0, y0, x1, y1, std::vector<ColorInt>{c0, c1}, {}, tile);
}

ShaderPtr linearGradient(float x0, float y0, float x1, float y1, const std::vector<ColorInt>& colors, const std::vector<float>& positions, TileMode tile) {
    auto s = std::make_shared<Shader>();
    s->kind = Shader::Kind::Linear;
    s->x0 = x0; s->y0 = y0; s->x1 = x1; s->y1 = y1;
    s->colors = colors;
    s->positions = positions;
    s->tile = tile;
    return s;
}

ShaderPtr radialGradient(float cx, float cy, float radius, ColorInt c0, ColorInt c1, TileMode tile) {
    return radialGradient(cx, cy, radius, std::vector<ColorInt>{c0, c1}, {}, tile);
}

ShaderPtr radialGradient(float cx, float cy, float radius, const std::vector<ColorInt>& colors, const std::vector<float>& positions, TileMode tile) {
    auto s = std::make_shared<Shader>();
    s->kind = Shader::Kind::Radial;
    s->cx = cx; s->cy = cy; s->radius = radius;
    s->colors = colors;
    s->positions = positions;
    s->tile = tile;
    return s;
}

ShaderPtr sweepGradient(float cx, float cy, const std::vector<ColorInt>& colors, const std::vector<float>& positions) {
    auto s = std::make_shared<Shader>();
    s->kind = Shader::Kind::Sweep;
    s->cx = cx; s->cy = cy;
    s->colors = colors;
    s->positions = positions;
    return s;
}

// ====================================================================== paint / path
float Paint::measureText(const std::string& utf8) const {
    const auto glyphs = detail::shapeText(utf8, typeface, textSize);
    float w = 0.0F;
    for (const auto& g : glyphs) w += g.advancePx + letterSpacing * textSize;
    return w;
}

float Paint::measureText(const std::string& utf8, int from, int count) const {
    const auto glyphs = detail::shapeText(utf8, typeface, textSize);
    float w = 0.0F;
    const int end = std::min(static_cast<int>(glyphs.size()), from + count);
    for (int i = std::max(0, from); i < end; ++i) w += glyphs[static_cast<std::size_t>(i)].advancePx + letterSpacing * textSize;
    return w;
}

void Path::moveTo(float x, float y) {
    contours_.emplace_back();
    contours_.back().xy = {x, y};
}

void Path::lineTo(float x, float y) {
    if (contours_.empty()) { moveTo(x, y); return; }
    contours_.back().xy.push_back(x);
    contours_.back().xy.push_back(y);
}

void Path::close() {
    if (!contours_.empty()) contours_.back().closed = true;
}

// ====================================================================== canvas
Canvas::Canvas(int width, int height) : width_(std::max(1, width)), height_(std::max(1, height)) {
    pixels_.assign(static_cast<std::size_t>(width_) * static_cast<std::size_t>(height_), 0U);
    state_.clipL = 0;
    state_.clipT = 0;
    state_.clipR = width_;
    state_.clipB = height_;
}

Image Canvas::takeImage() {
    Image img;
    img.width = width_;
    img.height = height_;
    img.pixels = std::move(pixels_);
    pixels_.clear();
    return img;
}

void Canvas::clear(ColorInt color) {
    const std::uint32_t p = premultiply(color);
    std::fill(pixels_.begin(), pixels_.end(), p);
}

void Canvas::save() { stack_.push_back(state_); }

void Canvas::restore() {
    if (stack_.empty()) return;
    state_ = stack_.back();
    stack_.pop_back();
}

void Canvas::translate(float dx, float dy) {
    Matrix& m = state_.m;
    m.e += m.a * dx + m.c * dy;
    m.f += m.b * dx + m.d * dy;
}

void Canvas::scale(float sx, float sy) {
    Matrix& m = state_.m;
    m.a *= sx; m.b *= sx;
    m.c *= sy; m.d *= sy;
}

void Canvas::rotate(float degrees, float px, float py) {
    translate(px, py);
    const float rad = degrees * kPi / 180.0F;
    const float cs = std::cos(rad);
    const float sn = std::sin(rad);
    Matrix& m = state_.m;
    const float a = m.a * cs + m.c * sn;
    const float b = m.b * cs + m.d * sn;
    const float c = -m.a * sn + m.c * cs;
    const float d = -m.b * sn + m.d * cs;
    m.a = a; m.b = b; m.c = c; m.d = d;
    translate(-px, -py);
}

void Canvas::clipRect(const RectF& r) {
    float x0, y0, x1, y1;
    mapPoint(r.left, r.top, x0, y0);
    mapPoint(r.right, r.bottom, x1, y1);
    state_.clipL = std::max(state_.clipL, static_cast<int>(std::lround(std::min(x0, x1))));
    state_.clipT = std::max(state_.clipT, static_cast<int>(std::lround(std::min(y0, y1))));
    state_.clipR = std::min(state_.clipR, static_cast<int>(std::lround(std::max(x0, x1))));
    state_.clipB = std::min(state_.clipB, static_cast<int>(std::lround(std::max(y0, y1))));
}

void Canvas::mapPoint(float x, float y, float& ox, float& oy) const noexcept {
    const Matrix& m = state_.m;
    ox = m.a * x + m.c * y + m.e;
    oy = m.b * x + m.d * y + m.f;
}

bool Canvas::isAxisAligned() const noexcept {
    const Matrix& m = state_.m;
    return std::fabs(m.b) < 1e-6F && std::fabs(m.c) < 1e-6F && m.a > 0.0F && m.d > 0.0F;
}

float Canvas::uniformScale() const noexcept {
    const Matrix& m = state_.m;
    return std::sqrt(std::fabs(m.a * m.d - m.b * m.c));
}

// ---------------------------------------------------------------- source setup and pixel writing
namespace {
struct Source {
    bool useShader{false};
    std::uint32_t solid{0U};     // premultiplied
    int alpha255{255};           // paint alpha, applied to shader colours
};
} // namespace

// The current source is kept in these members for the duration of one draw call.
static thread_local Source gSource;
static thread_local const Shader* gShader = nullptr;

namespace {
// Gradient lookup table: a gradient is turned into a row of ready colours once per draw call, so that a pixel costs
// a multiplication and a table read instead of a search through the colour stops.
struct LutState {
    bool ready{false};      // prepared for this draw call
    int seen{0};            // pixels evaluated directly so far in this draw call (the table is built only for larger areas)
    bool usable{false};     // false: evaluate every pixel directly (sweep gradients, tiny sizes)
    bool opaque{false};     // every colour of the table is fully opaque
    std::vector<std::uint32_t> table;
    int last{0};
    bool radial{false};
    bool repeat{false};
    float ta{0.0F}, tb{0.0F}, tc{0.0F};              // linear: t = ta * X + tb * Y + tc (X, Y: pixel centre in device pixels)
    float ia{1.0F}, ib{0.0F}, ic{0.0F}, id{1.0F}, ie{0.0F}, jf{0.0F};   // inverse matrix (radial)
    float cx{0.0F}, cy{0.0F}, invRadius{1.0F};
};
} // namespace
static thread_local LutState gLut;

void Canvas::prepareLut() {
    gLut.ready = true;
    gLut.usable = false;
    const Shader& s = *gShader;
    if (s.kind == Shader::Kind::Sweep || s.colors.empty()) return;
    const int n = 256;
    gLut.last = n - 1;
    gLut.table.resize(static_cast<std::size_t>(n));
    gLut.repeat = s.tile == TileMode::Repeat;
    gLut.opaque = true;
    for (int i = 0; i < n; ++i) {
        const float t = static_cast<float>(i) / static_cast<float>(n - 1);
        float c[4];
        interpolateStops(s, t, c);
        const float a = c[0] / 255.0F;
        const int ia = static_cast<int>(c[0] + 0.5F);
        const int ir = static_cast<int>(c[1] * a + 0.5F);
        const int ig = static_cast<int>(c[2] * a + 0.5F);
        const int ib = static_cast<int>(c[3] * a + 0.5F);
        std::uint32_t px = (static_cast<std::uint32_t>(std::clamp(ia, 0, 255)) << 24U) | (static_cast<std::uint32_t>(std::clamp(ir, 0, 255)) << 16U) |
                           (static_cast<std::uint32_t>(std::clamp(ig, 0, 255)) << 8U) | static_cast<std::uint32_t>(std::clamp(ib, 0, 255));
        if (gSource.alpha255 < 255) px = scalePremul(px, gSource.alpha255);
        gLut.table[static_cast<std::size_t>(i)] = px;
        if ((px >> 24U) != 255U) gLut.opaque = false;
    }
    const Matrix& m = inverse_;
    if (s.kind == Shader::Kind::Linear) {
        const float dx = s.x1 - s.x0;
        const float dy = s.y1 - s.y0;
        const float len2 = dx * dx + dy * dy;
        gLut.radial = false;
        if (len2 <= 0.0F) { gLut.ta = gLut.tb = 0.0F; gLut.tc = 0.0F; }
        else {
            // local = inverse * device; t = ((lx - x0) * dx + (ly - y0) * dy) / len2
            gLut.ta = (m.a * dx + m.b * dy) / len2;
            gLut.tb = (m.c * dx + m.d * dy) / len2;
            gLut.tc = ((m.e - s.x0) * dx + (m.f - s.y0) * dy) / len2;
        }
    } else {
        gLut.radial = true;
        gLut.ia = m.a; gLut.ib = m.b; gLut.ic = m.c; gLut.id = m.d; gLut.ie = m.e; gLut.jf = m.f;
        gLut.cx = s.cx; gLut.cy = s.cy;
        gLut.invRadius = s.radius > 0.0F ? 1.0F / s.radius : 0.0F;
    }
    gLut.usable = true;
}

namespace {
inline std::uint32_t lutAt(const LutState& l, float px, float py) noexcept {   // px, py: pixel centre in device pixels
    float t;
    if (!l.radial) {
        t = l.ta * px + l.tb * py + l.tc;
    } else {
        const float lx = l.ia * px + l.ic * py + l.ie - l.cx;
        const float ly = l.ib * px + l.id * py + l.jf - l.cy;
        t = std::sqrt(lx * lx + ly * ly) * l.invRadius;
    }
    if (l.repeat) t -= std::floor(t);
    else t = std::clamp(t, 0.0F, 1.0F);
    const auto top = static_cast<float>(l.last);
    float f = t * top + 0.5F;
    f = f > 0.0F ? f : 0.0F;          // (also turns NaN into 0)
    f = f < top ? f : top;
    return l.table[static_cast<std::size_t>(f)];
}
} // namespace

ColorInt Canvas::shaderPixel(const Shader& s, int x, int y) const noexcept {
    const float dx = static_cast<float>(x) + 0.5F;
    const float dy = static_cast<float>(y) + 0.5F;
    const float lx = inverse_.a * dx + inverse_.c * dy + inverse_.e;
    const float ly = inverse_.b * dx + inverse_.d * dy + inverse_.f;
    return s.colorAt(lx, ly);
}

std::uint32_t Canvas::sourceAt(int x, int y) {
    if (!gSource.useShader) return gSource.solid;
    if (!gLut.ready && ++gLut.seen > 600) prepareLut();
    if (gLut.usable) return lutAt(gLut, static_cast<float>(x) + 0.5F, static_cast<float>(y) + 0.5F);
    std::uint32_t src = shaderPixel(*gShader, x, y);
    if (gSource.alpha255 < 255) src = scalePremul(src, gSource.alpha255);
    return src;
}

void Canvas::blendPixel(int x, int y, ColorInt, const Shader*, float coverage) {
    const int cov = static_cast<int>(coverage * 255.0F + 0.5F);
    if (cov <= 0) return;
    std::uint32_t src = sourceAt(x, y);
    if (cov < 255) src = scalePremul(src, cov);
    std::uint32_t& dst = pixels_[static_cast<std::size_t>(y) * static_cast<std::size_t>(width_) + static_cast<std::size_t>(x)];
    dst = over(dst, src);
}

// Pixels [x0, x1) of one row, all with the same coverage.
void Canvas::fillSpan(int y, int x0, int x1, int cov255) {
    if (x1 <= x0 || cov255 <= 0) return;
    std::uint32_t* row = pixels_.data() + static_cast<std::size_t>(y) * static_cast<std::size_t>(width_);
    if (!gSource.useShader) {
        std::uint32_t src = gSource.solid;
        if (cov255 < 255) src = scalePremul(src, cov255);
        if ((src >> 24U) == 255U) {
            std::fill(row + x0, row + x1, src);
        } else if ((src >> 24U) != 0U) {
            overSolidRun(row + x0, x1 - x0, src);
        }
        return;
    }
    if (!gLut.ready) {
        gLut.seen += x1 - x0;
        if (gLut.seen > 600) prepareLut();
    }
    if (gLut.usable) {
        const float py = static_cast<float>(y) + 0.5F;
        const LutState& l = gLut;
        const float scale = static_cast<float>(l.last);
        if (!l.radial) {
            // linear: the parameter grows by the same step from pixel to pixel
            float t = l.ta * (static_cast<float>(x0) + 0.5F) + l.tb * py + l.tc;
            const float tEnd = t + l.ta * static_cast<float>(x1 - x0);
            const bool plain = l.opaque && cov255 >= 255;
            if (std::fabs(t) < 1e8F && std::fabs(tEnd) < 1e8F) {   // (otherwise: the slow loop below)
            for (int x = x0; x < x1; ++x, t += l.ta) {
                float u = t;
                if (l.repeat) {
                    int fi = static_cast<int>(u);
                    if (u < static_cast<float>(fi)) --fi;
                    u -= static_cast<float>(fi);
                } else {
                    u = u < 0.0F ? 0.0F : (u > 1.0F ? 1.0F : u);
                }
                float f = u * scale + 0.5F;
                f = f > 0.0F ? f : 0.0F;
                f = f < scale ? f : scale;
                std::uint32_t src = l.table[static_cast<std::size_t>(f)];
                if (plain) { row[x] = src; continue; }
                if (cov255 < 255) src = scalePremul(src, cov255);
                row[x] = over(row[x], src);
            }
            return;
            }
        }
        for (int x = x0; x < x1; ++x) {
            std::uint32_t src = lutAt(l, static_cast<float>(x) + 0.5F, py);
            if (cov255 < 255) src = scalePremul(src, cov255);
            row[x] = over(row[x], src);
        }
        return;
    }
    for (int x = x0; x < x1; ++x) {
        std::uint32_t src = sourceAt(x, y);
        if (cov255 < 255) src = scalePremul(src, cov255);
        row[x] = over(row[x], src);
    }
}

void Canvas::fillCoverageRow(int y, int x0, const float* coverage, int count, ColorInt, const Shader*) {
    for (int i = 0; i < count; ++i) {
        if (coverage[i] > 0.002F) blendPixel(x0 + i, y, 0U, nullptr, coverage[i]);
    }
}

void Canvas::fillAlignedRect(const RectF& d, const Paint&, ColorInt, const Shader*) {
    const float l = std::max(d.left, static_cast<float>(state_.clipL));
    const float t = std::max(d.top, static_cast<float>(state_.clipT));
    const float r = std::min(d.right, static_cast<float>(state_.clipR));
    const float b = std::min(d.bottom, static_cast<float>(state_.clipB));
    if (!(l < r && t < b)) return;
    const int x0 = static_cast<int>(std::floor(l));
    const int x1 = static_cast<int>(std::ceil(r));
    const int y0 = static_cast<int>(std::floor(t));
    const int y1 = static_cast<int>(std::ceil(b));
    // columns that are covered completely: [ix0, ix1)
    const int ix0 = std::min(x1, static_cast<int>(std::ceil(l)));
    const int ix1 = std::max(ix0, std::min(x1, static_cast<int>(std::floor(r))));
    for (int y = y0; y < y1; ++y) {
        const float covY = std::min(static_cast<float>(y + 1), b) - std::max(static_cast<float>(y), t);
        // left edge pixels, the middle run, right edge pixels
        for (int x = x0; x < ix0; ++x) {
            const float covX = std::min(static_cast<float>(x + 1), r) - std::max(static_cast<float>(x), l);
            blendPixel(x, y, 0U, nullptr, covX * covY);
        }
        fillSpan(y, ix0, ix1, static_cast<int>(covY * 255.0F + 0.5F));
        for (int x = ix1; x < x1; ++x) {
            if (x < ix0) continue;
            const float covX = std::min(static_cast<float>(x + 1), r) - std::max(static_cast<float>(x), l);
            blendPixel(x, y, 0U, nullptr, covX * covY);
        }
    }
}

void Canvas::fillPolys(const std::vector<Poly>& polys, const Paint&, ColorInt, const Shader*) {
    float minX = std::numeric_limits<float>::max(), minY = minX, maxX = -minX, maxY = -minX;
    for (const Poly& p : polys) {
        for (std::size_t i = 0U; i + 1U < p.xy.size(); i += 2U) {
            minX = std::min(minX, p.xy[i]); maxX = std::max(maxX, p.xy[i]);
            minY = std::min(minY, p.xy[i + 1U]); maxY = std::max(maxY, p.xy[i + 1U]);
        }
    }
    if (!(minX <= maxX) || !std::isfinite(minX) || !std::isfinite(maxX) || !std::isfinite(minY) || !std::isfinite(maxY)) return;
    const int x0 = std::max(state_.clipL, static_cast<int>(std::floor(std::max(minX, -1e7F))));
    const int y0 = std::max(state_.clipT, static_cast<int>(std::floor(std::max(minY, -1e7F))));
    const int x1 = std::min(state_.clipR, static_cast<int>(std::ceil(std::min(maxX, 1e7F))));
    const int y1 = std::min(state_.clipB, static_cast<int>(std::ceil(std::min(maxY, 1e7F))));
    if (x1 <= x0 || y1 <= y0) return;
    const int w = x1 - x0;
    const int h = y1 - y0;
    const int stride = w + 2;
    const std::size_t needed = static_cast<std::size_t>(stride) * static_cast<std::size_t>(h);
    if (accumulation_.size() < needed) accumulation_.assign(needed, 0.0F);   // (stays all zero between draw calls: every row is cleared after it was read)
    float* a = accumulation_.data();
    for (const Poly& p : polys) {
        const std::size_t n = p.xy.size() / 2U;
        if (n < 3U) continue;
        for (std::size_t i = 0U; i < n; ++i) {
            const std::size_t j = (i + 1U) % n;
            accumulateEdge(a, stride, w, h, p.xy[2U * i] - static_cast<float>(x0), p.xy[2U * i + 1U] - static_cast<float>(y0),
                           p.xy[2U * j] - static_cast<float>(x0), p.xy[2U * j + 1U] - static_cast<float>(y0));
        }
    }
    for (int row = 0; row < h; ++row) {
        const float* r = a + static_cast<std::ptrdiff_t>(row) * stride;
        float acc = 0.0F;
        int x = 0;
        while (x < w) {
            acc += r[x];
            const float cov = std::min(1.0F, std::fabs(acc));
            if (cov > 0.99805F) {
                // fully covered; the pixels after it with no edge in them are covered the same way
                int xe = x + 1;
                while (xe < w && r[xe] == 0.0F) ++xe;
                fillSpan(y0 + row, x0 + x, x0 + xe, 255);
                x = xe;
                continue;
            }
            if (cov > 0.002F) blendPixel(x0 + x, y0 + row, 0U, nullptr, cov);
            ++x;
        }
        std::memset(a + static_cast<std::ptrdiff_t>(row) * stride, 0, static_cast<std::size_t>(stride) * sizeof(float));
    }
}

// ---------------------------------------------------------------- geometry builders (local space -> device Poly)
void Canvas::addCircle(std::vector<Poly>& out, float cx, float cy, float rx, float ry, bool reverse) const {
    const float rDev = std::max(rx, ry) * uniformScale();
    const float tol = 0.06F;
    int n = rDev <= tol ? 8 : static_cast<int>(std::ceil(kPi / std::acos(std::max(0.0F, 1.0F - tol / rDev))));
    n = std::clamp(n, 8, 720);
    std::vector<float> local;
    local.reserve(static_cast<std::size_t>(n) * 2U);
    for (int i = 0; i < n; ++i) {
        const float th = 2.0F * kPi * static_cast<float>(i) / static_cast<float>(n);
        local.push_back(cx + rx * std::cos(th));
        local.push_back(cy + ry * std::sin(th));
    }
    if (reverse) reversePoly(local);
    Poly p;
    p.xy.resize(local.size());
    for (std::size_t i = 0U; i < local.size(); i += 2U) mapPoint(local[i], local[i + 1U], p.xy[i], p.xy[i + 1U]);
    out.push_back(std::move(p));
}

void Canvas::addRoundRect(std::vector<Poly>& out, const RectF& r, float rx, float ry, bool reverse) const {
    rx = std::clamp(rx, 0.0F, r.width() * 0.5F);
    ry = std::clamp(ry, 0.0F, r.height() * 0.5F);
    std::vector<float> local;
    if (rx <= 0.0F || ry <= 0.0F) {
        local = {r.left, r.top, r.right, r.top, r.right, r.bottom, r.left, r.bottom};
    } else {
        const float rDev = std::max(rx, ry) * uniformScale();
        int n = rDev <= 0.1F ? 4 : static_cast<int>(std::ceil((kPi * 0.5F) / std::acos(std::max(0.0F, 1.0F - 0.06F / rDev))));
        n = std::clamp(n, 3, 180);
        // corners in the order top-left, top-right, bottom-right, bottom-left; each swept over a quarter turn
        const float cxs[4] = {r.left + rx, r.right - rx, r.right - rx, r.left + rx};
        const float cys[4] = {r.top + ry, r.top + ry, r.bottom - ry, r.bottom - ry};
        const float start[4] = {kPi, 1.5F * kPi, 0.0F, 0.5F * kPi};
        for (int c = 0; c < 4; ++c) {
            for (int i = 0; i <= n; ++i) {
                const float th = start[c] + 0.5F * kPi * static_cast<float>(i) / static_cast<float>(n);
                local.push_back(cxs[c] + rx * std::cos(th));
                local.push_back(cys[c] + ry * std::sin(th));
            }
        }
    }
    if (reverse) reversePoly(local);
    Poly p;
    p.xy.resize(local.size());
    for (std::size_t i = 0U; i < local.size(); i += 2U) mapPoint(local[i], local[i + 1U], p.xy[i], p.xy[i + 1U]);
    out.push_back(std::move(p));
}

void Canvas::addArcBand(std::vector<Poly>& out, float cx, float cy, float rx, float ry, float startRad, float sweepRad, float halfWidth, Cap cap) const {
    const float radius = 0.5F * (rx + ry);
    float a0 = startRad;
    float a1 = startRad + sweepRad;
    if (cap == Cap::Square && radius > 0.0F) {
        const float ext = halfWidth / radius * (sweepRad >= 0.0F ? 1.0F : -1.0F);
        a0 -= ext;
        a1 += ext;
    }
    const float rOut = radius + halfWidth;
    const float rIn = std::max(0.0F, radius - halfWidth);
    const float rDev = rOut * uniformScale();
    const float dTheta = rDev <= 0.1F ? 0.5F : 2.0F * std::acos(std::max(0.0F, 1.0F - 0.06F / rDev));
    int n = static_cast<int>(std::ceil(std::fabs(a1 - a0) / std::max(0.01F, dTheta)));
    n = std::clamp(n, 2, 1440);
    std::vector<float> local;
    local.reserve(static_cast<std::size_t>(n + 1) * 4U);
    for (int i = 0; i <= n; ++i) {
        const float th = a0 + (a1 - a0) * static_cast<float>(i) / static_cast<float>(n);
        local.push_back(cx + rOut * std::cos(th));
        local.push_back(cy + rOut * std::sin(th));
    }
    for (int i = n; i >= 0; --i) {
        const float th = a0 + (a1 - a0) * static_cast<float>(i) / static_cast<float>(n);
        local.push_back(cx + rIn * std::cos(th));
        local.push_back(cy + rIn * std::sin(th));
    }
    if (signedArea(local) < 0.0F) reversePoly(local);
    Poly p;
    p.xy.resize(local.size());
    for (std::size_t i = 0U; i < local.size(); i += 2U) mapPoint(local[i], local[i + 1U], p.xy[i], p.xy[i + 1U]);
    out.push_back(std::move(p));
    if (cap == Cap::Round && halfWidth > 0.0F) {
        for (const float th : {startRad, startRad + sweepRad}) {
            addCircle(out, cx + radius * std::cos(th), cy + radius * std::sin(th), halfWidth, halfWidth, false);
        }
    }
}

void Canvas::strokeLinePolys(const float* xy, int count, bool closed, float width, Cap cap, std::vector<Poly>& out) const {
    const float hw = width * 0.5F;
    if (count < 2 || hw <= 0.0F) return;
    // remove repeated points
    std::vector<float> p;
    for (int i = 0; i < count; ++i) {
        if (!p.empty() && std::fabs(p[p.size() - 2U] - xy[2 * i]) < 1e-6F && std::fabs(p[p.size() - 1U] - xy[2 * i + 1]) < 1e-6F) continue;
        p.push_back(xy[2 * i]);
        p.push_back(xy[2 * i + 1]);
    }
    int n = static_cast<int>(p.size() / 2U);
    if (closed && n > 2 && std::fabs(p[0] - p[p.size() - 2U]) < 1e-6F && std::fabs(p[1] - p[p.size() - 1U]) < 1e-6F) { p.pop_back(); p.pop_back(); --n; }
    if (n < 2) {
        if (n == 1 && cap == Cap::Round) addCircle(out, p[0], p[1], hw, hw, false);
        return;
    }
    const int segs = closed ? n : n - 1;
    auto emit = [&](std::vector<float> local) {
        if (signedArea(local) < 0.0F) reversePoly(local);
        Poly q;
        q.xy.resize(local.size());
        for (std::size_t i = 0U; i < local.size(); i += 2U) mapPoint(local[i], local[i + 1U], q.xy[i], q.xy[i + 1U]);
        out.push_back(std::move(q));
    };
    std::vector<float> dirs(static_cast<std::size_t>(segs) * 2U);
    for (int s = 0; s < segs; ++s) {
        const int a = s, b = (s + 1) % n;
        float dx = p[static_cast<std::size_t>(2 * b)] - p[static_cast<std::size_t>(2 * a)];
        float dy = p[static_cast<std::size_t>(2 * b + 1)] - p[static_cast<std::size_t>(2 * a + 1)];
        const float len = std::hypot(dx, dy);
        dx /= len; dy /= len;
        dirs[static_cast<std::size_t>(2 * s)] = dx;
        dirs[static_cast<std::size_t>(2 * s + 1)] = dy;
        float ax = p[static_cast<std::size_t>(2 * a)], ay = p[static_cast<std::size_t>(2 * a + 1)];
        float bx = p[static_cast<std::size_t>(2 * b)], by = p[static_cast<std::size_t>(2 * b + 1)];
        if (cap == Cap::Square && !closed) {
            if (s == 0) { ax -= dx * hw; ay -= dy * hw; }
            if (s == segs - 1) { bx += dx * hw; by += dy * hw; }
        }
        const float nx = -dy * hw, ny = dx * hw;
        emit({ax + nx, ay + ny, bx + nx, by + ny, bx - nx, by - ny, ax - nx, ay - ny});
    }
    // joins (miter up to a limit of 4, otherwise bevel)
    const int firstJoin = closed ? 0 : 1;
    const int lastJoin = closed ? n - 1 : n - 2;
    for (int v = firstJoin; v <= lastJoin; ++v) {
        const int sPrev = (v - 1 + segs) % segs;
        const int sNext = v % segs;
        const float d0x = dirs[static_cast<std::size_t>(2 * sPrev)], d0y = dirs[static_cast<std::size_t>(2 * sPrev + 1)];
        const float d1x = dirs[static_cast<std::size_t>(2 * sNext)], d1y = dirs[static_cast<std::size_t>(2 * sNext + 1)];
        const float cross = d0x * d1y - d0y * d1x;
        if (std::fabs(cross) < 1e-5F && d0x * d1x + d0y * d1y > 0.0F) continue;   // straight on
        const float sgn = cross > 0.0F ? 1.0F : -1.0F;
        const float n0x = -d0y, n0y = d0x, n1x = -d1y, n1y = d1x;
        const float px = p[static_cast<std::size_t>(2 * v)], py = p[static_cast<std::size_t>(2 * v + 1)];
        std::vector<float> wedge{px, py, px - sgn * n0x * hw, py - sgn * n0y * hw};
        const float denom = 1.0F + (n0x * n1x + n0y * n1y);
        if (denom > 1e-4F) {
            const float mx = (n0x + n1x) / denom, my = (n0y + n1y) / denom;
            if (std::hypot(mx, my) <= 4.0F) {
                wedge.push_back(px - sgn * mx * hw);
                wedge.push_back(py - sgn * my * hw);
            }
        }
        wedge.push_back(px - sgn * n1x * hw);
        wedge.push_back(py - sgn * n1y * hw);
        emit(wedge);
    }
    if (!closed && cap == Cap::Round) {
        addCircle(out, p[0], p[1], hw, hw, false);
        addCircle(out, p[static_cast<std::size_t>(2 * (n - 1))], p[static_cast<std::size_t>(2 * (n - 1) + 1)], hw, hw, false);
    }
}

// ---------------------------------------------------------------- the draw calls
namespace {
// Sets up the source (colour or shader) of a draw call. Returns the shader to use or nullptr.
void setSource(const Paint& paint, bool& useShader) {
    useShader = paint.shader != nullptr && !paint.shader->colors.empty();
    gSource.useShader = useShader;
    gSource.alpha255 = Color::alpha(paint.color);
    gSource.solid = premultiply(paint.color);
    gShader = useShader ? paint.shader.get() : nullptr;
    gLut.ready = false;
    gLut.usable = false;
    gLut.seen = 0;
}
} // namespace

#define SILVETON_PREPARE_SOURCE(paint) \
    bool useShader_ = false; \
    setSource(paint, useShader_); \
    if (useShader_) { \
        const Matrix& m_ = state_.m; \
        const float det_ = m_.a * m_.d - m_.b * m_.c; \
        if (std::fabs(det_) < 1e-9F) return; \
        const float id_ = 1.0F / det_; \
        inverse_.a = m_.d * id_; inverse_.b = -m_.b * id_; inverse_.c = -m_.c * id_; inverse_.d = m_.a * id_; \
        inverse_.e = -(inverse_.a * m_.e + inverse_.c * m_.f); \
        inverse_.f = -(inverse_.b * m_.e + inverse_.d * m_.f); \
    }

void Canvas::drawRect(const RectF& r, const Paint& paint) {
    SILVETON_PREPARE_SOURCE(paint)
    const bool fill = paint.style != Style::Stroke;
    const bool stroke = paint.style != Style::Fill && paint.strokeWidth > 0.0F;
    if (fill && isAxisAligned()) {
        float x0, y0, x1, y1;
        mapPoint(r.left, r.top, x0, y0);
        mapPoint(r.right, r.bottom, x1, y1);
        fillAlignedRect(RectF(x0, y0, x1, y1), paint, 0U, nullptr);
    } else if (fill) {
        std::vector<Poly> polys;
        addRoundRect(polys, r, 0.0F, 0.0F, false);
        fillPolys(polys, paint, 0U, nullptr);
    }
    if (stroke) {
        const float hw = paint.strokeWidth * 0.5F;
        std::vector<Poly> polys;
        addRoundRect(polys, RectF(r.left - hw, r.top - hw, r.right + hw, r.bottom + hw), 0.0F, 0.0F, false);
        const RectF inner(r.left + hw, r.top + hw, r.right - hw, r.bottom - hw);
        if (inner.width() > 0.0F && inner.height() > 0.0F) addRoundRect(polys, inner, 0.0F, 0.0F, true);
        fillPolys(polys, paint, 0U, nullptr);
    }
}

void Canvas::drawRoundRect(const RectF& r, float rx, float ry, const Paint& paint) {
    SILVETON_PREPARE_SOURCE(paint)
    const bool fill = paint.style != Style::Stroke;
    const bool stroke = paint.style != Style::Fill && paint.strokeWidth > 0.0F;
    if (fill) {
        std::vector<Poly> polys;
        addRoundRect(polys, r, rx, ry, false);
        fillPolys(polys, paint, 0U, nullptr);
    }
    if (stroke) {
        const float hw = paint.strokeWidth * 0.5F;
        std::vector<Poly> polys;
        addRoundRect(polys, RectF(r.left - hw, r.top - hw, r.right + hw, r.bottom + hw), rx + hw, ry + hw, false);
        const RectF inner(r.left + hw, r.top + hw, r.right - hw, r.bottom - hw);
        if (inner.width() > 0.0F && inner.height() > 0.0F) addRoundRect(polys, inner, std::max(0.0F, rx - hw), std::max(0.0F, ry - hw), true);
        fillPolys(polys, paint, 0U, nullptr);
    }
}

void Canvas::drawCircle(float cx, float cy, float radius, const Paint& paint) {
    if (radius <= 0.0F) return;
    SILVETON_PREPARE_SOURCE(paint)
    const bool fill = paint.style != Style::Stroke;
    const bool stroke = paint.style != Style::Fill && paint.strokeWidth > 0.0F;
    if (fill) {
        std::vector<Poly> polys;
        addCircle(polys, cx, cy, radius, radius, false);
        fillPolys(polys, paint, 0U, nullptr);
    }
    if (stroke) {
        const float hw = paint.strokeWidth * 0.5F;
        std::vector<Poly> polys;
        addCircle(polys, cx, cy, radius + hw, radius + hw, false);
        if (radius - hw > 0.0F) addCircle(polys, cx, cy, radius - hw, radius - hw, true);
        fillPolys(polys, paint, 0U, nullptr);
    }
}

void Canvas::drawLine(float x0, float y0, float x1, float y1, const Paint& paint) {
    SILVETON_PREPARE_SOURCE(paint)
    // Android draws lines with the stroke width, whatever the style (width 0 = hairline, drawn as 1 px)
    const float w = paint.strokeWidth > 0.0F ? paint.strokeWidth : 1.0F / std::max(0.0001F, uniformScale());
    const float xy[4] = {x0, y0, x1, y1};
    std::vector<Poly> polys;
    strokeLinePolys(xy, 2, false, w, paint.strokeCap, polys);
    fillPolys(polys, paint, 0U, nullptr);
}

void Canvas::drawArc(const RectF& oval, float startDegrees, float sweepDegrees, bool useCenter, const Paint& paint) {
    SILVETON_PREPARE_SOURCE(paint)
    const float cx = oval.centerX(), cy = oval.centerY();
    const float rx = oval.width() * 0.5F, ry = oval.height() * 0.5F;
    const float a0 = startDegrees * kPi / 180.0F;
    float sweep = sweepDegrees * kPi / 180.0F;
    if (std::fabs(sweep) > 2.0F * kPi) sweep = sweep > 0.0F ? 2.0F * kPi : -2.0F * kPi;
    const bool fill = paint.style != Style::Stroke;
    const bool stroke = paint.style != Style::Fill && paint.strokeWidth > 0.0F;
    if (fill) {
        const float rDev = std::max(rx, ry) * uniformScale();
        const float dTheta = rDev <= 0.1F ? 0.5F : 2.0F * std::acos(std::max(0.0F, 1.0F - 0.06F / rDev));
        const int n = std::clamp(static_cast<int>(std::ceil(std::fabs(sweep) / std::max(0.01F, dTheta))), 2, 1440);
        std::vector<float> local;
        if (useCenter) { local.push_back(cx); local.push_back(cy); }
        for (int i = 0; i <= n; ++i) {
            const float th = a0 + sweep * static_cast<float>(i) / static_cast<float>(n);
            local.push_back(cx + rx * std::cos(th));
            local.push_back(cy + ry * std::sin(th));
        }
        if (signedArea(local) < 0.0F) reversePoly(local);
        Poly p;
        p.xy.resize(local.size());
        for (std::size_t i = 0U; i < local.size(); i += 2U) mapPoint(local[i], local[i + 1U], p.xy[i], p.xy[i + 1U]);
        std::vector<Poly> polys;
        polys.push_back(std::move(p));
        fillPolys(polys, paint, 0U, nullptr);
    }
    if (stroke) {
        std::vector<Poly> polys;
        addArcBand(polys, cx, cy, rx, ry, a0, sweep, paint.strokeWidth * 0.5F, paint.strokeCap);
        fillPolys(polys, paint, 0U, nullptr);
    }
}

void Canvas::drawPath(const Path& path, const Paint& paint) {
    SILVETON_PREPARE_SOURCE(paint)
    const bool fill = paint.style != Style::Stroke;
    const bool stroke = paint.style != Style::Fill && paint.strokeWidth > 0.0F;
    if (fill) {
        std::vector<Poly> polys;
        for (const auto& c : path.contours()) {
            if (c.xy.size() < 6U) continue;
            std::vector<float> local = c.xy;
            if (signedArea(local) < 0.0F) reversePoly(local);
            Poly p;
            p.xy.resize(local.size());
            for (std::size_t i = 0U; i < local.size(); i += 2U) mapPoint(local[i], local[i + 1U], p.xy[i], p.xy[i + 1U]);
            polys.push_back(std::move(p));
        }
        fillPolys(polys, paint, 0U, nullptr);
    }
    if (stroke) {
        std::vector<Poly> polys;
        for (const auto& c : path.contours()) {
            strokeLinePolys(c.xy.data(), static_cast<int>(c.xy.size() / 2U), c.closed, paint.strokeWidth, paint.strokeCap, polys);
        }
        fillPolys(polys, paint, 0U, nullptr);
    }
}

void Canvas::drawText(const std::string& utf8, float x, float y, const Paint& paint) {
    if (utf8.empty() || paint.textSize <= 0.0F) return;
    SILVETON_PREPARE_SOURCE(paint)
    const auto glyphs = detail::shapeText(utf8, paint.typeface, paint.textSize);
    const float spacing = paint.letterSpacing * paint.textSize;
    float width = 0.0F;
    for (const auto& g : glyphs) width += g.advancePx + spacing;
    float pen = x;
    if (paint.textAlign == Align::Center) pen = x - width * 0.5F;
    else if (paint.textAlign == Align::Right) pen = x - width;
    std::vector<Poly> polys;
    for (const auto& g : glyphs) {
        if (g.outline != nullptr) {
            for (const auto& contour : g.outline->contours) {
                if (contour.size() < 6U) continue;
                Poly p;
                p.xy.resize(contour.size());
                for (std::size_t i = 0U; i < contour.size(); i += 2U) {
                    mapPoint(pen + contour[i] * g.scale, y - contour[i + 1U] * g.scale, p.xy[i], p.xy[i + 1U]);
                }
                polys.push_back(std::move(p));
            }
        }
        pen += g.advancePx + spacing;
    }
    fillPolys(polys, paint, 0U, nullptr);
}

void Canvas::drawImage(const Image& image, const RectF& dst, const Paint& paint) {
    if (image.width <= 0 || image.height <= 0 || dst.isEmpty() || !isAxisAligned()) return;
    float dx0, dy0, dx1, dy1;
    mapPoint(dst.left, dst.top, dx0, dy0);
    mapPoint(dst.right, dst.bottom, dx1, dy1);
    const int x0 = std::max(state_.clipL, static_cast<int>(std::floor(dx0)));
    const int y0 = std::max(state_.clipT, static_cast<int>(std::floor(dy0)));
    const int x1 = std::min(state_.clipR, static_cast<int>(std::ceil(dx1)));
    const int y1 = std::min(state_.clipB, static_cast<int>(std::ceil(dy1)));
    const int alpha = Color::alpha(paint.color);
    for (int y = y0; y < y1; ++y) {
        const float v = ((static_cast<float>(y) + 0.5F - dy0) / (dy1 - dy0)) * static_cast<float>(image.height) - 0.5F;
        const int iy = static_cast<int>(std::floor(v));
        const float fy = v - static_cast<float>(iy);
        for (int x = x0; x < x1; ++x) {
            const float u = ((static_cast<float>(x) + 0.5F - dx0) / (dx1 - dx0)) * static_cast<float>(image.width) - 0.5F;
            const int ix = static_cast<int>(std::floor(u));
            const float fx = u - static_cast<float>(ix);
            auto px = [&](int sx, int sy) -> std::uint32_t {
                sx = std::clamp(sx, 0, image.width - 1);
                sy = std::clamp(sy, 0, image.height - 1);
                return image.pixels[static_cast<std::size_t>(sy) * static_cast<std::size_t>(image.width) + static_cast<std::size_t>(sx)];
            };
            const std::uint32_t c00 = px(ix, iy), c10 = px(ix + 1, iy), c01 = px(ix, iy + 1), c11 = px(ix + 1, iy + 1);
            std::uint32_t outc = 0U;
            for (int shift = 0; shift <= 24; shift += 8) {
                const float c0 = static_cast<float>((c00 >> shift) & 255U) * (1.0F - fx) + static_cast<float>((c10 >> shift) & 255U) * fx;
                const float c1 = static_cast<float>((c01 >> shift) & 255U) * (1.0F - fx) + static_cast<float>((c11 >> shift) & 255U) * fx;
                const int v8 = static_cast<int>(c0 * (1.0F - fy) + c1 * fy + 0.5F);
                outc |= static_cast<std::uint32_t>(std::clamp(v8, 0, 255)) << shift;
            }
            outc = scalePremul(outc, alpha);
            std::uint32_t& d = pixels_[static_cast<std::size_t>(y) * static_cast<std::size_t>(width_) + static_cast<std::size_t>(x)];
            d = over(d, outc);
        }
    }
}

} // namespace silveton::ui
