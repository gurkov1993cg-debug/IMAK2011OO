// SILVETON_MAC_UI_SUPPORT_V1
#include "silveton/ui/Support.h"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cerrno>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <sstream>

#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>

namespace silveton::ui {

// ------------------------------------------------------------------ clock
namespace {
std::atomic<std::int64_t> gFixedClock{-1};
std::chrono::steady_clock::time_point startPoint() {
    static const auto start = std::chrono::steady_clock::now();
    return start;
}
} // namespace

std::int64_t nowMs() {
    const std::int64_t fixed = gFixedClock.load();
    if (fixed >= 0) return fixed;
    return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - startPoint()).count() + 1000;
}

void setFixedClockForTests(std::int64_t ms) { gFixedClock.store(ms); }

// ------------------------------------------------------------------ text
std::string fmtFixed(double value, int decimals) {
    if (std::isnan(value)) return "NaN";
    if (std::isinf(value)) return value > 0 ? "Infinity" : "-Infinity";
    decimals = std::clamp(decimals, 0, 9);
    // exact decimal expansion of the binary number, then round half up on the text
    char buf[512];
    std::snprintf(buf, sizeof buf, "%.40f", std::fabs(value));
    std::string digits = buf;
    const std::size_t dot = digits.find('.');
    std::string intPart = digits.substr(0, dot);
    std::string frac = digits.substr(dot + 1);
    const bool roundUp = frac.size() > static_cast<std::size_t>(decimals) && frac[static_cast<std::size_t>(decimals)] >= '5';
    frac = frac.substr(0, static_cast<std::size_t>(decimals));
    std::string all = intPart + frac;
    if (roundUp) {
        std::size_t i = all.size();
        while (i > 0) {
            --i;
            if (all[i] == '9') { all[i] = '0'; } else { ++all[i]; break; }
            if (i == 0) all.insert(all.begin(), '1');
        }
    }
    const std::size_t intLen = all.size() - static_cast<std::size_t>(decimals);
    std::string out = all.substr(0, intLen);
    if (decimals > 0) out += "." + all.substr(intLen);
    if (std::signbit(value)) out = "-" + out;   // Java prints "-0.00" for a small negative number too
    return out;
}

std::string fmtZeroPad(long long value, int width) {
    const bool neg = value < 0;
    std::string d = std::to_string(neg ? -value : value);
    const int target = neg ? width - 1 : width;
    while (static_cast<int>(d.size()) < target) d.insert(d.begin(), '0');
    return neg ? "-" + d : d;
}

std::string toStr(long long value) { return std::to_string(value); }

static bool isWs(char c) { return c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\v' || c == '\f'; }

std::string trimmed(const std::string& s) {
    std::size_t a = 0, b = s.size();
    while (a < b && isWs(s[a])) ++a;
    while (b > a && isWs(s[b - 1])) --b;
    return s.substr(a, b - a);
}

bool isBlank(const std::string& s) {
    return std::all_of(s.begin(), s.end(), [](char c) { return isWs(c); });
}

std::optional<long long> toLongOrNull(const std::string& s) {
    if (s.empty()) return std::nullopt;
    std::size_t i = 0;
    if (s[0] == '-' || s[0] == '+') i = 1;
    if (i >= s.size()) return std::nullopt;
    long long v = 0;
    for (; i < s.size(); ++i) {
        if (s[i] < '0' || s[i] > '9') return std::nullopt;
        if (v > 900000000000000000LL) return std::nullopt;
        v = v * 10 + (s[i] - '0');
    }
    return s[0] == '-' ? -v : v;
}

std::optional<int> toIntOrNull(const std::string& s) {
    const auto v = toLongOrNull(s);
    if (!v || *v < -2147483648LL || *v > 2147483647LL) return std::nullopt;
    return static_cast<int>(*v);
}

std::optional<float> toFloatOrNull(const std::string& s) {
    if (s.empty()) return std::nullopt;
    char* end = nullptr;
    errno = 0;
    const double v = std::strtod(s.c_str(), &end);
    if (end == s.c_str() || *end != '\0') return std::nullopt;
    return static_cast<float>(v);
}

std::vector<std::string> splitChar(const std::string& s, char sep) {
    std::vector<std::string> out;
    std::size_t from = 0;
    for (;;) {
        const std::size_t at = s.find(sep, from);
        if (at == std::string::npos) { out.push_back(s.substr(from)); break; }
        out.push_back(s.substr(from, at - from));
        from = at + 1;
    }
    return out;
}

bool startsWith(const std::string& s, const std::string& p) { return s.size() >= p.size() && s.compare(0, p.size(), p) == 0; }
bool endsWith(const std::string& s, const std::string& p) { return s.size() >= p.size() && s.compare(s.size() - p.size(), p.size(), p) == 0; }

std::string replaceAll(std::string s, const std::string& from, const std::string& to) {
    if (from.empty()) return s;
    std::size_t at = 0;
    while ((at = s.find(from, at)) != std::string::npos) { s.replace(at, from.size(), to); at += to.size(); }
    return s;
}

// ------------------------------------------------------------------ java.util.Random
JavaRandom::JavaRandom(std::int64_t seed) : seed_((seed ^ 0x5DEECE66DLL) & ((1LL << 48) - 1)) {}

int JavaRandom::next(int bits) {
    seed_ = (seed_ * 0x5DEECE66DLL + 0xBLL) & ((1LL << 48) - 1);
    return static_cast<int>(static_cast<std::int64_t>(static_cast<std::uint64_t>(seed_) >> (48 - bits)));
}

int JavaRandom::nextInt() { return next(32); }

int JavaRandom::nextInt(int bound) {
    if (bound <= 0) return 0;
    int r = next(31);
    const int m = bound - 1;
    if ((bound & m) == 0) {
        r = static_cast<int>((static_cast<std::int64_t>(bound) * static_cast<std::int64_t>(r)) >> 31);
    } else {
        for (int u = r; u - (r = u % bound) + m < 0; u = next(31)) {}
    }
    return r;
}

bool JavaRandom::nextBoolean() { return next(1) != 0; }
float JavaRandom::nextFloat() { return static_cast<float>(next(24)) / static_cast<float>(1 << 24); }

// ------------------------------------------------------------------ files
namespace files {

bool isFile(const std::string& p) { struct stat st{}; return !p.empty() && ::stat(p.c_str(), &st) == 0 && S_ISREG(st.st_mode); }
bool isDirectory(const std::string& p) { struct stat st{}; return !p.empty() && ::stat(p.c_str(), &st) == 0 && S_ISDIR(st.st_mode); }
bool exists(const std::string& p) { struct stat st{}; return !p.empty() && ::stat(p.c_str(), &st) == 0; }
long long fileSize(const std::string& p) { struct stat st{}; return (!p.empty() && ::stat(p.c_str(), &st) == 0) ? static_cast<long long>(st.st_size) : -1; }

long long lastModifiedMs(const std::string& p) {
    struct stat st{};
    if (p.empty() || ::stat(p.c_str(), &st) != 0) return 0;
#if defined(__APPLE__)
    return static_cast<long long>(st.st_mtimespec.tv_sec) * 1000LL + st.st_mtimespec.tv_nsec / 1000000LL;
#else
    return static_cast<long long>(st.st_mtim.tv_sec) * 1000LL + st.st_mtim.tv_nsec / 1000000LL;
#endif
}

bool readable(const std::string& p) { return !p.empty() && ::access(p.c_str(), R_OK) == 0; }

bool makeDirectories(const std::string& p) {
    if (p.empty()) return false;
    if (isDirectory(p)) return true;
    const std::string parent = parentOf(p);
    if (!parent.empty() && parent != p && !isDirectory(parent)) makeDirectories(parent);
    if (::mkdir(p.c_str(), 0777) != 0 && errno != EEXIST) return false;
    return isDirectory(p);
}

std::vector<std::string> listNames(const std::string& dir) {
    std::vector<std::string> out;
    DIR* d = ::opendir(dir.c_str());
    if (d == nullptr) return out;
    while (dirent* e = ::readdir(d)) {
        const std::string n = e->d_name;
        if (n != "." && n != "..") out.push_back(n);
    }
    ::closedir(d);
    std::sort(out.begin(), out.end());
    return out;
}

std::string join(const std::string& dir, const std::string& name) {
    if (dir.empty()) return name;
    if (dir.back() == '/') return dir + name;
    return dir + "/" + name;
}

std::string parentOf(const std::string& path) {
    std::string p = path;
    while (p.size() > 1 && p.back() == '/') p.pop_back();
    const std::size_t at = p.rfind('/');
    if (at == std::string::npos) return {};
    if (at == 0) return "/";
    return p.substr(0, at);
}

std::string nameOf(const std::string& path) {
    std::string p = path;
    while (p.size() > 1 && p.back() == '/') p.pop_back();
    const std::size_t at = p.rfind('/');
    return at == std::string::npos ? p : p.substr(at + 1);
}

std::string absolute(const std::string& path) {
    if (!path.empty() && path[0] == '/') return path;
    char buf[4096];
    if (::getcwd(buf, sizeof buf) == nullptr) return path;
    return join(buf, path);
}

bool removeRecursively(const std::string& path) {
    struct stat st{};
    if (path.empty() || ::lstat(path.c_str(), &st) != 0) return true;
    if (S_ISDIR(st.st_mode)) {
        for (const auto& n : listNames(path)) removeRecursively(join(path, n));
        return ::rmdir(path.c_str()) == 0;
    }
    return ::unlink(path.c_str()) == 0;
}

bool copyFile(const std::string& from, const std::string& to) {
    std::ifstream in(from, std::ios::binary);
    if (!in) return false;
    std::ofstream out(to, std::ios::binary | std::ios::trunc);
    if (!out) return false;
    char buffer[1 << 16];
    while (in) {
        in.read(buffer, sizeof buffer);
        const std::streamsize got = in.gcount();
        if (got > 0) out.write(buffer, got);
    }
    out.flush();
    return static_cast<bool>(out);
}

bool copyRecursively(const std::string& from, const std::string& to) {
    if (isDirectory(from)) {
        if (!makeDirectories(to)) return false;
        bool ok = true;
        for (const auto& n : listNames(from)) ok = copyRecursively(join(from, n), join(to, n)) && ok;
        return ok;
    }
    return copyFile(from, to);
}

bool readText(const std::string& path, std::string& out) {
    std::ifstream in(path, std::ios::binary);
    if (!in) return false;
    std::ostringstream ss;
    ss << in.rdbuf();
    out = ss.str();
    return true;
}

bool writeText(const std::string& path, const std::string& text) {
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    if (!out) return false;
    out.write(text.data(), static_cast<std::streamsize>(text.size()));
    out.flush();
    return static_cast<bool>(out);
}

std::string homeDirectory() {
    const char* h = std::getenv("HOME");
    return h != nullptr ? std::string(h) : std::string("/");
}

} // namespace files

// ------------------------------------------------------------------ prefs
Prefs::Prefs(std::string path) : path_(std::move(path)) { load(); }

void Prefs::load() {
    if (path_.empty()) return;
    std::string text;
    if (!files::readText(path_, text)) return;
    std::lock_guard<std::mutex> lock(mutex_);
    for (const auto& line : splitChar(text, '\n')) {
        const std::size_t eq = line.find('=');
        if (eq == std::string::npos || eq == 0) continue;
        values_[line.substr(0, eq)] = line.substr(eq + 1);
    }
}

void Prefs::save() const {
    if (path_.empty()) return;
    std::string text;
    for (const auto& kv : values_) text += kv.first + "=" + kv.second + "\n";
    const std::string dir = files::parentOf(path_);
    if (!dir.empty()) files::makeDirectories(dir);
    const std::string tmp = path_ + ".tmp";
    if (files::writeText(tmp, text)) std::rename(tmp.c_str(), path_.c_str());
}

int Prefs::getInt(const std::string& key, int def) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto it = values_.find(key);
    if (it == values_.end()) return def;
    return toIntOrNull(it->second).value_or(def);
}

bool Prefs::getBool(const std::string& key, bool def) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto it = values_.find(key);
    if (it == values_.end()) return def;
    if (it->second == "true") return true;
    if (it->second == "false") return false;
    return def;
}

std::string Prefs::getString(const std::string& key, const std::string& def) const {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto it = values_.find(key);
    return it == values_.end() ? def : it->second;
}

void Prefs::putInt(const std::string& key, int value) { putAll({{key, std::to_string(value)}}); }
void Prefs::putBool(const std::string& key, bool value) { putAll({{key, value ? "true" : "false"}}); }
void Prefs::putString(const std::string& key, const std::string& value) { putAll({{key, value}}); }

void Prefs::putAll(const std::vector<std::pair<std::string, std::string>>& values) {
    std::lock_guard<std::mutex> lock(mutex_);
    for (const auto& kv : values) {
        std::string v = kv.second;
        std::replace(v.begin(), v.end(), '\n', ' ');
        values_[kv.first] = v;
    }
    save();
}

} // namespace silveton::ui
