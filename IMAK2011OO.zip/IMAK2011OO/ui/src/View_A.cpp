// SILVETON_MAC_VIEW_V1 - part A: state, touch, frame (tablet SilvetonSamplerView.kt lines 1-700 and 3476-3565)
#include "silveton/ui/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui {

namespace {
float at(const std::vector<float>& v, std::size_t i, float def) { return i < v.size() ? v[i] : def; }
bool inRange(float v, float lo, float hi) { return v >= lo && v <= hi; }
} // namespace

SilvetonSamplerView::SilvetonSamplerView(Ctrl& s) : sampler(s) {
    paint.antiAlias = true;
    hits.reserve(256);
    pairHits.reserve(8);
    smoothRangeHits.reserve(4);
    listLongHits.reserve(24);
    stripSound.fill(0);
    marked.fill(false);
    const auto favs = sampler.listFavourites();
    listFavs = favs;
    frameAudioStatus = sampler.audioStatus();
    frameUpperMeters.assign(7, {0.0F, 0.0F});
    frameMidiStatus = sampler.midiStatus();
    lastMidiSerial = frameMidiStatus.activitySerial;
    applyTheme(sampler.themeDark());   // SILVETON_THEME_V1
    refreshAllUppers();
    refreshFx();
    refreshGlobal();
    cachedCombiName = sampler.combiName();
}

SilvetonSamplerView::~SilvetonSamplerView() = default;

void SilvetonSamplerView::setMidiConnections(int count) {
    midiConnections = std::max(0, count);
    invalidate();
}

void SilvetonSamplerView::setWarning(const std::string& message) {
    std::lock_guard<std::mutex> lock(warningMutex_);
    pendingWarning_ = isBlank(message) ? std::nullopt : std::optional<std::string>(message);
    pendingWarningSet_ = true;
    invalidated_ = true;
}

void SilvetonSamplerView::refreshAllForTests() { refreshEverything(); }

// Reads Uppers, effects, MASTER and the LIST again (after a bank was loaded).
void SilvetonSamplerView::refreshEverything() {
    refreshAllUppers();
    refreshFx();
    refreshGlobal();
    refreshListCache();
    cachedCombiName = sampler.combiName();
}

// ---------------------------------------------------------------- caches and parameter helpers
std::vector<float> SilvetonSamplerView::uParams(int u) {
    auto& slot = upperParamsCache[static_cast<std::size_t>(u)];
    if (!slot) slot = sampler.upperParams(u);
    return *slot;
}

std::vector<float> SilvetonSamplerView::lParams(int u, int l) {
    auto& slot = layerParamsCache[static_cast<std::size_t>(u)][static_cast<std::size_t>(l)];
    if (!slot) slot = sampler.layerParams(u, l);
    return *slot;
}

std::string SilvetonSamplerView::lName(int u, int l) {
    auto& slot = layerNameCache[static_cast<std::size_t>(u)][static_cast<std::size_t>(l)];
    if (!slot) slot = sampler.layerName(u, l);
    return *slot;
}

std::vector<float> SilvetonSamplerView::fxP(int unit) {
    auto& slot = fxParamsCache[static_cast<std::size_t>(unit)];
    if (!slot) slot = sampler.fxParams(unit);
    return *slot;
}

void SilvetonSamplerView::dropParamCaches(int u) {
    upperParamsCache[static_cast<std::size_t>(u)].reset();
    for (std::size_t l = 0U; l < 4U; ++l) {
        layerParamsCache[static_cast<std::size_t>(u)][l].reset();
        layerNameCache[static_cast<std::size_t>(u)][l].reset();
    }
}

// SILVETON_MARK_LINK_V1: with LINK on, a change of a MARKED Upper is repeated with the same value on every other marked Upper.
std::vector<int> SilvetonSamplerView::linkTargets(int u) const {
    std::vector<int> out;
    if (!linkOn || u < 0 || u > 6 || !marked[static_cast<std::size_t>(u)]) return out;
    for (int i = 0; i < 7; ++i) if (i != u && marked[static_cast<std::size_t>(i)]) out.push_back(i);
    return out;
}

void SilvetonSamplerView::setUParam(int u, int id, float v) {
    setUParamOne(u, id, v);
    for (const int t : linkTargets(u)) setUParamOne(t, id, v);
}

void SilvetonSamplerView::setUParamOne(int u, int id, float v) {
    auto a = uParams(u);
    if (id < static_cast<int>(a.size())) a[static_cast<std::size_t>(id)] = v;
    upperParamsCache[static_cast<std::size_t>(u)] = a;
    if (!sampler.setUpperParam(u, id, v)) upperParamsCache[static_cast<std::size_t>(u)].reset();
    if (id >= 16 && id <= 35) refreshUpper(u);   // LOW / MID / HIGH of the old TONE page mirror bands 1 / 3 / 5
}

void SilvetonSamplerView::setLParam(int u, int l, int id, float v) {
    setLParamOne(u, l, id, v);
    for (const int t : linkTargets(u)) setLParamOne(t, l, id, v);
}

void SilvetonSamplerView::setLParamOne(int u, int l, int id, float v) {
    auto a = lParams(u, l);
    if (id < static_cast<int>(a.size())) a[static_cast<std::size_t>(id)] = v;
    layerParamsCache[static_cast<std::size_t>(u)][static_cast<std::size_t>(l)] = a;
    if (!sampler.setLayerParam(u, l, id, v)) layerParamsCache[static_cast<std::size_t>(u)][static_cast<std::size_t>(l)].reset();
}

void SilvetonSamplerView::setFxP(int unit, int id, float v) {
    setFxPOne(unit, id, v);
    if (unit >= 4) for (const int t : linkTargets(unit - 4)) setFxPOne(4 + t, id, v);   // 4..10 = INSERT of Upper 1..7
}

void SilvetonSamplerView::setFxPOne(int unit, int id, float v) {
    auto a = fxP(unit);
    if (id < static_cast<int>(a.size())) a[static_cast<std::size_t>(id)] = v;
    fxParamsCache[static_cast<std::size_t>(unit)] = a;
    if (!sampler.setFxParam(unit, id, v)) fxParamsCache[static_cast<std::size_t>(unit)].reset();
    if (unit < 4) refreshFx();
}

bool SilvetonSamplerView::layerOn(int u, int l) { return at(lParams(u, l), 0U, 0.0F) >= 0.5F; }
int SilvetonSamplerView::layerSlot(int u, int l) { return static_cast<int>(at(lParams(u, l), 31U, 0.0F)); }

// TONE extra of a sound (0 = basic, 1..4 = layer): ids 0..14 (see the bridge)
float SilvetonSamplerView::toneX(int u, int sound, int id) {
    return sound == 0 ? at(uParams(u), static_cast<std::size_t>(id), 0.0F) : at(lParams(u, sound - 1), static_cast<std::size_t>(16 + id), 0.0F);
}

void SilvetonSamplerView::setToneX(int u, int sound, int id, float v) {
    if (sound == 0) setUParam(u, id, v); else setLParam(u, sound - 1, 16 + id, v);
}

std::string SilvetonSamplerView::soundLabel(int sound) {
    switch (sound) {
        case 0: return "ОСНОВЕН";
        case 5: return "ОБЩО UPPER";
        default: return "LAYER " + std::to_string(sound);
    }
}

std::vector<SilvetonSamplerView::UpperTab> SilvetonSamplerView::tabsFor(int sound) {
    if (sound == 5) return {UpperTab::PORTA, UpperTab::EQ, UpperTab::CONTROL, UpperTab::FX};
    return {UpperTab::TUNE, UpperTab::RANGE, UpperTab::TONE};   // SILVETON_SYNTH_MENU_OFF_V1
}

// ---------------------------------------------------------------- touch (mouse)
bool SilvetonSamplerView::dialogOpen() const { return dialogIsOpen(); }

void SilvetonSamplerView::pointer(PointerAction action, float rawX, float rawY) {
    // picture pixels -> design units (the tablet transforms the MotionEvent the same way)
    const float x = (rawX - uiOffsetX) / uiScale;
    const float y = (rawY - uiOffsetY) / uiScale;
    handleTouch(action, x, y);
}

void SilvetonSamplerView::secondaryClick(float rawX, float rawY) {
    const float x = (rawX - uiOffsetX) / uiScale;
    const float y = (rawY - uiOffsetY) / uiScale;
    // the tablet's second finger on the partner of a - / + pair = reset
    for (const auto& pair : pairHits) {
        if (pair.a.contains(x, y) || pair.b.contains(x, y)) {
            pair.reset();
            pairConsumed = false;
            activeHit.reset();
            hapticFeedback();
            invalidate();
            return;
        }
    }
    // a knob / fader / key with its own reset (the tablet's double tap)
    if (auto h = hitAt(x, y)) {
        if (h->reset) {
            h->reset();
            hapticFeedback();
            invalidate();
            return;
        }
    }
    if (const ListLongHit* l = listLongHitAt(x, y)) {
        const ListLongHit copy = *l;
        copy.action(x, y);
        invalidate();
    }
}

void SilvetonSamplerView::handleTouch(PointerAction action, float x, float y) {
    if (dialogPointerHook(action, x, y)) return;   // the - / + keys of the number page repeat while held
    if (pairConsumed && (action == PointerAction::Up || action == PointerAction::Cancel)) {
        pairConsumed = false;
        activeHit.reset();
        pointerDown_ = false;
        invalidate();
        return;
    }
    if (handleSmoothRangeTouch(action, x, y)) return;
    switch (action) {
        case PointerAction::Down:
            listLongPressX = x;
            listLongPressY = y;
            listLongPressFired = false;
            listLongPressArmed = listLongHitAt(x, y) != nullptr;
            listLongPressStartMs = nowMs();
            break;
        case PointerAction::Move:
            if (listLongPressArmed) {
                const float dx = x - listLongPressX;
                const float dy = y - listLongPressY;
                if (dx * dx + dy * dy > touchSlop * touchSlop) listLongPressArmed = false;
            }
            break;
        case PointerAction::Up:
        case PointerAction::Cancel:
            listLongPressArmed = false;
            if (listLongPressFired) {
                onTouchEventBase(PointerAction::Cancel, x, y);
                listLongPressFired = false;
                return;
            }
            break;
    }
    onTouchEventBase(action, x, y);
}

void SilvetonSamplerView::tick(std::int64_t now) {
    // the tablet's postDelayed(listLongPressRunnable, longPressTimeout)
    if (listLongPressArmed && now - listLongPressStartMs >= LONG_PRESS_MS) {
        const ListLongHit* target = listLongHitAt(listLongPressX, listLongPressY);
        if (target != nullptr) {
            const ListLongHit copy = *target;
            listLongPressArmed = false;
            listLongPressFired = true;
            hapticFeedback();
            copy.action(listLongPressX, listLongPressY);
            invalidate();
        } else {
            listLongPressArmed = false;
        }
    }
    tickDialogs(now);
}

void SilvetonSamplerView::onTouchEventBase(PointerAction action, float x, float y) {
    switch (action) {
        case PointerAction::Down: {
            pointerDown_ = true;
            downX = x;
            downY = y;
            downTimeMs = nowMs();
            dragMoved = false;
            activeHit = hitAt(downX, downY);
            // SILVETON_STRIP_SELECT_V1: touching ANYWHERE on an Upper strip selects that Upper;
            // the touched key / knob / fader still does its own job.
            if (page_ == Page::COMBI && !picker && !markMode && !(dropUpper >= 0 && dropUpper <= 6) && !(editSound == 5 && tab == UpperTab::EQ) &&
                inRange(downY, 108.0F, 468.0F) && downX >= 112.0F) {
                const float sw = (1214.0F - 6.0F * 8.0F) / 7.0F;
                const int k = static_cast<int>((downX - 112.0F) / (sw + 8.0F));
                if (k >= 0 && k <= 6 && downX <= 112.0F + static_cast<float>(k) * (sw + 8.0F) + sw && selectedUpper_ != k) selectedUpper_ = k;
            }
            postInvalidateOnAnimation();
            return;
        }
        case PointerAction::Move: {
            if (!pointerDown_) return;
            if (!activeHit) return;
            const std::shared_ptr<Hit> hit = activeHit;
            if (hit->drag) {
                const float dx = x - downX;
                const float dy = y - downY;
                if (!dragMoved && dx * dx + dy * dy >= touchSlop * touchSlop) dragMoved = true;
                if (dragMoved) {
                    hit->drag(x, y, false);
                    postInvalidateOnAnimation();
                }
            }
            return;
        }
        case PointerAction::Up: {
            if (!pointerDown_) return;
            const std::shared_ptr<Hit> hit = activeHit;
            const std::int64_t now = nowMs();
            // SILVETON_LIST_V2: swipe left / right over the BLENDS = next / previous page
            const auto pk = picker;
            if (page_ == Page::COMBI && pk && (!hit || !hit->drag) && inRange(downY, 204.0F, 786.0F) && std::fabs(x - downX) > 140.0F && std::fabs(y - downY) < 90.0F) {
                const int pages = std::max(1, (static_cast<int>(pickerItems(*pk).size()) + 39) / 40);
                pk->page = std::clamp(pk->page + (x < downX ? 1 : -1), 0, pages - 1);
                activeHit.reset(); pointerDown_ = false; dragMoved = false;
                postInvalidateOnAnimation();
                return;
            }
            if (page_ == Page::LIST && !writeOpen && (!hit || !hit->drag) && inRange(downY, 156.0F, 640.0F) && std::fabs(x - downX) > 140.0F && std::fabs(y - downY) < 90.0F) {
                const int pages = std::max(1, (static_cast<int>(listVisible().size()) + LIST_PER_PAGE - 1) / LIST_PER_PAGE);
                listPage = std::clamp(listPage + (x < downX ? 1 : -1), 0, pages - 1);
                activeHit.reset(); pointerDown_ = false; dragMoved = false;
                postInvalidateOnAnimation();
                return;
            }
            if (hit) {
                if (dragMoved && hit->drag) {
                    // One native commit at finger-up. MOVE stays local/vsync-fast.
                    hit->drag(x, y, true);
                } else {
                    const bool doubleTap = lastTapRect.has_value() && lastTapRect->contains(x, y) && now - lastTapTimeMs <= 280;
                    const bool held = now - downTimeMs >= 480;
                    if (doubleTap && hit->reset) {
                        hit->reset();
                        lastTapTimeMs = 0;
                        lastTapRect.reset();
                    } else if (held && hit->drag) {
                        // Long press keeps exact numeric entry available.
                        hit->tap(x, y);
                        lastTapTimeMs = 0;
                        lastTapRect.reset();
                    } else if (hit->drag) {
                        hit->drag(x, y, true);
                        lastTapTimeMs = now;
                        lastTapRect = hit->rect;
                    } else {
                        hit->tap(x, y);
                        lastTapTimeMs = now;
                        lastTapRect = hit->rect;
                    }
                }
            }
            activeHit.reset();
            pointerDown_ = false;
            dragMoved = false;
            postInvalidateOnAnimation();
            return;
        }
        case PointerAction::Cancel:
            activeHit.reset();
            pointerDown_ = false;
            dragMoved = false;
            postInvalidateOnAnimation();
            return;
    }
}

bool SilvetonSamplerView::handleSmoothRangeTouch(PointerAction action, float x, float y) {
    switch (action) {
        case PointerAction::Down: {
            std::shared_ptr<SmoothRangeHit> range;
            for (auto it = smoothRangeHits.rbegin(); it != smoothRangeHits.rend(); ++it) {
                if ((*it)->rect.contains(x, y)) { range = *it; break; }
            }
            if (range) {
                activeSmoothRange = range;
                smoothActive = true;
                const float span = range->maxValue - range->minValue;
                const float lowX = range->rect.left + range->rect.width() * std::clamp((range->low - range->minValue) / span, 0.0F, 1.0F);
                const float highX = range->rect.left + range->rect.width() * std::clamp((range->high - range->minValue) / span, 0.0F, 1.0F);
                activeSmoothRangeHigh = std::fabs(x - highX) < std::fabs(x - lowX);
                emitSmoothRange(*range, x);
                return true;
            }
            return false;
        }
        case PointerAction::Move:
            if (smoothActive && activeSmoothRange) { emitSmoothRange(*activeSmoothRange, x); return true; }
            return false;
        case PointerAction::Up:
            if (activeSmoothRange) {
                emitSmoothRange(*activeSmoothRange, x);
                activeSmoothRange.reset();
                smoothActive = false;
                return true;
            }
            return false;
        case PointerAction::Cancel:
            if (activeSmoothRange) {
                activeSmoothRange.reset();
                smoothActive = false;
                return true;
            }
            return false;
    }
    (void)y;
    return false;
}

void SilvetonSamplerView::registerSmoothRange(const RectF& r, float minValue, float maxValue, float step, float low, float high,
                                              std::function<void(float, float)> onChange) {
    auto h = std::make_shared<SmoothRangeHit>();
    h->rect = r;
    h->minValue = minValue;
    h->maxValue = maxValue;
    h->step = step;
    h->low = low;
    h->high = high;
    h->onChange = std::move(onChange);
    smoothRangeHits.push_back(std::move(h));
}

void SilvetonSamplerView::emitSmoothRange(SmoothRangeHit& h, float x) {
    if (h.rect.width() <= 1.0F) return;
    const float t = std::clamp((x - h.rect.left) / h.rect.width(), 0.0F, 1.0F);
    const float value = quantizeControl(h.minValue + (h.maxValue - h.minValue) * t, h.minValue, h.maxValue, h.step);
    if (activeSmoothRangeHigh) h.high = std::max(h.low, value); else h.low = std::min(h.high, value);
    h.onChange(h.low, h.high);
    invalidate();
}

float SilvetonSamplerView::quantizeControl(float value, float minValue, float maxValue, float step) {
    const float clamped = std::clamp(value, minValue, maxValue);
    if (step <= 0.0F) return clamped;
    const float q = std::nearbyint((clamped - minValue) / step) * step + minValue;   // Kotlin round(): ties to even
    return std::clamp(q, minValue, maxValue);
}

/** Relative knob: drag up or right to raise. Long press = exact number, double tap = default. */
void SilvetonSamplerView::knobHit(const RectF& r, float value, float minV, float maxV, float step, float travel,
                                  std::function<void(float)> onChange, std::function<void()> exact, std::function<void()> reset,
                                  std::function<void(float)> onFinal) {
    const float start = value;
    // SILVETON_FINE_KNOBS_V1: ten times finer steps than the display grid (whole-number controls with a small
    // range keep their steps), and a slow finger moves 4x finer.
    const float fine = (step >= 1.0F && maxV - minV <= 48.0F) ? step : step / 10.0F;
    float last = value;
    float acc = 0.0F;
    float prevD = 0.0F;
    hit(r, [exact](float, float) { exact(); }, std::move(reset),
        [this, start, fine, minV, maxV, travel, onChange, onFinal, last, acc, prevD](float x, float y, bool final) mutable {
            if (!dragMoved) return;
            const float d = (x - downX) - (y - downY);
            const float sgn = d > 0.0F ? 1.0F : (d < 0.0F ? -1.0F : 0.0F);
            const float moved = std::fabs(d) <= touchSlop ? 0.0F : d - sgn * touchSlop;
            const float delta = moved - prevD;
            prevD = moved;
            acc += delta * (std::fabs(delta) <= 2.0F ? 0.25F : 1.0F);
            const float nv = quantizeControl(start + acc / (travel * DRAG_SLOW) * (maxV - minV), minV, maxV, fine);
            if (nv != last) {
                last = nv;
                onChange(nv);
                invalidate();
            }
            if (final && onFinal) onFinal(nv);
        });
}

/** Relative vertical fader in dB. Long press = exact number, double tap = 0 dB. */
void SilvetonSamplerView::faderHit(const RectF& r, float levelDb, float travel, std::function<void(float)> onChange,
                                   std::function<void()> exact, std::function<void()> reset) {
    const float startT = faderT(levelDb);
    float last = levelDb;
    hit(r, [exact](float, float) { exact(); }, std::move(reset),
        [this, startT, travel, onChange, last](float, float y, bool) mutable {
            if (!dragMoved) return;
            const float d = downY - y;
            const float sgn = d > 0.0F ? 1.0F : (d < 0.0F ? -1.0F : 0.0F);
            const float moved = std::fabs(d) <= touchSlop ? 0.0F : d - sgn * touchSlop;
            const float nv = quantizeControl(faderDb(std::clamp(startT + moved / (travel * DRAG_SLOW), 0.0F, 1.0F)), -60.0F, 12.0F, 0.1F);
            if (nv != last) {
                last = nv;
                onChange(nv);
                invalidate();
            }
        });
}

// Fader law: -60..-24 dB, -24..0 dB and 0..+12 dB each take one third of the travel.
float SilvetonSamplerView::faderT(float db) {
    if (db <= -60.0F) return 0.0F;
    if (db < -24.0F) return (db + 60.0F) / 108.0F;
    if (db < 0.0F) return 1.0F / 3.0F + (db + 24.0F) / 72.0F;
    return 2.0F / 3.0F + std::min(db, 12.0F) / 36.0F;
}

float SilvetonSamplerView::faderDb(float t) {
    if (t <= 1.0F / 3.0F) return -60.0F + t * 108.0F;
    if (t <= 2.0F / 3.0F) return -24.0F + (t - 1.0F / 3.0F) * 72.0F;
    return (t - 2.0F / 3.0F) * 36.0F;
}

// ---------------------------------------------------------------- frame
bool SilvetonSamplerView::redrawDue(std::int64_t now) const {
    return invalidated_ || now >= nextRedrawMs_;
}

void SilvetonSamplerView::draw(Canvas& canvas) {
    invalidated_ = false;
    {
        std::lock_guard<std::mutex> lock(warningMutex_);
        if (pendingWarningSet_) {
            warning = pendingWarning_;
            pendingWarningSet_ = false;
        }
    }
    hits.clear();
    pairHits.clear();
    smoothRangeHits.clear();
    listLongHits.clear();
    {
        const int serial = sampler.bankSerial();
        if (serial != seenBankSerial_) {
            seenBankSerial_ = serial;
            if (serial > 0) refreshEverything();   // a bank was loaded (in the background): read Uppers, effects, LIST again
        }
    }
    const std::int64_t telemetryNow = nowMs();
    if (lastTelemetryMs == 0 || telemetryNow - lastTelemetryMs >= 50) {
        const int keyScanWas = sampler.keyScanUpper();
        scanMode = sampler.pollScan();
        if (keyScanWas >= 0 && sampler.keyScanUpper() < 0) {
            refreshUpper(keyScanWas);
            // LINK: the range found by SCAN goes to the other marked Uppers too
            const auto got = upperStates[static_cast<std::size_t>(keyScanWas)];
            if (got) {
                for (const int t : linkTargets(keyScanWas)) {
                    auto cur = upperStates[static_cast<std::size_t>(t)];
                    if (!cur) cur = sampler.upperState(t);
                    if (!cur) continue;
                    UpperState m = *cur;
                    m.keyLow = got->keyLow;
                    m.keyHigh = got->keyHigh;
                    upperStates[static_cast<std::size_t>(t)] = m;
                    if (!sampler.updateUpperMain(t, m)) refreshUpper(t);
                }
            }
        }
        frameAudioStatus = sampler.audioStatus();
        frameUpperMeters = sampler.upperMeters();
        frameMidiStatus = sampler.midiStatus();
        lastTelemetryMs = telemetryNow;
    }
    if (frameMidiStatus.activitySerial != lastMidiSerial) {
        lastMidiSerial = frameMidiStatus.activitySerial;
        midiFlashUntilMs = nowMs() + 220;
    }

    widthPx_ = canvas.width();
    heightPx_ = canvas.height();
    const float w = static_cast<float>(widthPx_);
    const float h = static_cast<float>(heightPx_);
    if (w <= 0.0F || h <= 0.0F) return;
    const float k = std::min(w / DESIGN_W, h / DESIGN_H);
    uiScale = k;
    uiOffsetX = (w - DESIGN_W * k) * 0.5F;
    uiOffsetY = (h - DESIGN_H * k) * 0.5F;
    paint.shader = nullptr;
    paint.style = Style::Fill;
    paint.color = C_SIDE_A;
    canvas.drawRect(RectF(0.0F, 0.0F, w, h), paint);

    canvas.save();
    canvas.translate(uiOffsetX, uiOffsetY);
    canvas.scale(k, k);
    drawMetal(canvas);
    drawSideNav(canvas);
    drawHeader(canvas);
    switch (page_) {
        case Page::LIST: drawList(canvas); break;
        case Page::COMBI: drawCombi(canvas); break;
        case Page::EFFECTS: drawEffects(canvas); break;
        case Page::SETTINGS: drawSettings(canvas); break;
    }
    if (warning) {
        const std::string msg = *warning;
        const RectF box(112.0F, 744.0F, 1326.0F, 786.0F);
        shadow(canvas, box, 10.0F, 3.0F, 90);
        fill(canvas, box, 10.0F, C_WARN_BG);
        text(canvas, msg, box.left + 16.0F, box.centerY() + 5.0F, 14.0F, C_WARN_TEXT, Opt().bold().maxW(box.width() - 120.0F));
        text(canvas, "СКРИЙ ×", box.right - 16.0F, box.centerY() + 5.0F, 12.0F, C_WARN_TEXT, Opt().right().bold().spacing(0.1F));
        hit(box, [this](float, float) { warning.reset(); });
    }
    if (writeOpen) {
        // Modal: only the WRITE screen answers touches while it is open.
        hits.clear();
        smoothRangeHits.clear();
        listLongHits.clear();
        drawWriteScreen(canvas);
    }
    if (dialogIsOpen()) {
        // The dialogs of the tablet (alert, list, number, text ...) are modal overlays here.
        hits.clear();
        pairHits.clear();
        smoothRangeHits.clear();
        listLongHits.clear();
        drawDialogs(canvas);
    }
    canvas.restore();

    const std::int64_t now = nowMs();
    if ((activeHit && activeHit->drag) || activeSmoothRange) nextRedrawMs_ = now;   // postInvalidateOnAnimation
    else nextRedrawMs_ = std::min<std::int64_t>(now + 100, delayedRedrawMs_);       // postInvalidateDelayed(100) and the shorter ones of the pages
    delayedRedrawMs_ = std::numeric_limits<std::int64_t>::max();
}

void SilvetonSamplerView::postInvalidateDelayed(int ms) {
    delayedRedrawMs_ = std::min<std::int64_t>(delayedRedrawMs_, nowMs() + ms);
}

void SilvetonSamplerView::drawMetal(Canvas& c) {
    paint.style = Style::Fill;
    paint.color = Color::BLACK;
    if (darkTheme) {   // SILVETON_THEME_V1: deep panel, lighter towards the middle
        paint.shader = radialGradient(DESIGN_W * 0.55F, DESIGN_H * 0.4F, DESIGN_W * 0.9F, Color::rgb(42, 44, 50), C_METAL_A, TileMode::Clamp);
        c.drawRect(RectF(0.0F, 0.0F, DESIGN_W, DESIGN_H), paint);
        paint.shader = nullptr;
        return;
    }
    paint.shader = linearGradient(0.0F, 0.0F, 4.0F, 0.0F, std::vector<ColorInt>{C_METAL_A, C_METAL_A, C_METAL_B, C_METAL_B},
                                  std::vector<float>{0.0F, 0.5F, 0.5F, 1.0F}, TileMode::Repeat);
    c.drawRect(RectF(0.0F, 0.0F, DESIGN_W, DESIGN_H), paint);
    paint.shader = nullptr;
}

// SILVETON_THEME_V1: the wooden side of the dark theme (walnut), drawn once into a bitmap.
std::shared_ptr<Image> SilvetonSamplerView::wood() {
    if (woodBitmap_) return woodBitmap_;
    const int bw = 96;
    const int bh = 800;
    Canvas cv(bw, bh);
    Paint p;
    p.antiAlias = true;
    p.shader = linearGradient(0.0F, 0.0F, static_cast<float>(bw), 0.0F,
                              std::vector<ColorInt>{Color::rgb(78, 48, 28), Color::rgb(118, 74, 42), Color::rgb(96, 58, 34), Color::rgb(70, 42, 24)},
                              std::vector<float>{0.0F, 0.35F, 0.7F, 1.0F}, TileMode::Clamp);
    cv.drawRect(RectF(0.0F, 0.0F, static_cast<float>(bw), static_cast<float>(bh)), p);
    p.shader = nullptr;
    p.style = Style::Stroke;
    JavaRandom rnd(7);
    for (int k = 0; k < 70; ++k) {   // grain: wavy vertical lines, darker and lighter
        const float x0 = rnd.nextFloat() * static_cast<float>(bw);
        const float amp = 2.0F + rnd.nextFloat() * 6.0F;
        const float per = 120.0F + rnd.nextFloat() * 260.0F;
        const float ph = rnd.nextFloat() * 6.28F;
        const bool dark = rnd.nextBoolean();
        if (dark) p.color = Color::argb(28 + rnd.nextInt(30), 20, 10, 4);
        else p.color = Color::argb(18 + rnd.nextInt(20), 220, 170, 110);
        p.strokeWidth = 0.6F + rnd.nextFloat() * 1.6F;
        Path path;
        path.moveTo(x0 + amp * std::sin(ph), 0.0F);
        float y = 0.0F;
        while (y < static_cast<float>(bh)) {
            y += 8.0F;
            path.lineTo(x0 + amp * std::sin(ph + y / per * 6.28F), y);
        }
        cv.drawPath(path, p);
    }
    woodBitmap_ = std::make_shared<Image>(cv.takeImage());
    return woodBitmap_;
}

// ---------------------------------------------------------------- commits
// SILVETON_MARK_LINK_V1: one group of the Upper is sent natively; with LINK on, only the fields that CHANGED
// are copied (same value) onto the other marked Uppers - the rest of those Uppers stays as it is.
void SilvetonSamplerView::commitGroup(int u, const UpperState& s, const std::function<bool(int, const UpperState&)>& send,
                                      const std::function<UpperState(const UpperState&, const UpperState&, const UpperState&)>& merge) {
    const auto old = upperStates[static_cast<std::size_t>(u)];
    upperStates[static_cast<std::size_t>(u)] = s;
    if (!send(u, s)) refreshUpper(u);
    if (!old) return;
    for (const int t : linkTargets(u)) {
        auto cur = upperStates[static_cast<std::size_t>(t)];
        if (!cur) cur = sampler.upperState(t);
        if (!cur) continue;
        const UpperState m = merge(*old, s, *cur);
        upperStates[static_cast<std::size_t>(t)] = m;
        if (!send(t, m)) refreshUpper(t);
    }
}

void SilvetonSamplerView::commitMain(int i, const UpperState& s) {
    commitGroup(i, s, [this](int t, const UpperState& st) { return sampler.updateUpperMain(t, st); },
        [](const UpperState& o, const UpperState& n, const UpperState& c) {
            UpperState r = c;
            r.enabled = chg(o.enabled, n.enabled, c.enabled); r.solo = chg(o.solo, n.solo, c.solo); r.mute = chg(o.mute, n.mute, c.mute);
            r.levelDb = chg(o.levelDb, n.levelDb, c.levelDb); r.pan = chg(o.pan, n.pan, c.pan);
            r.keyLow = chg(o.keyLow, n.keyLow, c.keyLow); r.keyHigh = chg(o.keyHigh, n.keyHigh, c.keyHigh);
            r.voiceMode = chg(o.voiceMode, n.voiceMode, c.voiceMode);
            return r;
        });
}

void SilvetonSamplerView::commitTune(const UpperState& s) {
    commitGroup(selectedUpper_, s, [this](int t, const UpperState& st) { return sampler.updateUpperTune(t, st); },
        [](const UpperState& o, const UpperState& n, const UpperState& c) {
            UpperState r = c;
            r.octave = chg(o.octave, n.octave, c.octave); r.transpose = chg(o.transpose, n.transpose, c.transpose);
            r.fineCents = chg(o.fineCents, n.fineCents, c.fineCents); r.pitchBendRange = chg(o.pitchBendRange, n.pitchBendRange, c.pitchBendRange);
            r.portamentoSec = chg(o.portamentoSec, n.portamentoSec, c.portamentoSec);
            return r;
        });
}

void SilvetonSamplerView::commitRange(const UpperState& s) {
    commitGroup(selectedUpper_, s, [this](int t, const UpperState& st) { return sampler.updateUpperRange(t, st); },
        [](const UpperState& o, const UpperState& n, const UpperState& c) {
            UpperState r = c;
            r.velocityLow = chg(o.velocityLow, n.velocityLow, c.velocityLow); r.velocityHigh = chg(o.velocityHigh, n.velocityHigh, c.velocityHigh);
            return r;
        });
}

void SilvetonSamplerView::commitControlFor(int u, const UpperState& s) {
    commitGroup(u, s, [this](int t, const UpperState& st) { return sampler.updateUpperControl(t, st); },
        [](const UpperState& o, const UpperState& n, const UpperState& c) {
            UpperState r = c;
            r.breath = chg(o.breath, n.breath, c.breath); r.expression = chg(o.expression, n.expression, c.expression);
            r.aftertouch = chg(o.aftertouch, n.aftertouch, c.aftertouch); r.damper = chg(o.damper, n.damper, c.damper);
            r.midiChannel = chg(o.midiChannel, n.midiChannel, c.midiChannel);
            return r;
        });
}

void SilvetonSamplerView::commitTone(const UpperState& s) {
    commitGroup(selectedUpper_, s, [this](int t, const UpperState& st) { return sampler.updateUpperTone(t, st); },
        [](const UpperState& o, const UpperState& n, const UpperState& c) {
            UpperState r = c;
            r.attackScale = chg(o.attackScale, n.attackScale, c.attackScale); r.decayScale = chg(o.decayScale, n.decayScale, c.decayScale);
            r.sustainScale = chg(o.sustainScale, n.sustainScale, c.sustainScale); r.releaseScale = chg(o.releaseScale, n.releaseScale, c.releaseScale);
            r.cutoffOctaves = chg(o.cutoffOctaves, n.cutoffOctaves, c.cutoffOctaves); r.resonanceOffset = chg(o.resonanceOffset, n.resonanceOffset, c.resonanceOffset);
            r.lfoRateScale = chg(o.lfoRateScale, n.lfoRateScale, c.lfoRateScale); r.lfoDepthScale = chg(o.lfoDepthScale, n.lfoDepthScale, c.lfoDepthScale);
            r.eqLowDb = chg(o.eqLowDb, n.eqLowDb, c.eqLowDb); r.eqMidDb = chg(o.eqMidDb, n.eqMidDb, c.eqMidDb); r.eqHighDb = chg(o.eqHighDb, n.eqHighDb, c.eqHighDb);
            return r;
        });
}

void SilvetonSamplerView::commitUpperFx(const UpperState& s) {
    commitGroup(selectedUpper_, s, [this](int t, const UpperState& st) { return sampler.updateUpperFx(t, st); },
        [](const UpperState& o, const UpperState& n, const UpperState& c) {
            UpperState r = c;
            r.fxSend1 = chg(o.fxSend1, n.fxSend1, c.fxSend1); r.fxSend2 = chg(o.fxSend2, n.fxSend2, c.fxSend2);
            return r;
        });
}

void SilvetonSamplerView::commitGlobal(const GlobalUiState& g) {
    globalState = g;
    if (!sampler.updateGlobalUi(g)) refreshGlobal();
}

void SilvetonSamplerView::refreshUpper(int i) { upperStates[static_cast<std::size_t>(i)] = sampler.upperState(i); dropParamCaches(i); }
void SilvetonSamplerView::refreshAllUppers() { for (int i = 0; i < 7; ++i) refreshUpper(i); }

void SilvetonSamplerView::refreshFx() {
    fxState = sampler.combiFxState();
    for (auto& slot : fxParamsCache) slot.reset();
}

void SilvetonSamplerView::refreshGlobal() { globalState = sampler.globalUiState(); }

/** MASTER changed from outside the screen. */
void SilvetonSamplerView::globalChangedOutside() { refreshGlobal(); invalidate(); }

void SilvetonSamplerView::refreshListCache() {
    cachedListItems = sampler.listItems(0, 0, 0);
    cachedActiveListEntry = sampler.activeListEntry(0, 0, 0);
    listCacheLoaded = true;
}

void SilvetonSamplerView::hit(const RectF& r, std::function<void(float, float)> tap, std::function<void()> reset,
                              std::function<void(float, float, bool)> drag) {
    auto h = std::make_shared<Hit>();
    h->rect = r;
    h->tap = std::move(tap);
    h->reset = std::move(reset);
    h->drag = std::move(drag);
    hits.push_back(std::move(h));
}

std::shared_ptr<SilvetonSamplerView::Hit> SilvetonSamplerView::hitAt(float x, float y) {
    for (auto it = hits.rbegin(); it != hits.rend(); ++it) {
        if ((*it)->rect.contains(x, y)) return *it;
    }
    return nullptr;
}

void SilvetonSamplerView::listLongHit(const RectF& r, std::function<void(float, float)> action) {
    listLongHits.push_back(ListLongHit{r, std::move(action)});
}

const SilvetonSamplerView::ListLongHit* SilvetonSamplerView::listLongHitAt(float x, float y) const {
    for (auto it = listLongHits.rbegin(); it != listLongHits.rend(); ++it) {
        if (it->rect.contains(x, y)) return &*it;
    }
    return nullptr;
}

bool SilvetonSamplerView::isDown(const RectF& r) const {
    if (!activeHit) return false;
    if (dragMoved) return false;
    const RectF& h = activeHit->rect;
    return std::fabs(h.left - r.left) < 0.5F && std::fabs(h.top - r.top) < 0.5F &&
           std::fabs(h.right - r.right) < 0.5F && std::fabs(h.bottom - r.bottom) < 0.5F;
}

} // namespace silveton::ui
