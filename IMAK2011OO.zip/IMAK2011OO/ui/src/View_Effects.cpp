// SILVETON_MAC_VIEW_V1 - the EFFECTS page (tablet SilvetonSamplerView.kt lines 2582-2721)
#include "silveton/ui/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui {

namespace {
float at(const std::vector<float>& v, std::size_t i, float def) { return i < v.size() ? v[i] : def; }
// Kotlin's kotlin.math.ln on a Float computes in double and rounds back to float.
float lnf(float x) { return static_cast<float>(std::log(static_cast<double>(x))); }
float roundf_(float v) { return std::nearbyint(v); }   // kotlin.math.round(Float)

float reverbSeconds(float feedback) {
    const float f = std::clamp(feedback, 0.0F, 0.95F);
    return 0.6F * static_cast<float>(std::pow(20.0, static_cast<double>(f / 0.95F)));
}
float reverbFeedbackFor(float seconds) {
    return std::clamp(0.95F * (lnf(std::clamp(seconds, 0.6F, 12.0F) / 0.6F) / lnf(20.0F)), 0.0F, 0.95F);
}

// One knob of an effect: id into the FX params, label, min, max, step, how it is shown.
struct FxKnob {
    int id;
    std::string label;
    float minV;
    float maxV;
    float step;
    float def;
    std::function<std::string(float)> show;
    int decimals;
};

std::vector<FxKnob> fxKnobsFor(int type) {
    const auto pct = [](float v) { return fmtFixed(static_cast<double>(v * 100.0F), 2) + " %"; };
    const auto ms = [](float v) {
        if (v < 1000.0F) return std::to_string(static_cast<int>(roundf_(v))) + " ms";
        return fmtFixed(static_cast<double>(v / 1000.0F), 2) + " s";
    };
    const auto hz = [](float v) { return fmtFixed(static_cast<double>(v), 2) + " Hz"; };
    const auto whole = [](float v) { return std::to_string(static_cast<int>(v)); };
    const auto db2 = [](float v) { return fmtFixed(static_cast<double>(v), 2) + " dB"; };
    const FxKnob wet{1, "WET", 0.0F, 1.0F, 0.01F, 0.3F, pct, 0};
    const std::vector<FxKnob> reverb = {
        wet, {7, "PRE-DELAY", 0.0F, 200.0F, 1.0F, 10.0F, ms, 0},
        {3, "DECAY", 0.0F, 0.95F, 0.005F, 0.6F, [](float v) { return fmtFixed(static_cast<double>(reverbSeconds(v)), 2) + " s"; }, 1},
        {6, "TONE", 0.0F, 1.0F, 0.01F, 0.6F, pct, 0}, {8, "DAMPING", 0.0F, 1.0F, 0.01F, 0.4F, pct, 0},
        {9, "SIZE", 0.0F, 1.0F, 0.01F, 0.5F, pct, 0}, {10, "MOD", 0.0F, 1.0F, 0.01F, 0.3F, pct, 0}};
    const std::vector<FxKnob> delay = {wet, {2, "TIME", 1.0F, 2500.0F, 1.0F, 320.0F, ms, 0}, {3, "FEEDBACK", 0.0F, 0.95F, 0.005F, 0.25F, pct, 0},
                                       {6, "TONE", 0.0F, 1.0F, 0.01F, 0.5F, pct, 0}};
    const auto plus = [&delay](const FxKnob& extra, const FxKnob* second = nullptr) {
        std::vector<FxKnob> v = delay;
        v.push_back(extra);
        if (second != nullptr) v.push_back(*second);
        return v;
    };
    switch (type) {
        case 1: return delay;
        case 8: { const FxKnob a{10, "WOW/FLUTTER", 0.0F, 1.0F, 0.01F, 0.3F, pct, 0}; const FxKnob b{5, "SATURATION", 0.0F, 1.0F, 0.01F, 0.35F, pct, 0}; return plus(a, &b); }
        case 9: return delay;
        case 10: return plus({5, "SPREAD", 0.0F, 1.0F, 0.01F, 0.35F, pct, 0});
        case 11: return plus({5, "DUCKING", 0.0F, 1.0F, 0.01F, 0.6F, pct, 0});
        case 2: return {wet, {4, "RATE", 0.02F, 8.0F, 0.01F, 0.8F, hz, 2}, {5, "DEPTH", 0.0F, 1.0F, 0.01F, 0.35F, pct, 0}, {6, "TONE", 0.0F, 1.0F, 0.01F, 0.5F, pct, 0},
                        {14, "VOICES", 2.0F, 4.0F, 1.0F, 3.0F, whole, 0}};
        case 12: return {wet, {4, "RATE", 0.02F, 8.0F, 0.01F, 0.3F, hz, 2}, {5, "DEPTH", 0.0F, 1.0F, 0.01F, 0.5F, pct, 0}, {3, "FEEDBACK", -0.95F, 0.95F, 0.01F, 0.4F, pct, 0}};
        case 17: return {wet, {4, "SPEED", 0.1F, 2.0F, 0.01F, 0.6F, hz, 2}, {5, "DEPTH", 0.0F, 1.0F, 0.01F, 0.7F, pct, 0}};
        case 13: return {wet, {4, "RATE", 0.02F, 8.0F, 0.01F, 0.4F, hz, 2}, {5, "DEPTH", 0.0F, 1.0F, 0.01F, 0.6F, pct, 0}, {3, "FEEDBACK", 0.0F, 0.9F, 0.01F, 0.3F, pct, 0},
                         {14, "STAGES", 4.0F, 8.0F, 2.0F, 6.0F, whole, 0}};
        case 14: return {wet, {4, "SLOW Hz", 0.1F, 2.0F, 0.01F, 0.8F, hz, 2}, {14, "FAST Hz", 2.0F, 10.0F, 0.1F, 6.5F, hz, 1}, {5, "DEPTH", 0.0F, 1.0F, 0.01F, 0.6F, pct, 0},
                         {15, "SPEED", 0.0F, 1.0F, 1.0F, 0.0F, [](float v) { return std::string(v >= 0.5F ? "FAST" : "SLOW"); }, 0}};
        case 15: return {{14, "THRESHOLD", -60.0F, 0.0F, 0.5F, -20.0F, db2, 1},
                         {15, "RATIO", 1.0F, 20.0F, 0.1F, 4.0F, [](float v) { return fmtFixed(static_cast<double>(v), 1) + " : 1"; }, 1},
                         {2, "ATTACK", 0.1F, 300.0F, 0.1F, 10.0F, ms, 1}, {16, "RELEASE", 10.0F, 3000.0F, 1.0F, 120.0F, ms, 0},
                         {6, "MAKE-UP", 0.0F, 24.0F, 0.1F, 0.0F, db2, 1}};
        case 16: return {wet, {5, "DRIVE", 0.0F, 1.0F, 0.01F, 0.4F, pct, 0}, {6, "TONE", 0.0F, 1.0F, 0.01F, 0.6F, pct, 0}, {14, "OUTPUT", -24.0F, 12.0F, 0.5F, 0.0F, db2, 1}};
        case 3: case 4: case 5: case 6: case 7: return reverb;
        default: return {};
    }
}
} // namespace

void SilvetonSamplerView::drawEffects(Canvas& c) {
    // SILVETON_FX_V3: FX1..FX4 (common sends) and INSERT of every Upper; one big board.
    std::vector<std::string> names;
    for (int i = 1; i <= 4; ++i) names.push_back("FX" + std::to_string(i));
    for (int i = 1; i <= 7; ++i) names.push_back("INS U" + std::to_string(i));
    const float kw = (1214.0F - 10.0F * 6.0F) / 11.0F;
    for (int k = 0; k < 11; ++k) {
        const float fk = static_cast<float>(k);
        const RectF r(112.0F + fk * (kw + 6.0F), 108.0F, 112.0F + fk * (kw + 6.0F) + kw, 146.0F);
        const int t = static_cast<int>(at(fxP(k), 0U, 0.0F));
        stripToggle(c, r, names[static_cast<std::size_t>(k)] + (t != 0 ? " ●" : ""), fxUnitFocus == k, C_AMBER, 11.0F);
        hit(r, [this, k](float, float) { fxUnitFocus = k; });
    }
    drawFxBoardV3(c, RectF(112.0F, 154.0F, 1326.0F, 722.0F), fxUnitFocus);
    std::optional<CombiFxState> fx = fxState;
    if (!fx) { fx = sampler.combiFxState(); if (fx) fxState = fx; }
    const RectF route(112.0F, 734.0F, 1326.0F, 786.0F);
    const int routing = fx ? fx->routing : 0;
    lightKey(c, route, routing == 0 ? "ROUTING:   FX1 + FX2   ПАРАЛЕЛНО" : "ROUTING:   FX1 → FX2   ПОСЛЕДОВАТЕЛНО", true, 14.0F);
    hit(route, [this, routing](float, float) {
            const int next = routing == 0 ? 1 : 0;
            if (sampler.updateCombiFxRouting(next)) refreshFx();
        },
        [this]() { if (sampler.updateCombiFxRouting(0)) refreshFx(); });
}

void SilvetonSamplerView::drawFxBoardV3(Canvas& c, const RectF& r, int unit) {
    board(c, r);
    const std::vector<float> p = fxP(unit);
    const int type = static_cast<int>(at(p, 0U, 0.0F));
    const std::string title = unit < 4 ? "FX" + std::to_string(unit + 1) : "INSERT U" + std::to_string(unit - 3);
    text(c, title, r.left + 22.0F, r.top + 42.0F, 24.0F, C_AMBER, Opt().monoBold());
    // type keys: two rows of 9 (17 types)
    static const char* const typeNames[] = {"OFF", "DIGITAL DLY", "CHORUS", "PLATE", "HALL", "ROOM", "CHAMBER", "SPRING", "TAPE DLY", "PING-PONG",
                                            "MULTI-TAP", "DUCK DLY", "FLANGER", "PHASER", "ROTARY", "COMP", "DRIVE", "ENSEMBLE"};
    static const int order[] = {0, 4, 3, 5, 6, 7, 1, 8, 9, 10, 11, 2, 17, 12, 13, 14, 15, 16};
    const float tx0 = r.left + 200.0F;
    const float tw = (r.right - 20.0F - tx0 - 8.0F * 6.0F) / 9.0F;
    for (int k = 0; k < 18; ++k) {
        const int t = order[k];
        const float row = static_cast<float>(k / 9);
        const float col = static_cast<float>(k % 9);
        const RectF b(tx0 + col * (tw + 6.0F), r.top + 14.0F + row * 40.0F, tx0 + col * (tw + 6.0F) + tw, r.top + 48.0F + row * 40.0F);
        segKey(c, b, typeNames[t], type == t, 11.0F);
        hit(b, [this, unit, t](float, float) { setFxP(unit, 0, static_cast<float>(t)); });
    }
    const RectF sec(r.left + 16.0F, r.top + 104.0F, r.right - 16.0F, r.bottom - 16.0F);
    section(c, sec, "ПАРАМЕТРИ · " + effectName(type));
    const std::vector<FxKnob> knobs = fxKnobsFor(type);
    if (knobs.empty()) {
        text(c, title + " е изключен. Избери ефект отгоре.", sec.centerX(), sec.top + 160.0F, 16.0F, C_KNOB_LABEL, Opt().center().maxW(sec.width() - 40.0F));
        return;
    }
    const int n = static_cast<int>(knobs.size());
    for (int k = 0; k < n; ++k) {
        const FxKnob kn = knobs[static_cast<std::size_t>(k)];
        const float cx = sec.left + sec.width() * (static_cast<float>(k) + 0.5F) / static_cast<float>(n);
        const float cy = sec.top + 150.0F;
        const float v = at(p, static_cast<std::size_t>(kn.id), kn.def);
        const std::function<void(float)> apply = [this, unit, kn](float nv) {
            setFxP(unit, kn.id, kn.step >= 1.0F ? roundf_(nv / kn.step) * kn.step : nv);
        };
        const bool reverbType = type >= 3 && type <= 7;
        knobControl(c, cx, cy, 40.0F, v, kn.minV, kn.maxV, kn.step, 300.0F, kn.minV < 0.0F && kn.maxV > 0.0F, kn.show(v), kn.label,
                    std::min(200.0F, sec.width() / static_cast<float>(n) - 10.0F),
                    [apply](float nv) { apply(nv); },
                    [this, kn, v, title, apply, reverbType]() {
                        if (kn.id == 3 && reverbType) {
                            showNumber(title + " DECAY s", reverbSeconds(v), 0.6F, 12.0F, 1, [apply](float it) { apply(reverbFeedbackFor(it)); }, true,
                                       [apply, v]() { apply(v); });
                        } else if (kn.maxV <= 1.0F && kn.minV >= -1.0F && kn.step < 1.0F) {
                            showNumber(title + " " + kn.label + " %", v * 100.0F, kn.minV * 100.0F, kn.maxV * 100.0F, 0,
                                       [apply, kn](float it) { apply(std::clamp(it / 100.0F, kn.minV, kn.maxV)); }, true, [apply, v]() { apply(v); });
                        } else {
                            showNumber(title + " " + kn.label, v, kn.minV, kn.maxV, kn.decimals, [apply](float it) { apply(it); });
                        }
                    },
                    [apply, kn]() { apply(kn.def); });
    }
    // delays: tempo sync keys
    if (type == 1 || type == 8 || type == 9 || type == 10 || type == 11) {
        const bool sync = at(p, 11U, 0.0F) >= 0.5F;
        const float y = sec.top + 300.0F;
        const RectF sr(sec.left + 16.0F, y, sec.left + 176.0F, y + 44.0F);
        stripToggle(c, sr, "TEMPO SYNC", sync, C_AMBER, 12.0F);
        hit(sr, [this, unit, sync](float, float) { setFxP(unit, 11, sync ? 0.0F : 1.0F); });
        const float bpm = at(p, 12U, 120.0F);
        const RectF br(sec.left + 188.0F, y, sec.left + 348.0F, y + 44.0F);
        lightKey(c, br, std::to_string(static_cast<int>(bpm)) + " BPM", sync, 13.0F);
        hit(br, [this, unit, bpm](float, float) {
            showNumber("TEMPO (BPM)", bpm, 30.0F, 300.0F, 0, [this, unit](float it) { setFxP(unit, 12, roundf_(it)); });
        });
        const RectF tapR(sec.left + 360.0F, y, sec.left + 470.0F, y + 44.0F);
        lightKey(c, tapR, "TAP", sync, 13.0F);
        hit(tapR, [this, unit](float, float) { tapTempo(unit); });
        static const std::pair<float, const char*> divs[] = {{0.25F, "1/4"}, {0.1875F, "1/8."}, {0.125F, "1/8"}, {0.0833333F, "1/8T"}, {0.0625F, "1/16"}, {0.5F, "1/2"}};
        const float cur = at(p, 13U, 0.25F);
        for (int k = 0; k < 6; ++k) {
            const float d = divs[k].first;
            const RectF dr(sec.left + 490.0F + static_cast<float>(k) * 96.0F, y, sec.left + 578.0F + static_cast<float>(k) * 96.0F, y + 44.0F);
            stripToggle(c, dr, divs[k].second, sync && std::fabs(cur - d) < 0.002F, C_AMBER, 12.0F);
            hit(dr, [this, unit, d](float, float) { setFxP(unit, 13, d); });
        }
    }
    if (unit < 4) {
        const int slot = unit + 1;
        std::string sends;
        for (int uu = 0; uu < 7; ++uu) {
            const auto& st = upperStates[static_cast<std::size_t>(uu)];
            if (!st) continue;
            float send = 0.0F;
            switch (slot) {
                case 1: send = st->fxSend1; break;
                case 2: send = st->fxSend2; break;
                case 3: send = at(uParams(uu), 46U, 0.0F); break;
                default: send = at(uParams(uu), 47U, 0.0F); break;
            }
            if (send > 0.004F && st->soundName != "EMPTY" && st->enabled) {
                if (!sends.empty()) sends += "   ";
                sends += "U" + std::to_string(uu + 1) + " " + std::to_string(static_cast<int>(roundf_(send * 100.0F))) + "%";
            }
        }
        const float y = sec.bottom - 60.0F;
        text(c, "ПРАЩАТ КЪМ FX" + std::to_string(slot), sec.left + 16.0F, y, 11.0F, C_SECTION_TITLE, Opt().spacing(0.25F));
        text(c, sends.empty() ? "Никой UPPER не праща тук – вдигни FX" + std::to_string(slot) + " SEND (КОМБИ → FX)" : sends,
             sec.left + 16.0F, y + 28.0F, 15.0F, sends.empty() ? C_AMBER : C_LCD_OK, Opt().monoBold().maxW(sec.width() - 32.0F));
    }
}

void SilvetonSamplerView::tapTempo(int unit) {
    const std::int64_t now = nowMs();
    if (!tapTimes.empty() && now - tapTimes.back() > 2000) tapTimes.clear();
    tapTimes.push_back(now);
    if (tapTimes.size() >= 2) {
        const float avg = static_cast<float>(tapTimes.back() - tapTimes.front()) / static_cast<float>(tapTimes.size() - 1);
        setFxP(unit, 12, std::clamp(roundf_(60000.0F / avg), 30.0F, 300.0F));
        setFxP(unit, 11, 1.0F);
    }
    if (tapTimes.size() > 8) tapTimes.erase(tapTimes.begin());
}

} // namespace silveton::ui
