#pragma once
// SILVETON_MAC_UI_SUPPORT_V1 - the small everyday helpers the screens of the tablet got from Kotlin / Java / Android:
// clock, number formatting like Java's String.format, Java's random numbers, file and folder helpers, and the saved settings.

#include <cstdint>
#include <functional>
#include <map>
#include <mutex>
#include <optional>
#include <string>
#include <vector>

namespace silveton::ui {

// ------------------------------------------------------------------ clock (milliseconds since the program started)
std::int64_t nowMs();
// Tests can run time by hand: a fixed clock instead of the real one (pass a negative value to return to the real clock).
void setFixedClockForTests(std::int64_t ms);

// ------------------------------------------------------------------ text
// Java's String.format("%.Nf") rounds a tie upward (0.125 -> "0.13"); C's printf rounds a tie to even. This is Java's way.
std::string fmtFixed(double value, int decimals);
// "%03d"-like: whole number padded with zeros to at least `width` digits (negative numbers get the sign in front).
std::string fmtZeroPad(long long value, int width);
std::string toStr(long long value);
std::string trimmed(const std::string& s);                          // Kotlin trim(): white space at both ends
bool isBlank(const std::string& s);
std::optional<int> toIntOrNull(const std::string& s);               // Kotlin toIntOrNull(): whole text must be a number
std::optional<long long> toLongOrNull(const std::string& s);
std::optional<float> toFloatOrNull(const std::string& s);
std::vector<std::string> splitChar(const std::string& s, char sep);   // like Kotlin split(char): keeps empty parts
bool startsWith(const std::string& s, const std::string& prefix);
bool endsWith(const std::string& s, const std::string& suffix);
std::string replaceAll(std::string s, const std::string& from, const std::string& to);

// ------------------------------------------------------------------ java.util.Random (same numbers for the same seed)
class JavaRandom {
public:
    explicit JavaRandom(std::int64_t seed);
    int nextInt();
    int nextInt(int bound);
    bool nextBoolean();
    float nextFloat();
private:
    int next(int bits);
    std::int64_t seed_;
};

// ------------------------------------------------------------------ files and folders (plain POSIX; no std::filesystem on the old Mac system)
namespace files {
bool isFile(const std::string& path);
bool isDirectory(const std::string& path);
bool exists(const std::string& path);
long long fileSize(const std::string& path);                        // -1 when missing
long long lastModifiedMs(const std::string& path);                  // 0 when missing
bool makeDirectories(const std::string& path);
bool removeRecursively(const std::string& path);
bool copyFile(const std::string& from, const std::string& to);      // overwrites
bool copyRecursively(const std::string& from, const std::string& to);   // overwrites
std::vector<std::string> listNames(const std::string& dir);         // names only, no "." and ".."
std::string join(const std::string& dir, const std::string& name);
std::string parentOf(const std::string& path);
std::string nameOf(const std::string& path);
std::string absolute(const std::string& path);
bool readText(const std::string& path, std::string& out);
bool writeText(const std::string& path, const std::string& text);
std::string homeDirectory();
bool readable(const std::string& path);
} // namespace files

// ------------------------------------------------------------------ saved settings (the tablet's SharedPreferences)
// One small text file "key=value" per line. Thread safe.
class Prefs {
public:
    explicit Prefs(std::string path = {});
    int getInt(const std::string& key, int def) const;
    bool getBool(const std::string& key, bool def) const;
    std::string getString(const std::string& key, const std::string& def) const;
    void putInt(const std::string& key, int value);
    void putBool(const std::string& key, bool value);
    void putString(const std::string& key, const std::string& value);
    // Several values in one go (one write of the file)
    void putAll(const std::vector<std::pair<std::string, std::string>>& values);
private:
    void load();
    void save() const;
    std::string path_;
    mutable std::mutex mutex_;
    std::map<std::string, std::string> values_;
};

} // namespace silveton::ui
