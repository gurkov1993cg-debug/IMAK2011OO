#pragma once
// SILVETON_MAC_GFX_V1 - the drawing layer of the Mac sampler.
// A small software renderer with the same vocabulary as the tablet's Android Canvas / Paint / Path / Shader, so the
// screens could be carried over one to one. It draws into a plain pixel buffer (premultiplied BGRA, 0xAARRGGBB),
// which the Mac shell shows in its window and the tests write to PNG files. No system drawing library is used,
// so a picture is the same on the iMac and on the Linux test machine.

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace silveton::ui {

// ------------------------------------------------------------------ colours (Android style: 0xAARRGGBB)
using ColorInt = std::uint32_t;

struct Color {
    static constexpr ColorInt argb(int a, int r, int g, int b) noexcept {
        return (static_cast<ColorInt>(a & 255) << 24) | (static_cast<ColorInt>(r & 255) << 16) |
               (static_cast<ColorInt>(g & 255) << 8) | static_cast<ColorInt>(b & 255);
    }
    static constexpr ColorInt rgb(int r, int g, int b) noexcept { return argb(255, r, g, b); }
    static constexpr int alpha(ColorInt c) noexcept { return static_cast<int>((c >> 24) & 255U); }
    static constexpr int red(ColorInt c) noexcept { return static_cast<int>((c >> 16) & 255U); }
    static constexpr int green(ColorInt c) noexcept { return static_cast<int>((c >> 8) & 255U); }
    static constexpr int blue(ColorInt c) noexcept { return static_cast<int>(c & 255U); }
    static constexpr ColorInt WHITE = 0xFFFFFFFFU;
    static constexpr ColorInt BLACK = 0xFF000000U;
    static constexpr ColorInt TRANSPARENT = 0x00000000U;
};

// ------------------------------------------------------------------ geometry
struct RectF {
    float left{0.0F}, top{0.0F}, right{0.0F}, bottom{0.0F};
    RectF() = default;
    RectF(float l, float t, float r, float b) : left(l), top(t), right(r), bottom(b) {}
    [[nodiscard]] float width() const noexcept { return right - left; }
    [[nodiscard]] float height() const noexcept { return bottom - top; }
    [[nodiscard]] float centerX() const noexcept { return (left + right) * 0.5F; }
    [[nodiscard]] float centerY() const noexcept { return (top + bottom) * 0.5F; }
    // Android: left <= x < right, top <= y < bottom
    [[nodiscard]] bool contains(float x, float y) const noexcept { return x >= left && x < right && y >= top && y < bottom; }
    [[nodiscard]] bool isEmpty() const noexcept { return !(left < right && top < bottom); }
    void set(float l, float t, float r, float b) noexcept { left = l; top = t; right = r; bottom = b; }
    void inset(float dx, float dy) noexcept { left += dx; top += dy; right -= dx; bottom -= dy; }
    void offset(float dx, float dy) noexcept { left += dx; top += dy; right += dx; bottom += dy; }
};

// ------------------------------------------------------------------ paint
enum class Style { Fill, Stroke, FillAndStroke };
enum class Cap { Butt, Round, Square };
enum class Align { Left, Center, Right };
enum class Face { Regular, Bold, Mono, MonoBold };
enum class TileMode { Clamp, Repeat };

class Shader {
public:
    enum class Kind { Linear, Radial, Sweep };
    Kind kind{Kind::Linear};
    float x0{0.0F}, y0{0.0F}, x1{0.0F}, y1{0.0F};   // linear: from-to
    float cx{0.0F}, cy{0.0F}, radius{1.0F};          // radial / sweep centre
    std::vector<ColorInt> colors;
    std::vector<float> positions;                    // empty = evenly spread
    TileMode tile{TileMode::Clamp};

    // Colour (premultiplied BGRA) of this shader at a point of the shader's own space.
    [[nodiscard]] ColorInt colorAt(float x, float y) const noexcept;
    // 0..1 position along the gradient of a point (before tiling)
    [[nodiscard]] float parameterAt(float x, float y) const noexcept;
    [[nodiscard]] ColorInt colorForParameter(float t) const noexcept;   // unpremultiplied ARGB
};
using ShaderPtr = std::shared_ptr<const Shader>;

ShaderPtr linearGradient(float x0, float y0, float x1, float y1, ColorInt c0, ColorInt c1, TileMode tile = TileMode::Clamp);
ShaderPtr linearGradient(float x0, float y0, float x1, float y1, const std::vector<ColorInt>& colors,
                         const std::vector<float>& positions, TileMode tile = TileMode::Clamp);
ShaderPtr radialGradient(float cx, float cy, float radius, ColorInt c0, ColorInt c1, TileMode tile = TileMode::Clamp);
ShaderPtr radialGradient(float cx, float cy, float radius, const std::vector<ColorInt>& colors,
                         const std::vector<float>& positions, TileMode tile = TileMode::Clamp);
ShaderPtr sweepGradient(float cx, float cy, const std::vector<ColorInt>& colors, const std::vector<float>& positions);

struct Paint {
    ColorInt color{Color::BLACK};
    Style style{Style::Fill};
    float strokeWidth{0.0F};
    Cap strokeCap{Cap::Butt};
    Align textAlign{Align::Left};
    float textSize{12.0F};
    Face typeface{Face::Regular};
    float letterSpacing{0.0F};      // in em, like Android's Paint.letterSpacing
    ShaderPtr shader{};
    bool antiAlias{true};

    // Width of the text as it would be drawn (advance of the letters + the letter spacing).
    [[nodiscard]] float measureText(const std::string& utf8) const;
    // Width of the first `count` letters (code points), starting at letter `from`.
    [[nodiscard]] float measureText(const std::string& utf8, int from, int count) const;
};

// ------------------------------------------------------------------ path (lines only, as the screens use it)
class Path {
public:
    void reset() { contours_.clear(); }
    void moveTo(float x, float y);
    void lineTo(float x, float y);
    void close();
    [[nodiscard]] bool isEmpty() const noexcept { return contours_.empty(); }

    struct Contour {
        std::vector<float> xy;   // x0,y0,x1,y1 ...
        bool closed{false};
    };
    [[nodiscard]] const std::vector<Contour>& contours() const noexcept { return contours_; }

private:
    std::vector<Contour> contours_;
};

// ------------------------------------------------------------------ images
struct Image {
    int width{0};
    int height{0};
    std::vector<std::uint32_t> pixels;   // premultiplied 0xAARRGGBB
};

// ------------------------------------------------------------------ canvas
class Canvas {
public:
    Canvas(int width, int height);

    [[nodiscard]] int width() const noexcept { return width_; }
    [[nodiscard]] int height() const noexcept { return height_; }
    [[nodiscard]] const std::uint32_t* pixels() const noexcept { return pixels_.data(); }
    [[nodiscard]] std::uint32_t* pixels() noexcept { return pixels_.data(); }
    [[nodiscard]] const std::vector<std::uint32_t>& buffer() const noexcept { return pixels_; }
    Image takeImage();                                // moves the picture out (the canvas is empty afterwards)
    void clear(ColorInt color);

    void save();
    void restore();
    void translate(float dx, float dy);
    void scale(float sx, float sy);
    void rotate(float degrees, float px = 0.0F, float py = 0.0F);
    void clipRect(const RectF& r);                    // only without rotation

    void drawRect(const RectF& r, const Paint& paint);
    void drawRoundRect(const RectF& r, float rx, float ry, const Paint& paint);
    void drawCircle(float cx, float cy, float radius, const Paint& paint);
    void drawLine(float x0, float y0, float x1, float y1, const Paint& paint);
    void drawArc(const RectF& oval, float startDegrees, float sweepDegrees, bool useCenter, const Paint& paint);
    void drawPath(const Path& path, const Paint& paint);
    void drawText(const std::string& utf8, float x, float y, const Paint& paint);
    void drawImage(const Image& image, const RectF& dst, const Paint& paint);

private:
    struct Matrix {
        float a{1.0F}, b{0.0F}, c{0.0F}, d{1.0F}, e{0.0F}, f{0.0F};   // x' = a x + c y + e ; y' = b x + d y + f
    };
    struct State {
        Matrix m;
        int clipL{0}, clipT{0}, clipR{0}, clipB{0};
    };
    struct Poly {
        std::vector<float> xy;    // device space
    };

    void fillPolys(const std::vector<Poly>& polys, const Paint& paint, ColorInt solid, const Shader* shader);
    void fillAlignedRect(const RectF& deviceRect, const Paint& paint, ColorInt solid, const Shader* shader);
    void fillCoverageRow(int y, int x0, const float* coverage, int count, ColorInt solid, const Shader* shader);
    void blendPixel(int x, int y, ColorInt solid, const Shader* shader, float coverage);
    void fillSpan(int y, int x0, int x1, int cov255);   // pixels [x0, x1) of one row, all with the same coverage (0..255)
    void prepareLut();                                  // gradient lookup table for the current draw call
    [[nodiscard]] std::uint32_t sourceAt(int x, int y);  // premultiplied colour of the current source (paint alpha applied)
    void strokeLinePolys(const float* xy, int pointCount, bool closed, float width, Cap cap, std::vector<Poly>& out) const;
    void addCircle(std::vector<Poly>& out, float cx, float cy, float rx, float ry, bool reverse) const;
    void addRoundRect(std::vector<Poly>& out, const RectF& r, float rx, float ry, bool reverse) const;
    void addArcBand(std::vector<Poly>& out, float cx, float cy, float rx, float ry, float startRad, float sweepRad,
                    float halfWidth, Cap cap) const;
    void mapPoint(float x, float y, float& ox, float& oy) const noexcept;
    [[nodiscard]] bool isAxisAligned() const noexcept;
    [[nodiscard]] float uniformScale() const noexcept;
    [[nodiscard]] Shader localShaderToDevice(const Shader& s) const;
    [[nodiscard]] ColorInt shaderPixel(const Shader& s, int x, int y) const noexcept;

    int width_{0};
    int height_{0};
    std::vector<std::uint32_t> pixels_;
    std::vector<State> stack_;
    State state_;
    std::vector<float> accumulation_;
    // inverse of the current matrix while a shader is used
    Matrix inverse_;
    bool inverseValid_{false};
};

// ------------------------------------------------------------------ fonts and helpers
// Where the font files (Roboto, DejaVu) are. Must be set once before any text is measured or drawn.
void setFontDirectory(const std::string& directory);
// Is the font data available (the files were found)?
bool fontsReady();

// UTF-8 helpers (the screens work with UTF-8 strings; Cyrillic is 2 bytes per letter)
int utf8Length(const std::string& s);                              // number of code points
std::string utf8Prefix(const std::string& s, int codePoints);      // first n code points
std::string utf8Substring(const std::string& s, int from, int to); // code points [from, to)
std::string utf8Upper(const std::string& s);                       // Latin + Cyrillic upper case

// Writes the picture as a PNG (RGB, no alpha) - for the tests and the screenshots.
bool writePng(const std::string& path, const Canvas& canvas);
bool writePng(const std::string& path, const Image& image);

} // namespace silveton::ui
